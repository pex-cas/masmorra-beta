# -*- coding: utf-8 -*-
"""Pruebas v6: defensa [L] en lugar de maná, sin robo de vida, oro y botellas con diseño propio."""
import random
import unittest

from tests._helpers import have_tk, install_fake_tk

install_fake_tk()
from player.player import CLASS_CONFIGS, GUARD_DELAY, Player   # noqa: E402


class TestDefenseBar(unittest.TestCase):
    def test_no_mana_and_no_lifesteal_anywhere(self):
        for cfg in CLASS_CONFIGS.values():
            self.assertNotIn("mp", cfg)
            self.assertIn("df", cfg)
            self.assertTrue(all(len(k) == 2 for k in cfg["kit"]))
        p = Player("Mago")
        for attr in ("mp", "max_mp", "mp_regen", "mp_potions", "lifesteal"):
            self.assertFalse(hasattr(p, attr), attr)
        self.assertNotIn("vampirismo", p.talents)
        self.assertFalse(hasattr(p, "use_mp_potion"))

    def test_guard_drains_and_recovers_slowly(self):
        p = Player("Guerrero")
        full = p.defense
        for _ in range(60):
            p.update_guard(True, 0.05)
        self.assertTrue(p.guarding)
        self.assertLess(p.defense, full - 50)
        low = p.defense
        for _ in range(int(GUARD_DELAY / 0.05) - 2):             # sin recuperar durante la espera
            p.update_guard(False, 0.05)
        self.assertEqual(p.defense, low)
        for _ in range(100):                                      # 5 s de recuperacion: lenta
            p.update_guard(False, 0.05)
        self.assertGreater(p.defense, low)
        self.assertLess(p.defense - low, 40)

    def test_guard_breaks_when_empty_and_returns_after_recovering(self):
        p = Player("Mago")
        for _ in range(400):
            p.update_guard(True, 0.05)
        self.assertTrue(p.guard_broken)
        self.assertFalse(p.guarding)
        p.update_guard(True, 0.05)
        self.assertFalse(p.guarding)                              # rota: L no hace nada
        for _ in range(2000):
            p.update_guard(False, 0.05)
        self.assertFalse(p.guard_broken)

    def test_guard_absorbs_damage_and_costs_bar(self):
        random.seed(1)
        p = Player("Guerrero")
        p.dodge = 0.0
        p.invuln = 0
        hp = p.hp
        p.update_guard(True, 0.0)
        d0 = p.defense
        dmg, _ = p.take_damage(100)
        loss_g = hp - p.hp
        self.assertLess(p.defense, d0)
        p2 = Player("Guerrero"); p2.dodge = 0.0
        p2.take_damage(100)
        self.assertLess(loss_g, (p2.max_hp - p2.hp) * 0.4)

    def test_defense_items_replace_mana_items(self):
        from inventory.items import Item, PREFIXES, SUFFIXES, STAT_NAMES
        txt = repr(PREFIXES) + repr(SUFFIXES) + repr(STAT_NAMES)
        self.assertNotIn("max_mp", txt)
        self.assertNotIn("mp_regen", txt)
        self.assertNotIn("lifesteal", txt)
        for _ in range(200):
            it = Item.generate_random(3)
            self.assertFalse({"max_mp", "mp_regen", "lifesteal"} & set(it.stats))


class TestGoldAndBottles(unittest.TestCase):
    def test_icons_build(self):
        from graphics import icons
        for g in [icons.potion_grid()] + [icons.coin_grid(i) for i in range(4)] + [icons.pile_grid(i) for i in range(3)]:
            self.assertEqual((len(g), len(g[0])), (16, 16))
            self.assertTrue(any(c for row in g for c in row))

    @unittest.skipIf(have_tk(), "motor simulado")
    def test_gold_drops_magnet_and_is_not_lost(self):
        from combat.entities import GoldPile
        from tests.test_engine_headless import TestEngineHeadless
        random.seed(4)
        e = TestEngineHeadless("build").build("Guerrero")
        p = e.player
        g0 = p.gold
        e.drop_gold(p.x + 90, p.y, 40)
        self.assertTrue(any(isinstance(o[2], GoldPile) for o in e.dropped_items))
        for _ in range(60):
            e.now += 0.016
            e.update_simulation(0.016)
        self.assertEqual(p.gold, g0 + 40)
        e.drop_gold(p.x + 900, p.y, 25)                            # lejos: no se junta, pero al bajar de piso se cobra
        e.load_floor(2)
        self.assertEqual(p.gold, g0 + 65)

    @unittest.skipIf(have_tk(), "motor simulado")
    def test_defense_key_blocks_attacks_in_engine(self):
        from tests.test_engine_headless import TestEngineHeadless
        random.seed(2)
        e = TestEngineHeadless("build").build("Guerrero")
        e.keys.update({"l": True, "x": True})
        for _ in range(20):
            e.now += 0.016
            e.update_simulation(0.016)
            e.render()
        self.assertTrue(e.player.guarding)
        self.assertEqual(e.player.cd[0], 0)                         # cubriendote no atacas
        e.keys["l"] = False
        e.update_simulation(0.016)
        self.assertFalse(e.player.guarding)


if __name__ == "__main__":
    unittest.main()
