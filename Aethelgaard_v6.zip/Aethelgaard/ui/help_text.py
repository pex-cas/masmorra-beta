# -*- coding: utf-8 -*-
"""Textos de ayuda de la interfaz."""


# ==============================================================================
SKILL_HELP = {
    "Guerrero": ("Tajo en arco frente a vos. Sin costo; mantenelo apretado para repetirlo.",
                 "Golpe sísmico: daño enorme, empuja y congela 1.2s a los golpeados.",
                 "Torbellino: 2.6s de cuchillas giratorias a tu alrededor. Sos invulnerable y más rápido."),
    "Mago": ("Rayo arcano: proyectil veloz, sin límite de uso.",
             "Bola de fuego: explota en área y deja a los enemigos ardiendo.",
             "Lluvia de meteoros: 10 meteoros caen alrededor del objetivo (cursor o autoapuntado)."),
    "Pícaro": ("Daga veloz con +10% de crítico. Sin costo.",
               "Abanico: lanza 7 dagas en abanico; cada una atraviesa a 2 enemigos.",
               "Danza de cuchillas: te teletransportás entre hasta 7 enemigos cercanos con golpes críticos."),
}

SLOT_HELP = {
    "Arma": "Sube tu daño físico y mágico.",
    "Armadura": "Da armadura y vida máxima.",
    "Casco": "Da armadura y vida máxima.",
    "Botas": "Da armadura y vida máxima.",
    "Amuleto": "Da defensa máxima y probabilidad de crítico.",
    "Anillo": "Da defensa máxima y probabilidad de crítico.",
}

TALENT_HELP = {
    "vitalidad": "+25 vida máxima y +0.5 regeneración de vida por punto.",
    "ferocidad": "+4 daño, +2% crítico y +0.1 de multiplicador crítico por punto.",
    "celeridad": "+10 velocidad, +5% reducción de cooldown y +10 stamina por punto.",
}

GUIDE_SECTIONS = [
    ("CONTROLES", [
        ("WASD / Flechas", "Moverte por la mazmorra."),
        ("SHIFT (mantener)", "Sprint: +55% velocidad, gasta stamina (barra amarilla). Si llega a 0 quedás sin aliento hasta recuperar."),
        ("ESPACIO", "Dash: esquive corto con invulnerabilidad. Tiene cooldown."),
        ("X o click izq.", "Ataque base. Mantenelo apretado para repetirlo."),
        ("C o click der.", "Ataque fuerte: más daño, con cooldown."),
        ("Z", "ULTIMATE: tu habilidad definitiva, con cooldown largo."),
        ("L (mantener)", "DEFENSA: te cubrís con un escudo y absorbés el 80% del daño. No podés atacar ni correr y caminás lento. "
                         "La barra celeste se gasta mientras te cubrís y con cada golpe absorbido; si se vacía la guardia se rompe "
                         "hasta recuperar un poco. Se recupera lento cuando soltás."),
        ("Q", "Poción de vida (cura 45%)."),
        ("P", "Activa o desactiva el AUTOAPUNTADO."),
        ("M", "Activa o desactiva la música."),
        ("O", "PAUSA: congela el juego. Volvé a apretar O o Esc para continuar."),
        ("I · T · B · G", "Mochila · Talentos · Tienda · Guía. Se abren a pantalla completa y pausan el juego; Esc los cierra."),
        ("F11", "Pantalla completa / ventana."),
    ]),
    ("AUTOAPUNTADO", [
        ("Cómo funciona", "Con P activado, cada ataque, dash y meteoro va solo hacia el enemigo visible más cercano (hasta 480px). "
                          "Aparece una mira roja sobre el objetivo. Sin enemigos cerca apuntás con el mouse. Con P desactivado apuntás siempre con el mouse."),
    ]),
    ("LA MAZMORRA", [
        ("Escaleras", "Bajan al siguiente piso. Cada 5 pisos hay un jefe que bloquea el descenso. El piso 10 es la victoria."),
        ("Cofres", "Caminá sobre ellos: dan oro."),
        ("Santuarios", "Curan vida y defensa por completo y regalan una poción de vida. El círculo de runas del suelo marca el altar."),
        ("Paredes secretas", "Algunas paredes tienen una grieta. Atacalas (cuerpo a cuerpo, proyectiles o explosiones) y se rompen, "
                             "revelando una cámara oculta con cofre, oro extra y una poción."),
        ("Antorchas", "Iluminan la zona; lejos de ellas todo es más oscuro. Lo explorado queda en el minimapa."),
        ("Pociones y oro", "Las botellas rojas son pociones de vida y las monedas / montones brillantes son oro: caminá cerca y el oro viene solo hacia vos."),
    ]),
    ("OBJETOS Y ORO", [
        ("Rareza", "Común (gris), Mágico (azul), Raro (amarillo), Épico (violeta), Legendario (naranja). Más rareza, más bonos."),
        ("Mochila", "Equipá lo que te sirva y vendé el resto por oro."),
        ("Tienda", "El equipo ya no cae de los enemigos: se compra en la Tienda [B] con oro y se renueva en cada piso."),
        ("Oro", "Se junta con enemigos, cofres y ventas. Cuenta como tu puntaje final."),
    ]),
]

MENU_STATES = ("INVENTORY", "TALENTS", "GUIDE", "SHOP", "HERO")      # menus a pantalla completa (juego en pausa)
PLAY_STATES = ("PLAYING", "PAUSED") + MENU_STATES
