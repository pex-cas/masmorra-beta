# Aethelgaard V9

- Eliminada la curación pasiva: la vida se recupera mediante pociones y santuarios.
- Críticos acumulativos por enemigo: cada golpe aumenta en 10 puntos porcentuales la probabilidad del siguiente crítico, hasta el 100%; el contador es individual y se elimina al derrotar al enemigo.
- Habitaciones secretas: una por piso como objetivo garantizado si la geometría lo permite; cada habitación adicional tiene probabilidades sucesivas del 50%, 25%, 12,5%, etc.
- El ataque básico tiene 50 ms adicionales de espera.
- Cinco piezas de jefe únicas por partida: Minotauro Rey, Reina Pútrida, Rey Espectral, Archimago Ígneo y Señor del Abismo. No se repiten.
- Los cofres de habitaciones secretas contienen exclusivamente una poción; los cofres normales conservan su recompensa de oro.


## Ajustes finales V9
- Eliminada la mira roja que rodeaba al objetivo automático; el autoapuntado sigue funcionando.
- Eliminados los santuarios benditos y su generación en los pisos.
- Subir de nivel ya no restaura la vida; sí recalcula las estadísticas y mantiene el ajuste de defensa.
- Añadido ataque alternativo con V: tajo amplio del Guerrero, triple rayo del Mago y doble daga del Bandido.
- Aumentada la pausa entre ataques básicos en 220 ms adicionales.
- Centrado y simetrizado el casco del Guerrero.
