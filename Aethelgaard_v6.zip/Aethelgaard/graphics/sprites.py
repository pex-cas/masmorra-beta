# -*- coding: utf-8 -*-
"""Sprites de personajes: pixel art 16x16 (el mismo diseno de la version original), con contorno."""
from graphics.utils import _rect, shade, to_photo
from player.player import CLASS_CONFIGS


# ==============================================================================
SPRITE_SPECS = {
    "Guerrero": dict(body="#9aa5b8", trim="#e63946", pads="#c1c9d6", leg="#4a4e69", boot="#2b2d42",
                     gear=("helm",), metal="#b8c1cf", plume="#e63946", weapon="sword", blade="#eef2f7",
                     shield="#7f5539", emblem="#ffd166", cape="#a4161a"),
    "Mago": dict(body="#3d5a99", trim="#ffd166", robe="#3d5a99", gear=("wizhat",), hat="#2c4577",
                 beard="#f1f1f1", weapon="staff", orb="#4cc9f0"),
    "Pícaro": dict(body="#2d6a4f", trim="#95d5b2", leg="#1b4332", boot="#081c15", gear=("hood",),
                   hood="#1b4332", mask="#081c15", weapon="dagger", blade="#d8f3dc", cape="#14301f",
                   eye="#d8f3dc"),
    "Esqueleto": dict(skin="#e9ecef", body="#ced4da", ribs="#495057", trim="#adb5bd", leg="#dee2e6",
                      boot="#adb5bd", skull=True, eye="#ff3b3b", weapon="sword", blade="#8d6e63"),
    "Zombi Pútrido": dict(skin="#7aa35a", body="#6b5b45", trim="#3a2e25", leg="#3d405b", boot="#222222",
                          hair="#2b2d1e", armsout=True, eye="#ffee32"),
    "Arquero Espectral": dict(skin="#caf0f8", body="#90e0ef", trim="#00b4d8", robe="#90e0ef",
                              gear=("hood",), hood="#48cae4", weapon="bow", eye="#023e8a"),
    "Mago de Fuego": dict(skin="#e8b88a", body="#c1121f", trim="#ffb703", robe="#c1121f",
                          gear=("flame",), weapon="staff", orb="#ff6d00", eye="#ffffff"),
    "Minotauro Brutal": dict(skin="#7f5539", body="#7f5539", trim="#3d2b1f", pads="#a68a64", leg="#5e3c23",
                             boot="#2b1d12", gear=("horns",), horn="#e9d8a6", snout="#a98467",
                             weapon="axe", eye="#ff2a2a", zoom=4),
    # Jefe: diseno nuevo en el mismo estilo pixel art (grilla de 24x24 para mas detalle)
    "Señor del Abismo (JEFE)": dict(boss=True, grid=24, zoom=6, skin="#7b2fa8", body="#1c1030", plate="#3a2266",
                                    trim="#ff2e63", horn="#efe3c8", wings="#4a1670", bone="#2a0f45",
                                    cloth="#5c0f2e", blade="#f0c6ff", eye="#ffee32"),
}


def build_humanoid(s, f):
    """f = frame de caminata: 0 neutro, 1 pierna izq arriba, 3 pierna der arriba."""
    if s.get("boss"):
        return build_boss(s, f)
    g = [[None] * 16 for _ in range(16)]
    R = lambda x, y, w, h, c: _rect(g, x, y, w, h, c)
    bob = 1 if f in (1, 3) else 0
    skin = s.get("skin", "#e8b88a")
    body = s["body"]
    trim = s.get("trim", body)
    eye = s.get("eye", "#111111")
    gears = s.get("gear", ())

    if s.get("wings"):
        w = s["wings"]
        R(0, 4 + bob, 3, 7, w); R(13, 4 + bob, 3, 7, w); R(1, 3 + bob, 1, 2, w); R(14, 3 + bob, 1, 2, w)
    if s.get("cape"):
        R(4, 7 + bob, 8, 8, s["cape"])

    boot = s.get("boot", "#1a1a1a")
    if s.get("robe"):
        rc = s["robe"]
        R(4, 11, 8, 1, rc); R(3, 12, 10, 3, rc)
        if f != 1: R(5, 15, 2, 1, boot)
        if f != 3: R(9, 15, 2, 1, boot)
    else:
        leg = s.get("leg", "#333333")
        ll = 3 if f == 1 else 4
        lr = 3 if f == 3 else 4
        R(5, 12, 2, ll - 1, leg); R(5, 11 + ll, 2, 1, boot)
        R(9, 12, 2, lr - 1, leg); R(9, 11 + lr, 2, 1, boot)

    R(4, 7 + bob, 8, 5, body)
    if s.get("ribs"):
        R(5, 8 + bob, 6, 1, s["ribs"]); R(5, 10 + bob, 6, 1, s["ribs"]); R(7, 7 + bob, 2, 5, "#e9ecef")
    R(4, 10 + bob, 8, 1, trim)
    if s.get("pads"):
        R(2, 7 + bob, 3, 2, s["pads"]); R(11, 7 + bob, 3, 2, s["pads"])
    if s.get("armsout"):
        R(12, 7 + bob, 4, 2, skin); R(0, 7 + bob, 4, 2, skin)
    else:
        sl = s.get("sleeve", body if not s.get("skull") else skin)
        R(3, 8 + bob, 1, 3, sl); R(12, 8 + bob, 1, 3, sl)
        R(3, 11 + bob, 1, 1, skin); R(12, 11 + bob, 1, 1, skin)

    R(5, 2 + bob, 6, 5, skin)
    if s.get("skull"):
        R(6, 4 + bob, 2, 2, "#111111"); R(9, 4 + bob, 2, 2, "#111111")
        R(7, 5 + bob, 1, 1, eye); R(10, 5 + bob, 1, 1, eye); R(6, 6 + bob, 4, 1, "#adb5bd")
    else:
        R(6, 4 + bob, 1, 1, eye); R(9, 4 + bob, 1, 1, eye)
    if s.get("hair"):
        h = s["hair"]
        R(5, 2 + bob, 6, 1, h); R(5, 3 + bob, 1, 2, h); R(10, 3 + bob, 1, 2, h)
    if s.get("beard"):
        R(6, 6 + bob, 4, 2, s["beard"])
    if s.get("mask"):
        R(5, 5 + bob, 6, 2, s["mask"])
    if s.get("snout"):
        R(6, 5 + bob, 4, 2, s["snout"]); R(7, 6 + bob, 1, 1, "#222222"); R(9, 6 + bob, 1, 1, "#222222")

    if "helm" in gears:
        m = s["metal"]
        R(5, 1 + bob, 6, 3, m); R(4, 2 + bob, 1, 4, m); R(11, 2 + bob, 1, 4, m); R(7, 4 + bob, 2, 2, m)
        R(6, 0 + bob, 4, 1, s["plume"])
    if "wizhat" in gears:
        h = s["hat"]
        R(3, 2 + bob, 10, 1, h); R(5, 1 + bob, 6, 1, h); R(6, 0 + bob, 4, 1, h); R(8, 1 + bob, 1, 1, "#ffd166")
    if "hood" in gears:
        h = s["hood"]
        R(4, 1 + bob, 8, 3, h); R(4, 3 + bob, 1, 4, h); R(11, 3 + bob, 1, 4, h)
    if "horns" in gears:
        hn = s["horn"]
        R(4, 1 + bob, 1, 2, hn); R(3, 0 + bob, 1, 2, hn); R(2, 0 + bob, 1, 1, hn)
        R(11, 1 + bob, 1, 2, hn); R(12, 0 + bob, 1, 2, hn); R(13, 0 + bob, 1, 1, hn)
    if "flame" in gears:
        R(5, 1 + bob, 6, 2, "#ff6d00"); R(5, 0 + bob, 1, 1, "#ff6d00"); R(7, 0 + bob, 2, 1, "#ffd23f")
        R(10, 0 + bob, 1, 1, "#ff6d00"); R(6, 1 + bob, 4, 1, "#ffd23f")

    w = s.get("weapon")
    if w == "sword":
        R(13, 2 + bob, 1, 7, s["blade"]); R(12, 9 + bob, 3, 1, "#8a5a2b"); R(13, 10 + bob, 1, 2, "#5c3d1e")
    elif w == "bigsword":
        R(13, 0 + bob, 2, 10, s["blade"]); R(12, 10 + bob, 4, 1, "#ff006e"); R(13, 11 + bob, 2, 3, "#5c3d1e")
    elif w == "staff":
        R(14, 3 + bob, 1, 12, "#7f5539"); R(14, 0 + bob, 1, 3, s["orb"]); R(13, 1 + bob, 3, 1, s["orb"])
    elif w == "dagger":
        R(13, 8 + bob, 1, 3, s["blade"]); R(12, 11 + bob, 3, 1, "#444444")
        R(2, 8 + bob, 1, 3, s["blade"]); R(1, 11 + bob, 3, 1, "#444444")
    elif w == "bow":
        wood = "#8b5e34"
        R(13, 3 + bob, 1, 1, wood); R(14, 4 + bob, 1, 6, wood); R(13, 10 + bob, 1, 1, wood)
        R(13, 4 + bob, 1, 6, "#dddddd")
    elif w == "axe":
        R(14, 3 + bob, 1, 10, "#7f5539"); R(11, 3 + bob, 4, 4, "#adb5bd"); R(11, 3 + bob, 1, 4, "#e9ecef")
    if s.get("shield"):
        R(0, 7 + bob, 4, 6, s["shield"]); R(2, 8 + bob, 1, 4, s["emblem"]); R(1, 9 + bob, 3, 1, s["emblem"])
    return g


def build_boss(s, f):
    """Senor del Abismo en pixel art 24x24: corona de cuernos, alas, armadura con nucleo runico y espadon."""
    g = [[None] * 24 for _ in range(24)]
    R = lambda x, y, w, h, c: _rect(g, x, y, w, h, c)
    M = lambda x, y, w, h, c: (R(x, y, w, h, c), R(24 - x - w, y, w, h, c))      # simetrico
    bob = 1 if f in (1, 3) else 0
    sk, bd, pl, tr, hn = s["skin"], s["body"], s["plate"], s["trim"], s["horn"]
    wg, bn, cl = s["wings"], s["bone"], s["cloth"]
    # alas (detras)
    M(0, 7 + bob, 5, 9, wg); M(1, 5 + bob, 3, 2, wg); M(1, 3 + bob, 1, 3, hn); M(4, 6 + bob, 1, 11, bn)
    M(2, 16 + bob, 2, 2, wg); M(0, 12 + bob, 1, 5, bn)
    # piernas
    ll = 4 if f == 1 else 5
    lr = 4 if f == 3 else 5
    R(8, 18, 3, ll - 1, "#120a22"); R(7, 17 + ll, 4, 1, bn); R(7, 18 + ll, 1, 1, hn); R(10, 18 + ll, 1, 1, hn)
    R(13, 18, 3, lr - 1, "#120a22"); R(13, 17 + lr, 4, 1, bn); R(13, 18 + lr, 1, 1, hn); R(16, 18 + lr, 1, 1, hn)
    # faldon y capa
    R(7, 16 + bob, 10, 3, cl); R(7, 16 + bob, 10, 1, tr); R(8, 19 + bob, 2, 1, cl); R(14, 19 + bob, 2, 1, cl)
    # torso
    R(7, 9 + bob, 10, 7, s["body"]); R(9, 10 + bob, 6, 5, pl)
    R(11, 11 + bob, 2, 3, tr); R(11, 12 + bob, 2, 1, "#ffffff")
    R(8, 11 + bob, 1, 4, tr); R(15, 11 + bob, 1, 4, tr)
    # hombreras con puas
    M(4, 8 + bob, 4, 3, pl); M(5, 5 + bob, 2, 3, hn); M(4, 7 + bob, 1, 1, hn)
    # brazos y garras
    M(5, 11 + bob, 2, 5, s["body"]); R(5, 16 + bob, 2, 2, sk); R(17, 16 + bob, 2, 2, sk)
    R(5, 18 + bob, 1, 1, hn); R(17, 18 + bob, 1, 1, hn)
    # espadon (mano derecha)
    R(20, 0 + bob, 2, 15, s["blade"]); R(21, 1 + bob, 1, 12, "#b565d6"); R(19, 15 + bob, 5, 1, tr); R(20, 16 + bob, 2, 3, "#5c3d1e")
    # cabeza
    R(8, 3 + bob, 8, 6, sk); R(8, 5 + bob, 8, 1, "#150a22")
    R(9, 6 + bob, 2, 1, s["eye"]); R(13, 6 + bob, 2, 1, s["eye"])
    R(10, 8 + bob, 4, 1, "#150a22"); R(10, 9 + bob, 1, 1, "#fffaf0"); R(13, 9 + bob, 1, 1, "#fffaf0")
    # corona y cuernos
    R(8, 2 + bob, 8, 1, pl); R(11, 2 + bob, 2, 1, tr)
    M(7, 1 + bob, 1, 2, hn); M(6, 0 + bob, 1, 2, hn); M(5, 0 + bob, 1, 1, hn)
    R(11, 0 + bob, 2, 2, hn)
    return g


def outline_grid(g, col="#0b0b10"):
    n = len(g)
    out = [row[:] for row in g]
    for y in range(n):
        for x in range(n):
            if g[y][x] is None:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < n and 0 <= ny < n and g[ny][nx]:
                        out[y][x] = col
                        break
    return out


class SpriteBank:
    """Sprites pixel art. `zoom` del spec = tamano en pantalla (16*zoom px); la grilla es 16x16 (el jefe 24x24)."""
    STAGE = {"Señor del Abismo (JEFE)": 14, "Minotauro Brutal": 10}      # zoom de la portada (por defecto 8; heroes 12)

    def __init__(self):
        self.imgs, self.preview, self.big, self.stage = {}, {}, {}, {}
        for name, spec in SPRITE_SPECS.items():
            z = spec.get("zoom", 3)
            n = spec.get("grid", 16)
            pz = z * 16 // n
            d = {}
            for f in (0, 1, 3):
                g = outline_grid(build_humanoid(spec, f))
                d[("R", f)] = to_photo(g, n, pz)
                d[("L", f)] = to_photo([row[::-1] for row in g], n, pz)
            self.imgs[name] = d
            g0 = outline_grid(build_humanoid(spec, 0))
            if name in CLASS_CONFIGS:
                self.preview[name] = to_photo(g0, n, 4)
                self.big[name] = to_photo(g0, n, 7)
                self.stage[name] = to_photo(g0, n, 12)
            else:                                   # portada: enemigos y jefe en penumbra
                gs = [[shade(c, 0.55) if c else None for c in row] for row in g0]
                self.stage[name] = to_photo(gs, n, self.STAGE.get(name, 8))

    def get(self, name, facing, frame):
        return self.imgs[name][(facing, frame)]
