# -*- coding: utf-8 -*-
"""
================================================================================
  CHRONICLES OF AETHELGAARD: THE ABYSSAL CITADEL  -  v3
  ARPG / Dungeon Crawler Roguelike  (Tkinter Canvas, 100% Python estandar)

  CONTROLES
    WASD / Flechas ..... moverse
    SHIFT (mantener) ... SPRINT (gasta stamina)
    ESPACIO ............ DASH (esquiva con invulnerabilidad)
    X (mantener) ....... ATAQUE BASE (se puede espamear)
    C .................. ATAQUE FUERTE (cooldown + algo de mana)
    Z .................. ULTIMATE (cooldown largo + mana)
    Mouse .............. apuntar  (click izq = X, click der = C)
    Q / E .............. pocion de vida / mana
    I / TAB ............ inventario        T / K ... talentos
    P .................. AUTOAPUNTADO on/off     M ... musica on/off     G ... guia
================================================================================
"""

import tkinter as tk
from tkinter import font as tkfont
import math
import random
import time
import threading
import queue
import os
import tempfile
import wave
import array
from functools import lru_cache

try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    HAS_WINSOUND = False


# ==============================================================================
# 1. AUDIO (un solo hilo con cola: no satura el CPU)
# ==============================================================================
class SoundEngine:
    PATTERNS = {
        "slash": [(450, 25)], "hit": [(220, 35)], "crit": [(850, 45)],
        "fireball": [(320, 60)], "freeze": [(1200, 40)], "dash": [(600, 30)],
        "gold": [(1400, 20), (1800, 30)], "potion": [(700, 40), (900, 50)],
        "level_up": [(523, 60), (659, 60), (784, 60), (1046, 60)],
        "boss_roar": [(150, 80), (110, 80), (80, 80)],
        "game_over": [(350, 100), (280, 100), (200, 100), (130, 100)],
        "heavy": [(180, 60), (120, 80)],
        "ult": [(300, 50), (450, 50), (700, 50), (1000, 80)],
        "meteor": [(90, 90)],
        "secret": [(300, 60), (400, 60), (600, 90)],
    }

    def __init__(self):
        self.enabled = HAS_WINSOUND
        self.q = queue.Queue()
        self.last = 0.0
        if self.enabled:
            threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        while True:
            pattern = self.q.get()
            for f, d in pattern:
                try:
                    winsound.Beep(int(max(37, min(32767, f))), int(d))
                except Exception:
                    pass

    def play_sfx(self, name):
        if not self.enabled:
            return
        now = time.time()
        if now - self.last < 0.04 or self.q.qsize() > 3:
            return
        self.last = now
        pat = self.PATTERNS.get(name)
        if pat:
            self.q.put(pat)

AUDIO = SoundEngine()


# ------------------------------------------------------------------------------
# MUSICA DE FONDO: ambiente oscuro generado por codigo (sin archivos externos).
# Se sintetiza un WAV en loop (drone + acordes que respiran + campanitas +
# latido grave) y se reproduce con winsound.PlaySound en segundo plano.
# Cada bioma tiene su propia tonalidad y progresion de acordes.
# ------------------------------------------------------------------------------
class MusicEngine:
    SR, LOOP = 11025, 16.0
    # bioma: (raiz en Hz, progresion [(semitonos, 'm'|'M')])
    THEMES = {
        1: (55.00, [(0, "m"), (8, "M"), (3, "M"), (10, "M")]),
        2: (49.00, [(0, "m"), (1, "M"), (0, "m"), (10, "M")]),
        3: (51.91, [(0, "m"), (5, "m"), (8, "M"), (7, "M")]),
        4: (46.25, [(0, "m"), (8, "M"), (1, "M"), (7, "m")]),
    }

    def __init__(self):
        self.enabled = HAS_WINSOUND
        self.muted = False
        self.current = None
        self.want = None
        self.building = set()
        self.lock = threading.Lock()

    def _path(self, bid):
        return os.path.join(tempfile.gettempdir(), "aethelgaard_bgm_v1_%d.wav" % bid)

    def synth(self, bid):
        """Devuelve la lista de muestras (int16) de un loop perfecto de LOOP segundos."""
        SR, L = self.SR, self.LOOP
        N = int(SR * L)
        root, prog = self.THEMES[bid]
        rnd = random.Random(bid * 101)
        tau, sin, exp = 2 * math.pi, math.sin, math.exp
        buf = [0.0] * N

        def fr(f):          # frecuencia con ciclos enteros -> el loop no hace "click"
            return max(1, round(f * L)) / L

        # drone grave con respiracion lenta
        f0, f1 = fr(root), fr(root * 1.5)
        for i in range(N):
            t = i / SR
            lfo = 0.78 + 0.22 * sin(tau * t / L)
            buf[i] = (0.15 * sin(tau * f0 * t) + 0.05 * sin(tau * f1 * t)) * lfo

        # acordes (pad) con ventana sin^2: suben y bajan, loop sin cortes
        seg = N // 4
        for k, (off, kind) in enumerate(prog):
            third = 3 if kind == "m" else 4
            freqs = [root * 2 ** ((off + s) / 12.0) * 2 for s in (0, third, 7)]
            a = k * seg
            for j in range(seg):
                t = (a + j) / SR
                w = sin(math.pi * j / seg) ** 2
                v = 0.0
                for f in freqs:
                    v += sin(tau * f * t) + 0.6 * sin(tau * f * 1.004 * t + 1.3)
                buf[a + j] += 0.045 * w * v

        # campanitas esporadicas (la cola se enrosca al inicio del loop)
        for step in range(32):
            if rnd.random() < 0.55:
                off, kind = prog[step // 8]
                third = 3 if kind == "m" else 4
                semis = off + rnd.choice((0, third, 7, 12, third + 12))
                f = root * 2 ** (semis / 12.0) * rnd.choice((4, 4, 8))
                start, dur = int(step * 0.5 * SR), int(2.2 * SR)
                for j in range(dur):
                    tt = j / SR
                    buf[(start + j) % N] += 0.07 * exp(-2.6 * tt) * (
                        sin(tau * f * tt) + 0.35 * sin(tau * f * 2.003 * tt))

        # latido grave (tension)
        for beat in range(8):
            for off_t, amp in ((0.0, 0.26), (0.30, 0.18)):
                start = int((beat * 2.0 + off_t) * SR)
                for j in range(int(0.45 * SR)):
                    tt = j / SR
                    buf[(start + j) % N] += amp * exp(-9 * tt) * sin(tau * 52 * tt * (1 - 0.3 * tt))

        peak = max(1e-6, max(abs(v) for v in buf))
        k = 0.72 * 32767 / peak
        return [int(v * k) for v in buf]

    def _write(self, bid, path):
        samples = self.synth(bid)
        tmp = path + ".tmp"
        with wave.open(tmp, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(self.SR)
            w.writeframes(array.array("h", samples).tobytes())
        os.replace(tmp, path)

    def _start(self, bid, path):
        try:
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
            self.current = bid
        except Exception:
            pass

    def _build_and_play(self, bid):
        path = self._path(bid)
        try:
            self._write(bid, path)
        except Exception:
            path = None
        finally:
            with self.lock:
                self.building.discard(bid)
        if path and self.want == bid and not self.muted and self.current != bid:
            self._start(bid, path)

    def play_theme(self, bid):
        bid = bid if bid in self.THEMES else 1
        self.want = bid
        if not self.enabled or self.muted or self.current == bid:
            return
        path = self._path(bid)
        if os.path.exists(path):
            self._start(bid, path)
            return
        with self.lock:
            if bid in self.building:
                return
            self.building.add(bid)
        threading.Thread(target=self._build_and_play, args=(bid,), daemon=True).start()

    def _purge(self):
        if self.enabled:
            try:
                winsound.PlaySound(None, winsound.SND_PURGE)
            except Exception:
                pass
        self.current = None

    def stop(self):
        self.want = None
        self._purge()

    def toggle(self):
        self.muted = not self.muted
        if self.muted:
            self._purge()
        else:
            self.play_theme(self.want or 1)
        return not self.muted

MUSIC = MusicEngine()


# ==============================================================================
# 2. UTILIDADES (colores, imagenes, grilla espacial)
# ==============================================================================
@lru_cache(maxsize=20000)
def _shade(h, f):
    r, g, b = int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16)
    return "#%02x%02x%02x" % (max(0, min(255, int(r * f))),
                              max(0, min(255, int(g * f))),
                              max(0, min(255, int(b * f))))

def shade(h, f):
    return _shade(h, round(f, 2))


def _rect(g, x, y, w, h, c):
    """Rellena un rectangulo en una grilla cuadrada de colores."""
    if not c:
        return
    n = len(g)
    for j in range(max(0, y), min(n, y + h)):
        row = g[j]
        for i in range(max(0, x), min(n, x + w)):
            row[i] = c


def to_photo(grid, n, zoom):
    """Convierte una grilla n x n de colores (None = transparente) en PhotoImage."""
    img = tk.PhotoImage(width=n, height=n)
    if all(c for row in grid for c in row):
        img.put(" ".join("{" + " ".join(row) + "}" for row in grid))
    else:
        for y, row in enumerate(grid):
            x = 0
            while x < n:
                c = row[x]
                if c:
                    x2 = x
                    while x2 + 1 < n and row[x2 + 1] == c:
                        x2 += 1
                    img.put(c, to=(x, y, x2 + 1, y + 1))
                    x = x2 + 1
                else:
                    x += 1
    return img.zoom(zoom, zoom) if zoom > 1 else img


class SpatialHashGrid:
    def __init__(self, cell_size=80):
        self.cell_size = cell_size
        self.grid = {}

    def clear(self):
        self.grid.clear()

    def insert(self, e):
        key = (int(e.x // self.cell_size), int(e.y // self.cell_size))
        self.grid.setdefault(key, []).append(e)

    def query_radius(self, x, y, radius):
        cs = self.cell_size
        res = []
        r_sq = radius * radius
        for cx in range(int((x - radius) // cs), int((x + radius) // cs) + 1):
            for cy in range(int((y - radius) // cs), int((y + radius) // cs) + 1):
                cell = self.grid.get((cx, cy))
                if cell:
                    for e in cell:
                        if (e.x - x) ** 2 + (e.y - y) ** 2 <= r_sq:
                            res.append(e)
        return res


# ==============================================================================
# 3. GENERADOR PROCEDURAL DE MAZMORRAS (salas con formas, pasillos anchos,
#    erosion organica, pilares, antorchas, decoracion y luz)
# ==============================================================================
TILE_VOID, TILE_FLOOR, TILE_WALL, TILE_DOOR = 0, 1, 2, 3
TILE_STAIRS_DOWN, TILE_SHRINE, TILE_CHEST, TILE_PILLAR = 4, 5, 6, 7
TILE_SECRET = 8   # pared secreta: parece pared, se rompe al atacarla

BIOME_THEMES = {
    1: {"name": "Criptas Azules", "floor": "#2a5478", "floor2": "#244b6c", "wall": "#2f6aa3",
        "top": "#0b1730", "mortar": "#183a58", "accent": "#3aa8ff", "rim": "#4fb4ff"},
    2: {"name": "Cavernas de Magma", "floor": "#4a2420", "floor2": "#3f1e1b", "wall": "#8a3f2f",
        "top": "#1a0a0a", "mortar": "#2a1210", "accent": "#ff6a1f", "rim": "#ff8a4a"},
    3: {"name": "Ruinas Toxicas", "floor": "#244a30", "floor2": "#1e4028", "wall": "#3f8050",
        "top": "#08140c", "mortar": "#12301c", "accent": "#4dff88", "rim": "#6dff9e"},
    4: {"name": "Santuario Abisal", "floor": "#34285a", "floor2": "#2c2150", "wall": "#6a48b8",
        "top": "#0c0818", "mortar": "#1c1438", "accent": "#c04dff", "rim": "#d58cff"},
}


class Room:
    def __init__(self, x, y, w, h, shape):
        self.x, self.y, self.w, self.h, self.shape = x, y, w, h, shape
        self.cx, self.cy = x + w // 2, y + h // 2
        self.cells = [(i, j) for i in range(x, x + w) for j in range(y, y + h) if self._inside(i, j)]

    def _inside(self, i, j):
        dx = (i + 0.5 - (self.x + self.w / 2)) / (self.w / 2)
        dy = (j + 0.5 - (self.y + self.h / 2)) / (self.h / 2)
        if self.shape == "round":
            return dx * dx + dy * dy <= 1.0
        if self.shape == "cross":
            return abs(dx) < 0.4 or abs(dy) < 0.4
        if self.shape == "chamfer":
            return abs(dx) + abs(dy) <= 1.55
        return True


class DungeonMap:
    def __init__(self, floor_level=1, width=60, height=60, tile_size=48):
        self.floor_level = floor_level
        self.width, self.height, self.tile_size = width, height, tile_size
        self.tiles = [[TILE_WALL] * height for _ in range(width)]
        self.revealed = [[False] * height for _ in range(width)]
        self.visible = [[False] * height for _ in range(width)]
        self.var = [[random.randint(0, 3) for _ in range(height)] for _ in range(width)]
        self.light = [[0.0] * height for _ in range(width)]
        self.look = None
        self.vis_list, self.new_revealed = [], []
        self._last_ptile = None
        self.rooms, self.torches, self.deco = [], [], {}
        self.wall_deco, self.secrets, self.rune = {}, {}, None
        self.torch_set = set()
        self.biome_id = min(4, (floor_level - 1) // 3 + 1)
        self.biome = BIOME_THEMES[self.biome_id]
        self._generate()
        self._bake()

    # ---------------------------------------------------------------- generacion
    def _generate(self):
        W, H, T = self.width, self.height, self.tiles
        while True:
            rooms = []
            target = random.randint(9, 13)
            for _ in range(300):
                if len(rooms) >= target:
                    break
                w, h = random.randint(7, 14), random.randint(7, 12)
                x, y = random.randint(2, W - w - 3), random.randint(2, H - h - 3)
                if any(x < r.x + r.w + 3 and x + w + 3 > r.x and y < r.y + r.h + 3 and y + h + 3 > r.y
                       for r in rooms):
                    continue
                rooms.append(Room(x, y, w, h, random.choice(("rect", "rect", "round", "cross", "chamfer"))))
            if len(rooms) >= 6:
                break

        for r in rooms:
            for (i, j) in r.cells:
                T[i][j] = TILE_FLOOR

        # Conexion tipo Prim (siempre conectado) + algunos bucles extra
        connected, rest = [rooms[0]], rooms[1:]
        while rest:
            best = None
            for a in connected:
                for b in rest:
                    d = (a.cx - b.cx) ** 2 + (a.cy - b.cy) ** 2
                    if best is None or d < best[0]:
                        best = (d, a, b)
            _, a, b = best
            self._corridor(a, b)
            connected.append(b)
            rest.remove(b)
        for _ in range(3):
            a, b = random.sample(rooms, 2)
            if (a.cx - b.cx) ** 2 + (a.cy - b.cy) ** 2 < 900:
                self._corridor(a, b)

        # Erosion organica + limpieza de paredes finas / puntas
        cand = [(x, y) for x in range(2, W - 2) for y in range(2, H - 2)
                if T[x][y] == TILE_WALL and random.random() < 0.07 and self._nfloor(x, y) >= 1]
        for x, y in cand:
            T[x][y] = TILE_FLOOR
        for _ in range(3):
            changed = False
            for x in range(1, W - 1):
                for y in range(1, H - 1):
                    if T[x][y] == TILE_WALL:
                        l, r_, u, d = (T[x - 1][y] != TILE_WALL, T[x + 1][y] != TILE_WALL,
                                       T[x][y - 1] != TILE_WALL, T[x][y + 1] != TILE_WALL)
                        if (l + r_ + u + d >= 3) or (l and r_) or (u and d):
                            T[x][y] = TILE_FLOOR
                            changed = True
            if not changed:
                break

        # Spawn en la primera sala, escaleras en la sala mas lejana
        first = rooms[0]
        far = max(rooms[1:], key=lambda r: (r.cx - first.cx) ** 2 + (r.cy - first.cy) ** 2)
        rooms.remove(far)
        rooms.append(far)
        self.rooms = rooms
        self.spawn_pos = (first.cx, first.cy)
        self.stairs_pos = (far.cx, far.cy)
        T[far.cx][far.cy] = TILE_STAIRS_DOWN

        # Pilares en salas grandes
        pillars = []
        for r in rooms[1:]:
            if r.shape == "rect" and r.w >= 10 and r.h >= 9:
                for (px, py) in ((r.x + 2, r.y + 2), (r.x + r.w - 3, r.y + 2),
                                 (r.x + 2, r.y + r.h - 3), (r.x + r.w - 3, r.y + r.h - 3)):
                    if T[px][py] == TILE_FLOOR:
                        T[px][py] = TILE_PILLAR
                        pillars.append((px, py))
        if self.stairs_pos not in self._reachable(self.spawn_pos):
            for (px, py) in pillars:
                T[px][py] = TILE_FLOOR

        # Cofres y santuarios
        for r in rooms[1:-1]:
            dice = random.random()
            free = [c for c in r.cells if T[c[0]][c[1]] == TILE_FLOOR]
            if not free:
                continue
            cx, cy = random.choice(free)
            if dice < 0.45:
                T[cx][cy] = TILE_CHEST
            elif dice < 0.70:
                T[cx][cy] = TILE_SHRINE
                if self.rune is None:
                    self.rune = (cx, cy)

        # Paredes secretas: se rompen atacandolas y esconden una camara con tesoro
        want_secrets = random.randint(1, 2) + (1 if self.floor_level >= 4 else 0)
        pool = rooms[1:-1]
        random.shuffle(pool)
        made = 0
        for r in pool:
            if made >= want_secrets:
                break
            for _ in range(40):
                i, j = random.choice(r.cells)
                if T[i][j] != TILE_FLOOR:
                    continue
                dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)]
                random.shuffle(dirs)
                ok = next((dv for dv in dirs if self._can_chamber(i, j, dv[0], dv[1])), None)
                if ok:
                    self._make_chamber(i, j, ok[0], ok[1])
                    made += 1
                    break

        # Antorchas en paredes frontales + mapa de luz
        for x in range(1, W - 1):
            for y in range(1, H - 2):
                if T[x][y] == TILE_WALL and T[x][y + 1] == TILE_FLOOR and random.random() < 0.10:
                    if all(abs(x - tx) + abs(y - ty) > 5 for tx, ty in self.torches):
                        self.torches.append((x, y))
        self.torch_set = set(self.torches)
        for (tx, ty) in self.torches:
            for x in range(tx - 6, tx + 7):
                for y in range(ty - 6, ty + 7):
                    if 0 <= x < W and 0 <= y < H:
                        v = max(0.0, 1.0 - math.hypot(x - tx, y - (ty + 1)) / 6.0)
                        if v > self.light[x][y]:
                            self.light[x][y] = v

        # Decoracion de paredes (puertas, arcos) y del suelo (barriles, cajas, telaranas...)
        for x in range(2, W - 2):
            for y in range(1, H - 2):
                if (T[x][y] == TILE_WALL and T[x][y + 1] == TILE_FLOOR and (x, y) not in self.torch_set
                        and T[x - 1][y] == TILE_WALL and T[x + 1][y] == TILE_WALL and random.random() < 0.04):
                    self.wall_deco[(x, y)] = random.choice(("door", "door", "arch"))
        for r in rooms:
            for (i, j) in r.cells:
                if T[i][j] != TILE_FLOOR or (i, j) == self.spawn_pos:
                    continue
                wall_n = T[i][j - 1] == TILE_WALL
                roll = random.random()
                if wall_n and T[i - 1][j] == TILE_WALL and roll < 0.55:
                    self.deco[(i, j)] = "web_l"
                elif wall_n and T[i + 1][j] == TILE_WALL and roll < 0.55:
                    self.deco[(i, j)] = "web_r"
                elif wall_n and roll < 0.07:
                    self.deco[(i, j)] = random.choice(("barrel", "crate", "chains", "barrel"))
                elif roll < 0.05:
                    self.deco[(i, j)] = random.choice(("bones", "moss", "crack", "crack"))

    def _can_chamber(self, i, j, dx, dy):
        W, H, T = self.width, self.height, self.tiles
        px, py = dy, dx
        for k in range(1, 6):
            for l in range(-2, 3):
                x, y = i + dx * k + px * l, j + dy * k + py * l
                if not (2 <= x <= W - 3 and 2 <= y <= H - 3) or T[x][y] != TILE_WALL:
                    return False
        return True

    def _make_chamber(self, i, j, dx, dy):
        T = self.tiles
        px, py = dy, dx
        for k in range(2, 5):
            for l in range(-1, 2):
                T[i + dx * k + px * l][j + dy * k + py * l] = TILE_FLOOR
        cx, cy = i + dx * 3, j + dy * 3
        T[cx][cy] = TILE_CHEST
        sx, sy = i + dx, j + dy
        T[sx][sy] = TILE_SECRET
        self.secrets[(sx, sy)] = {"hp": 4, "center": (cx, cy), "hit": False}

    def _nfloor(self, x, y):
        T = self.tiles
        return sum(1 for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)) if T[nx][ny] != TILE_WALL)

    def _corridor(self, a, b):
        wd = random.choice((2, 2, 3))
        if random.random() < 0.5:
            self._carve_h(a.cx, b.cx, a.cy, wd)
            self._carve_v(a.cy, b.cy, b.cx, wd)
        else:
            self._carve_v(a.cy, b.cy, a.cx, wd)
            self._carve_h(a.cx, b.cx, b.cy, wd)

    def _carve_h(self, x1, x2, y, wd):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for k in range(-(wd // 2), wd - (wd // 2)):
                yy = y + k
                if 1 <= x < self.width - 1 and 1 <= yy < self.height - 1:
                    self.tiles[x][yy] = TILE_FLOOR

    def _carve_v(self, y1, y2, x, wd):
        for y in range(min(y1, y2), max(y1, y2) + 1):
            for k in range(-(wd // 2), wd - (wd // 2)):
                xx = x + k
                if 1 <= xx < self.width - 1 and 1 <= y < self.height - 1:
                    self.tiles[xx][y] = TILE_FLOOR

    def _reachable(self, start):
        seen, stack = {start}, [start]
        while stack:
            x, y = stack.pop()
            for n in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if n not in seen and self.is_walkable(n[0], n[1]):
                    seen.add(n)
                    stack.append(n)
        return seen

    def _bake(self):
        self.look = [[None] * self.height for _ in range(self.width)]
        for x in range(self.width):
            for y in range(self.height):
                self._bake_tile(x, y)

    def _solid(self, x, y):
        if not (0 <= x < self.width and 0 <= y < self.height):
            return True
        return self.tiles[x][y] in (TILE_WALL, TILE_SECRET)

    def _bake_tile(self, x, y):
        """Elige el aspecto de cada tile: vacio, cara de pared, tope con borde o piso."""
        v = self.var[x][y]
        S = self._solid
        if self.tiles[x][y] in (TILE_WALL, TILE_SECRET):
            near = any(not S(x + dx, y + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1))
            if not near:
                self.look[x][y] = ("void", 0)
            elif not S(x, y + 1):
                m = (0 if S(x - 1, y) else 1) + (0 if S(x + 1, y) else 2)
                self.look[x][y] = ("wall_face", m + 4 * (v % 2))
            else:
                m = (0 if S(x, y - 1) else 1) + (0 if S(x + 1, y) else 2) + (0 if S(x - 1, y) else 4)
                self.look[x][y] = ("wall_cap", m)
        else:
            sh = y > 0 and S(x, y - 1)
            self.look[x][y] = ("floor_sh", v % 2) if sh else ("floor", v)

    def rebake_around(self, x, y):
        for xx in range(x - 2, x + 3):
            for yy in range(y - 2, y + 3):
                if 0 <= xx < self.width and 0 <= yy < self.height:
                    self._bake_tile(xx, yy)

    # ---------------------------------------------------------------- consultas
    def is_walkable(self, tx, ty):
        if 0 <= tx < self.width and 0 <= ty < self.height:
            t = self.tiles[tx][ty]
            return t not in (TILE_WALL, TILE_PILLAR, TILE_SECRET)
        return False

    def can_move(self, x, y, r):
        ts = self.tile_size
        for ox, oy in ((-r, -r), (r, -r), (-r, r), (r, r)):
            if not self.is_walkable(int((x + ox) // ts), int((y + oy) // ts)):
                return False
        return True

    def compute_fov(self, px, py, radius=9):
        ptx, pty = int(px // self.tile_size), int(py // self.tile_size)
        if (ptx, pty) == self._last_ptile:
            return
        self._last_ptile = (ptx, pty)
        for (x, y) in self.vis_list:
            self.visible[x][y] = False
        self.vis_list = []
        W, H = self.width, self.height
        rays = 120
        for i in range(rays):
            a = i / rays * 2 * math.pi
            dx, dy = math.cos(a) * 0.5, math.sin(a) * 0.5
            cx, cy = ptx + 0.5, pty + 0.5
            for _ in range(radius * 2):
                tx, ty = int(cx), int(cy)
                if not (0 <= tx < W and 0 <= ty < H):
                    break
                if not self.visible[tx][ty]:
                    self.visible[tx][ty] = True
                    self.vis_list.append((tx, ty))
                    if not self.revealed[tx][ty]:
                        self.revealed[tx][ty] = True
                        self.new_revealed.append((tx, ty))
                if self.tiles[tx][ty] in (TILE_WALL, TILE_SECRET):
                    break
                cx += dx
                cy += dy


# ==============================================================================
# 3b. ATLAS DE TEXTURAS (pixel art generado por codigo, con 4 niveles de luz)
# ==============================================================================
class TextureAtlas:
    """Texturas 24x24 (se muestran a 48px) con 4 niveles de luz.
    Estilo: piedra azulada, paredes con borde brillante bien marcado, vacio negro."""
    LEVELS = (1.0, 0.74, 0.52, 0.30)

    def __init__(self, biome_id):
        self.bid = biome_id
        self.b = BIOME_THEMES[biome_id]
        self.grids, self.imgs = {}, {}

    def get(self, kind, var, lvl):
        key = (kind, var, lvl)
        im = self.imgs.get(key)
        if im is None:
            g = self.grids.get((kind, var))
            if g is None:
                g = self.grids[(kind, var)] = self._make(kind, var)
            f = self.LEVELS[lvl]
            sg = [[shade(c, f) if c else None for c in row] for row in g]
            im = self.imgs[key] = to_photo(sg, 24, 2)
        return im

    def prewarm(self):
        for lvl in range(4):
            for v in range(4):
                self.get("floor", v, lvl)
            for v in range(2):
                self.get("floor_sh", v, lvl)
            for v in range(8):
                self.get("wall_face", v, lvl)
                self.get("wall_cap", v, lvl)
            self.get("void", 0, lvl)

    def _make(self, kind, var):
        b = self.b
        rnd = random.Random(var * 7919 + self.bid * 131 + sum(map(ord, kind)))
        g = [[None] * 24 for _ in range(24)]
        st, rim, ac = b["wall"], b["rim"], b["accent"]
        li, da = shade(st, 1.35), shade(st, 0.6)

        if kind in ("floor", "floor_sh"):
            for y in range(24):
                for x in range(24):
                    sx = (x + (6 if (y // 12) % 2 else 0) + var * 3) % 24
                    cell = ((sx // 12) * 31 + (y // 12) * 17 + var * 13) % 5
                    base = b["floor"] if (sx // 12 + y // 12 + var) % 2 == 0 else b["floor2"]
                    f = (0.94 + cell * 0.03) * (1 + (rnd.random() - 0.5) * 0.08)
                    if sx % 12 == 11 or y % 12 == 11:
                        col = shade(b["mortar"], f)
                    else:
                        col = shade(base, f * (1.14 if (sx % 12 == 0 or y % 12 == 0) else 1.0))
                        if sx % 12 == 10 or y % 12 == 10:
                            col = shade(col, 0.88)
                    if kind == "floor_sh" and y < 9:
                        col = shade(col, 0.5 + 0.5 * (y / 9.0))
                    g[y][x] = col

        elif kind == "wall_face":
            mask, bv = var % 4, var // 4
            for y in range(24):
                off = 6 if (y // 6) % 2 else 0
                for x in range(24):
                    bx = (x + off + bv * 5) % 12
                    f = 1 + (rnd.random() - 0.5) * 0.14
                    if y % 6 == 5 or bx == 11:
                        col = shade(b["mortar"], f)
                    else:
                        col = shade(st, f * (1.12 if (bx == 0 or y % 6 == 0) else 1.0))
                    if y >= 20:
                        col = shade(col, 0.78)
                    if rnd.random() < 0.012:
                        col = shade(ac, 0.5)
                    g[y][x] = col
            for x in range(24):           # borde superior brillante bien definido
                g[0][x] = rim
                g[1][x] = shade(rim, 0.82)
                g[2][x] = shade(b["top"], 1.3)
                g[3][x] = shade(b["mortar"], 0.8)
            for y in range(24):           # bordes laterales cuando hay piso al costado
                if mask & 1:
                    g[y][0], g[y][1] = rim, shade(rim, 0.8)
                if mask & 2:
                    g[y][23], g[y][22] = rim, shade(rim, 0.8)

        elif kind == "wall_cap":
            for y in range(24):
                for x in range(24):
                    f = 1 + (rnd.random() - 0.5) * 0.18 + (0.06 if (x // 6 + y // 6) % 2 == 0 else 0)
                    g[y][x] = shade(b["top"], f * 1.55)
            for k in range(24):
                if var & 1:
                    g[0][k], g[1][k], g[2][k] = rim, shade(rim, 0.8), shade(rim, 0.5)
                if var & 2:
                    g[k][23], g[k][22], g[k][21] = rim, shade(rim, 0.8), shade(rim, 0.5)
                if var & 4:
                    g[k][0], g[k][1], g[k][2] = rim, shade(rim, 0.8), shade(rim, 0.5)

        elif kind == "void":
            for y in range(24):
                for x in range(24):
                    g[y][x] = shade(b["top"], 0.5 * (1 + (rnd.random() - 0.5) * 0.16))

        elif kind == "crack_ov":      # grieta que delata una pared secreta
            x = 11
            col, hi = shade(b["top"], 0.6), shade(rim, 0.9)
            for y in range(2, 22):
                _rect(g, x, y, 1, 1, col)
                if y % 3 == 0:
                    _rect(g, x + 1, y, 1, 1, hi)
                x = max(5, min(18, x + rnd.choice((-1, 0, 0, 1))))
            for i in range(6):
                _rect(g, 11 + i, 12 + i // 2, 1, 1, col)

        elif kind == "pillar":
            _rect(g, 5, 19, 14, 4, da)
            _rect(g, 6, 18, 12, 2, st)
            _rect(g, 8, 5, 8, 14, st)
            _rect(g, 8, 5, 2, 14, li)
            _rect(g, 14, 5, 2, 14, da)
            _rect(g, 6, 2, 12, 4, li)
            _rect(g, 6, 5, 12, 1, da)

        elif kind == "torch":
            _rect(g, 11, 12, 2, 8, "#5a4a3a")
            _rect(g, 9, 11, 6, 2, "#2a2f3a")
            mid = shade(ac, 1.5)
            if var == 0:
                _rect(g, 10, 4, 4, 7, ac)
                _rect(g, 11, 2, 2, 3, mid)
                _rect(g, 11, 5, 2, 4, "#eaffff")
            else:
                _rect(g, 10, 5, 4, 6, ac)
                _rect(g, 11, 3, 2, 3, mid)
                _rect(g, 12, 6, 1, 4, "#eaffff")

        elif kind == "stairs":
            g = [["#0a0a12"] * 24 for _ in range(24)]
            for i in range(5):
                y = 2 + i * 4
                col = shade(st, 1.3 - i * 0.22)
                _rect(g, 2 + i, y, 20 - 2 * i, 3, col)
                _rect(g, 2 + i, y, 20 - 2 * i, 1, shade(col, 1.3))
            for k in range(24):
                g[0][k] = g[23][k] = ac
                g[k][0] = g[k][23] = ac

        elif kind == "chest":
            _rect(g, 3, 8, 18, 1, "#2a1a0e")
            _rect(g, 3, 9, 18, 12, "#8a5a2b")
            _rect(g, 3, 9, 18, 5, "#a8702f")
            _rect(g, 3, 13, 18, 1, "#3b2a1a")
            _rect(g, 6, 9, 2, 12, "#9aa0a6")
            _rect(g, 16, 9, 2, 12, "#9aa0a6")
            _rect(g, 11, 12, 3, 4, "#ffd166")
            _rect(g, 3, 21, 18, 1, "#2a1a0e")

        elif kind == "shrine":
            _rect(g, 6, 18, 12, 4, da)
            _rect(g, 8, 16, 8, 3, st)
            for (x, y, w, h) in ((11, 4, 2, 2), (10, 6, 4, 2), (9, 8, 6, 4), (10, 12, 4, 2), (11, 14, 2, 2)):
                _rect(g, x, y, w, h, shade(ac, 1.2))
            _rect(g, 11, 7, 1, 4, "#ffffff")

        elif kind == "bones":
            _rect(g, 5, 15, 7, 1, "#d9d4c7")
            _rect(g, 4, 14, 2, 3, "#d9d4c7")
            _rect(g, 11, 14, 2, 3, "#d9d4c7")
            _rect(g, 14, 11, 5, 4, "#e8e4d8")
            _rect(g, 15, 12, 1, 1, "#111111")
            _rect(g, 17, 12, 1, 1, "#111111")
            _rect(g, 15, 15, 3, 1, "#c9c4b6")

        elif kind == "moss":
            for _ in range(5):
                cx, cy = rnd.randint(3, 20), rnd.randint(3, 20)
                for _k in range(7):
                    _rect(g, cx + rnd.randint(-2, 2), cy + rnd.randint(-2, 2), 2, 2, shade("#3f7a4a", 0.7))

        elif kind == "crack":
            x, y = rnd.randint(4, 10), rnd.randint(1, 4)
            col = shade(b["floor"], 0.5)
            for _ in range(16):
                _rect(g, x, y, 1, 1, col)
                y += 1
                x += rnd.choice((-1, 0, 1, 1))

        elif kind == "barrel":
            _rect(g, 5, 9, 14, 10, "#6b4e2e")
            _rect(g, 6, 7, 12, 15, "#6b4e2e")
            _rect(g, 7, 5, 10, 3, "#8a6a40")
            _rect(g, 8, 5, 8, 1, "#a98353")
            _rect(g, 5, 11, 14, 1, "#2a2f3a")
            _rect(g, 5, 17, 14, 1, "#2a2f3a")
            _rect(g, 8, 8, 1, 13, "#8c6a40")
            _rect(g, 15, 8, 2, 13, "#4a351f")
            _rect(g, 6, 22, 12, 1, "#1d140b")

        elif kind == "crate":
            _rect(g, 4, 8, 16, 14, "#6e5636")
            for i in range(14):
                g[8 + i][4 + i] = "#3d2c18"
                g[8 + i][19 - i] = "#3d2c18"
            _rect(g, 4, 8, 16, 1, "#2a1d10")
            _rect(g, 4, 21, 16, 1, "#2a1d10")
            _rect(g, 4, 8, 1, 14, "#2a1d10")
            _rect(g, 19, 8, 1, 14, "#2a1d10")
            _rect(g, 5, 9, 14, 1, "#8a6c44")

        elif kind in ("web_l", "web_r"):
            pts = set()
            for r in (5, 9, 13):
                for i in range(r + 1):
                    pts.add((i, r - i))
            for i in range(15):
                pts.add((i, 0))
                pts.add((0, i))
            for i in range(11):
                pts.add((i, i))
            for (x, y) in pts:
                if 0 <= x < 24 and 0 <= y < 24:
                    g[y][x if kind == "web_l" else 23 - x] = "#9fb4cc"

        elif kind == "chains":
            for y in range(0, 18):
                _rect(g, 11 + (y % 2), y, 1, 1, "#8e99a6")
            for y in range(0, 18, 3):
                _rect(g, 10, y, 3, 2, "#6b7480")
            _rect(g, 8, 18, 8, 3, "#59616c")
            _rect(g, 9, 18, 6, 1, "#8e99a6")

        elif kind == "door":
            _rect(g, 4, 3, 16, 21, shade(st, 0.55))
            _rect(g, 7, 2, 10, 1, shade(st, 1.2))
            _rect(g, 5, 4, 14, 1, shade(st, 1.4))
            _rect(g, 6, 5, 12, 19, "#4a3322")
            for x in (8, 11, 14, 17):
                _rect(g, x, 5, 1, 19, "#33231a")
            _rect(g, 6, 5, 12, 1, "#5e4330")
            _rect(g, 6, 9, 12, 1, "#252a33")
            _rect(g, 6, 18, 12, 1, "#252a33")
            _rect(g, 10, 12, 4, 5, shade(ac, 0.9))
            _rect(g, 11, 13, 2, 2, "#d8f3ff")
            _rect(g, 11, 15, 2, 1, "#0a1a2a")

        elif kind == "arch":
            _rect(g, 3, 3, 18, 21, shade(st, 1.2))
            _rect(g, 5, 6, 14, 18, "#04060c")
            _rect(g, 7, 4, 10, 3, "#04060c")
            _rect(g, 10, 3, 4, 1, shade(st, 1.5))
        return g


# ==============================================================================
# 3c. HELPERS DE INTERFAZ: paleta piedra + naturaleza oscura, textura de piedra
#     con musgo y marco con scroll (para que entren todas las explicaciones)
# ==============================================================================
UI = {"bg": "#0f120d", "panel": "#171b13", "card": "#1c2117", "row": "#232a1c",
      "moss": "#4d6b35", "moss_d": "#2f4423", "edge": "#3b4533",
      "gold": "#d9b45a", "text": "#d8d2b8", "dim": "#8f9a80",
      "btn": "#2a3322", "btn_a": "#3c4b30", "green": "#7fbf6a"}


def make_stone_image(w, h, seed=1):
    """Textura de bloques de piedra oscura con musgo colgando (PhotoImage w x h)."""
    rnd = random.Random(seed)
    base, moss = "#2b3028", "#3f5a2c"
    rows = []
    for y in range(h):
        off = 11 if (y // 11) % 2 else 0
        row = []
        for x in range(w):
            bx = (x + off) % 22
            f = 1 + (rnd.random() - 0.5) * 0.16
            if y % 11 == 10 or bx == 21:
                col = shade(base, 0.5 * f)
            else:
                col = shade(base, f * (1.18 if (bx == 0 or y % 11 == 0) else 1.0))
            row.append(col)
        rows.append(row)
    for x in range(w):
        top = int(2 + 3 * math.sin(x * 0.21) + 3 * math.sin(x * 0.07 + 1) + rnd.random() * 2.5)
        bot = int(1 + 2 * math.sin(x * 0.33 + 2) + rnd.random() * 2.5)
        for y in range(max(0, min(h, top))):
            rows[y][x] = shade(moss, 0.55 + rnd.random() * 0.6)
        for y in range(h - max(0, bot), h):
            rows[y][x] = shade(moss, 0.4 + rnd.random() * 0.5)
    img = tk.PhotoImage(width=w, height=h)
    img.put(" ".join("{" + " ".join(r) + "}" for r in rows))
    return img


class ScrollFrame(tk.Frame):
    def __init__(self, parent, bg):
        super().__init__(parent, bg=bg)
        self.cv = tk.Canvas(self, bg=bg, highlightthickness=0)
        self.sb = tk.Scrollbar(self, orient="vertical", command=self.cv.yview, width=10)
        self.inner = tk.Frame(self.cv, bg=bg)
        self.win = self.cv.create_window((0, 0), window=self.inner, anchor="nw")
        self.cv.configure(yscrollcommand=self.sb.set)
        self.inner.bind("<Configure>", lambda e: self.cv.configure(scrollregion=self.cv.bbox("all")))
        self.cv.bind("<Configure>", lambda e: self.cv.itemconfigure(self.win, width=e.width))
        self.sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.cv.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)


# ==============================================================================
# 4. OBJETOS Y AFIJOS
# ==============================================================================
RARITY_COLORS = {"Común": "#d0d0d0", "Mágico": "#3a86ff", "Raro": "#ffd166",
                 "Épico": "#8338ec", "Legendario": "#ff5400"}

PREFIXES = [
    ("Feroz", {"phys_dmg": 4}), ("Arcano", {"mag_dmg": 5}), ("Vampírico", {"lifesteal": 0.05}),
    ("Titánico", {"max_hp": 35}), ("Glacial", {"freeze_chance": 0.15}), ("Ígneo", {"burn_dmg": 6}),
    ("Ágil", {"move_speed": 18}), ("Letal", {"crit_chance": 0.08}), ("Impenetrable", {"armor": 8}),
]
SUFFIXES = [
    ("de la Muerte", {"crit_mult": 0.35}), ("del Fénix", {"hp_regen": 3.0}),
    ("de la Tormenta", {"cdr": 0.12}), ("del Berserker", {"phys_dmg": 6, "armor": -2}),
    ("de las Sombras", {"dodge": 0.08}), ("de Maná Eterno", {"max_mp": 30, "mp_regen": 2.0}),
    ("de Voracidad", {"gold_bonus": 0.25}),
]
ITEM_SLOTS = ["Arma", "Armadura", "Casco", "Botas", "Amuleto", "Anillo"]
STAT_NAMES = {"phys_dmg": "Daño físico", "mag_dmg": "Poder mágico", "armor": "Armadura", "max_hp": "Vida máx",
              "max_mp": "Maná máx", "crit_chance": "Prob. crítico", "crit_mult": "Mult. crítico",
              "move_speed": "Velocidad", "lifesteal": "Robo de vida", "hp_regen": "Regen. vida",
              "mp_regen": "Regen. maná", "dodge": "Esquiva", "cdr": "Reduc. cooldown",
              "burn_dmg": "Fuego", "freeze_chance": "Hielo", "gold_bonus": "Oro extra"}


class Item:
    def __init__(self, name, slot, rarity, stats, desc=""):
        self.name, self.slot, self.rarity, self.stats, self.desc = name, slot, rarity, stats, desc
        self.value = 10

    def stat_text(self):
        parts = []
        for k, v in self.stats.items():
            parts.append(f"{STAT_NAMES.get(k, k)} {int(round(v * 100))}%" if isinstance(v, float) and abs(v) < 1.5
                         else f"{STAT_NAMES.get(k, k)} {round(v, 1) if isinstance(v, float) else v}")
        return ", ".join(parts)

    @classmethod
    def generate_random(cls, floor=1):
        slot = random.choice(ITEM_SLOTS)
        r = random.random()
        if r < 0.40: rarity, n_aff = "Común", 0
        elif r < 0.72: rarity, n_aff = "Mágico", 1
        elif r < 0.90: rarity, n_aff = "Raro", 2
        elif r < 0.98: rarity, n_aff = "Épico", 3
        else: rarity, n_aff = "Legendario", 4

        stats, prefix_str, suffix_str = {}, "", ""
        mult = 1.0 + floor * 0.18
        base_name = slot
        if slot == "Arma":
            v = round(random.randint(6, 12) * mult)
            stats["phys_dmg"], stats["mag_dmg"] = v, round(v * 0.8)
            base_name = random.choice(["Espada", "Hacha", "Báculo", "Daga", "Guadaña"])
        elif slot in ("Armadura", "Casco", "Botas"):
            stats["armor"] = round(random.randint(3, 8) * mult)
            stats["max_hp"] = round(random.randint(15, 30) * mult)
        else:
            stats["max_mp"] = round(random.randint(15, 35) * mult)
            stats["crit_chance"] = round(0.03 + floor * 0.005, 3)

        chosen = random.sample(PREFIXES, min(n_aff, len(PREFIXES)))
        if chosen:
            p_name, p_stat = chosen[0]
            prefix_str = p_name + " "
            for k, v in p_stat.items():
                stats[k] = stats.get(k, 0) + (round(v * mult) if isinstance(v, int) else v)
        if n_aff >= 2:
            s_name, s_stat = random.choice(SUFFIXES)
            suffix_str = " " + s_name
            for k, v in s_stat.items():
                stats[k] = stats.get(k, 0) + (round(v * mult) if isinstance(v, int) else v)

        item = cls(f"{prefix_str}{base_name}{suffix_str}".strip(), slot, rarity, stats)
        item.value = int((len(stats) * 15 + floor * 10) * (1.5 if rarity != "Común" else 1.0))
        return item


# ==============================================================================
# 5. ENTIDADES BASICAS
# ==============================================================================
class Particle:
    __slots__ = ('x', 'y', 'vx', 'vy', 'life', 'max_life', 'color', 'size')
    def __init__(self, x, y, vx, vy, life, color, size=3):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.life = self.max_life = life
        self.color, self.size = color, size


class Projectile:
    def __init__(self, x, y, vx, vy, dmg, is_player=True, color="#ffff00", ptype="bolt",
                 radius=5, pierce=1, duration=2.2, crit=False, aoe=0, burn=0.0):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.dmg, self.is_player, self.color, self.ptype = dmg, is_player, color, ptype
        self.radius, self.pierce, self.life = radius, pierce, duration
        self.crit, self.aoe, self.burn = crit, aoe, burn
        self.dead = False
        self.wall_hit = False
        self.hit = set()

    def update(self, dt, dungeon):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt
        if self.life <= 0:
            self.dead = True
        if not dungeon.is_walkable(int(self.x // dungeon.tile_size), int(self.y // dungeon.tile_size)):
            self.dead = True
            self.wall_hit = True


class FloatingText:
    __slots__ = ('x', 'y', 'text', 'color', 'life', 'max_life')
    def __init__(self, x, y, text, color="#ffffff", life=0.9):
        self.x, self.y, self.text, self.color = x, y, text, color
        self.life = self.max_life = life


class Effect:
    """Efectos visuales (tajos, anillos, meteoros, cuchillas giratorias, lineas)."""
    def __init__(self, kind, x, y, life, **kw):
        self.kind, self.x, self.y = kind, x, y
        self.life = self.max = life
        self.__dict__.update(kw)


# ==============================================================================
# 6. JUGADOR Y CLASES  (kit = [(nombre, cooldown, costo_mana)] -> X, C, Z)
# ==============================================================================
CLASS_CONFIGS = {
    "Guerrero": {
        "desc": "Maestro del cuerpo a cuerpo: tajos, terremotos y un torbellino de acero.",
        "hp": 150, "mp": 50, "speed": 160, "armor": 12, "color": "#e63946",
        "kit": [("Tajo", 0.32, 0), ("Golpe Sísmico", 4.0, 10), ("Torbellino Furia", 22.0, 30)],
    },
    "Mago": {
        "desc": "Canalizador arcano: rayos, bolas de fuego y lluvia de meteoros.",
        "hp": 90, "mp": 160, "speed": 150, "armor": 4, "color": "#457b9d",
        "kit": [("Rayo Arcano", 0.30, 0), ("Bola de Fuego", 4.5, 10), ("Lluvia de Meteoros", 24.0, 30)],
    },
    "Pícaro": {
        "desc": "Asesino veloz: dagas, abanico de filos y danza mortal de sombras.",
        "hp": 110, "mp": 80, "speed": 185, "armor": 7, "color": "#2a9d8f",
        "kit": [("Daga", 0.20, 0), ("Abanico de Dagas", 3.5, 10), ("Danza de Cuchillas", 20.0, 30)],
    },
}


class Player:
    def __init__(self, char_class="Guerrero"):
        cfg = CLASS_CONFIGS[char_class]
        self.char_class = char_class
        self.x = self.y = 0.0
        self.radius = 16
        self.color = cfg["color"]
        self.max_hp = cfg["hp"]; self.hp = self.max_hp
        self.max_mp = cfg["mp"]; self.mp = self.max_mp
        self.base_speed, self.base_armor = cfg["speed"], cfg["armor"]
        self.level, self.xp, self.xp_to_next = 1, 0, 60
        self.gold, self.skill_points = 50, 0

        # Stamina / sprint
        self.max_stamina = 100.0
        self.stamina = 100.0
        self.stam_delay = 0.0
        self.exhausted = False
        self.sprinting = False

        # Habilidades X / C / Z
        self.cd = [0.0, 0.0, 0.0]
        self.cd_max = [1.0, 1.0, 1.0]
        self.swing_dir = 1
        self.ult_time = 0.0
        self.ult_tick = 0.0

        # Dash / estados
        self.dash_cd = self.dash_time = 0.0
        self.dash_dx = self.dash_dy = 0.0
        self.invuln = 0.0
        self.hurt = 0.0
        self.anim = 0.0
        self.facing = "R"
        self.moving = False
        self.texts = []

        self.hp_potions, self.mp_potions = 3, 2
        self.equipment = {slot: None for slot in ITEM_SLOTS}
        self.inventory, self.max_inv = [], 16
        self.talents = {"vitalidad": 0, "ferocidad": 0, "celeridad": 0, "vampirismo": 0}
        self.equipment["Arma"] = Item("Espada de Iniciado", "Arma", "Común", {"phys_dmg": 5, "mag_dmg": 4})
        self.equipment["Armadura"] = Item("Túnica Básica", "Armadura", "Común", {"armor": 3, "max_hp": 15})
        self.recalculate_stats()

    def recalculate_stats(self):
        cfg, t = CLASS_CONFIGS[self.char_class], self.talents
        self.max_hp = cfg["hp"] + t["vitalidad"] * 25
        self.max_mp = cfg["mp"]
        self.armor = cfg["armor"]
        self.phys_dmg = 10 + t["ferocidad"] * 4
        self.mag_dmg = 10 + t["ferocidad"] * 4
        self.crit_chance = 0.08 + t["ferocidad"] * 0.02
        self.crit_mult = 1.5 + t["ferocidad"] * 0.1
        self.speed = self.base_speed + t["celeridad"] * 10
        self.cdr = min(0.40, t["celeridad"] * 0.05)
        self.lifesteal = t["vampirismo"] * 0.03
        self.hp_regen = 1.0 + t["vitalidad"] * 0.5
        self.mp_regen = 3.0
        self.dodge = 0.05
        self.max_stamina = 100.0 + t["celeridad"] * 10
        self.burn_dmg, self.freeze_chance, self.gold_bonus = 0, 0.0, 0.0
        for itm in self.equipment.values():
            if itm:
                st = itm.stats
                self.max_hp += st.get("max_hp", 0)
                self.max_mp += st.get("max_mp", 0)
                self.armor += st.get("armor", 0)
                self.phys_dmg += st.get("phys_dmg", 0)
                self.mag_dmg += st.get("mag_dmg", 0)
                self.crit_chance += st.get("crit_chance", 0.0)
                self.crit_mult += st.get("crit_mult", 0.0)
                self.speed += st.get("move_speed", 0)
                self.lifesteal += st.get("lifesteal", 0.0)
                self.hp_regen += st.get("hp_regen", 0.0)
                self.mp_regen += st.get("mp_regen", 0.0)
                self.dodge += st.get("dodge", 0.0)
                self.burn_dmg += st.get("burn_dmg", 0)
                self.freeze_chance += st.get("freeze_chance", 0.0)
                self.gold_bonus += st.get("gold_bonus", 0.0)
                self.cdr = min(0.50, self.cdr + st.get("cdr", 0.0))
        self.hp = min(self.hp, self.max_hp)
        self.mp = min(self.mp, self.max_mp)

    def gain_xp(self, amount):
        self.xp += amount
        leveled = False
        while self.xp >= self.xp_to_next:
            self.xp -= self.xp_to_next
            self.level += 1
            self.skill_points += 1
            self.xp_to_next = int(self.xp_to_next * 1.45)
            leveled = True
            AUDIO.play_sfx("level_up")
        if leveled:
            self.recalculate_stats()
            self.hp, self.mp = self.max_hp, self.max_mp
        return leveled

    def take_damage(self, raw_dmg):
        if self.invuln > 0:
            return 0, True
        if random.random() < self.dodge:
            self.texts.append(("Esquivado", "#a8dadc"))
            return 0, True
        reduction = self.armor / (self.armor + 50)
        dmg = max(1, int(raw_dmg * (1.0 - reduction)))
        self.hp -= dmg
        self.hurt = 0.25
        self.texts.append((f"-{dmg}", "#ff4d6d"))
        AUDIO.play_sfx("hit")
        return dmg, False

    def heal(self, amount):
        self.hp = min(self.max_hp, self.hp + amount)

    def use_hp_potion(self):
        if self.hp_potions > 0 and self.hp < self.max_hp:
            self.hp_potions -= 1
            v = int(self.max_hp * 0.45)
            self.heal(v)
            AUDIO.play_sfx("potion")
            return v
        return 0

    def use_mp_potion(self):
        if self.mp_potions > 0 and self.mp < self.max_mp:
            self.mp_potions -= 1
            self.mp = min(self.max_mp, self.mp + int(self.max_mp * 0.60))
            AUDIO.play_sfx("potion")
            return True
        return False

    def equip_item(self, idx):
        if 0 <= idx < len(self.inventory):
            item = self.inventory.pop(idx)
            old = self.equipment.get(item.slot)
            self.equipment[item.slot] = item
            if old:
                self.inventory.append(old)
            self.recalculate_stats()
            AUDIO.play_sfx("slash")

    def unequip_item(self, slot):
        item = self.equipment.get(slot)
        if item and len(self.inventory) < self.max_inv:
            self.equipment[slot] = None
            self.inventory.append(item)
            self.recalculate_stats()


# ==============================================================================
# 7. ENEMIGOS E IA
# ==============================================================================
ENEMY_ARCHETYPES = {
    "Esqueleto": {"hp": 35, "dmg": 8, "speed": 95, "xp": 15, "ai": "swarmer", "radius": 14},
    "Zombi Pútrido": {"hp": 65, "dmg": 14, "speed": 65, "xp": 22, "ai": "tank", "radius": 17},
    "Arquero Espectral": {"hp": 28, "dmg": 10, "speed": 110, "xp": 25, "ai": "ranger", "radius": 13},
    "Mago de Fuego": {"hp": 40, "dmg": 16, "speed": 90, "xp": 35, "ai": "caster", "radius": 15},
    "Minotauro Brutal": {"hp": 130, "dmg": 24, "speed": 125, "xp": 65, "ai": "charger", "radius": 22},
    "Señor del Abismo (JEFE)": {"hp": 550, "dmg": 28, "speed": 85, "xp": 350, "ai": "boss", "radius": 32},
}


class Enemy:
    def __init__(self, x, y, name, floor=1):
        cfg = ENEMY_ARCHETYPES[name]
        self.name, self.ai = name, cfg["ai"]
        self.x, self.y = float(x), float(y)
        self.radius = cfg["radius"]
        mult = 1.0 + (floor - 1) * 0.22
        self.max_hp = int(cfg["hp"] * mult)
        self.hp = float(self.max_hp)
        self.dmg = int(cfg["dmg"] * mult)
        self.speed = cfg["speed"] + floor * 2
        self.xp_reward = int(cfg["xp"] * mult)
        self.gold_reward = random.randint(5, 12 + floor * 4)
        self.attack_cd = random.uniform(0.2, 1.2)
        self.melee_cd = 0.0
        self.charge_timer = self.windup = 0.0
        self.cdx = self.cdy = 0.0
        self.pattern = 0
        self.casts = 0
        self.dead = False
        self.frozen_time = self.burn_time = 0.0
        self.kvx = self.kvy = 0.0
        self.anim = random.uniform(0, 5)
        self.facing = "R"
        self.moved = False

    def _move(self, mx, my, d):
        r = min(self.radius * 0.6, 20)
        ok = False
        if d.can_move(self.x + mx, self.y, r):
            self.x += mx
            ok = True
        if d.can_move(self.x, self.y + my, r):
            self.y += my
            ok = True
        if ok:
            self.moved = True
        return ok

    def update(self, dt, player, d, projectiles):
        if self.dead:
            return
        self.anim += dt
        if abs(self.kvx) + abs(self.kvy) > 5:
            self._move(self.kvx * dt, self.kvy * dt, d)
            k = max(0.0, 1.0 - 9.0 * dt)
            self.kvx *= k
            self.kvy *= k
        self.moved = False

        if self.burn_time > 0:
            self.burn_time -= dt
            self.hp -= 8 * dt
        if self.frozen_time > 0:
            self.frozen_time -= dt
            return

        self.attack_cd -= dt
        self.melee_cd -= dt
        dx, dy = player.x - self.x, player.y - self.y
        dist = math.hypot(dx, dy)
        if dist > 520 or dist < 0.001:
            return
        ux, uy = dx / dist, dy / dist
        self.facing = "R" if ux >= 0 else "L"
        sp = self.speed * dt
        touch = self.radius + player.radius * 0.8 + 4

        if self.ai in ("swarmer", "tank"):
            if dist > touch:
                self._move(ux * sp, uy * sp, d)
            elif self.attack_cd <= 0:
                player.take_damage(self.dmg)
                self.attack_cd = 1.1

        elif self.ai == "ranger":
            if dist < 180:
                self._move(-ux * sp, -uy * sp, d)
            elif dist > 260:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0 and dist < 360:
                projectiles.append(Projectile(self.x, self.y, ux * 280, uy * 280, self.dmg, False,
                                              "#9ae6ff", "arrow", 4))
                self.attack_cd = 1.8

        elif self.ai == "caster":
            if dist < 210:
                self._move(-ux * sp, -uy * sp, d)
            elif dist > 300:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0 and dist < 380:
                self.casts += 1
                spreads = (-0.25, 0, 0.25) if self.casts % 3 == 0 else (0,)
                a = math.atan2(uy, ux)
                for s in spreads:
                    projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 210, math.sin(a + s) * 210,
                                                  self.dmg, False, "#ff7b00", "orb", 7))
                self.attack_cd = 2.3

        elif self.ai == "charger":
            if self.charge_timer > 0:
                self.charge_timer -= dt
                if not self._move(self.cdx * self.speed * 2.8 * dt, self.cdy * self.speed * 2.8 * dt, d):
                    self.charge_timer = 0
                if dist < touch:
                    player.take_damage(self.dmg * 1.4)
                    self.charge_timer = 0
            elif self.windup > 0:
                self.windup -= dt
                if self.windup <= 0:
                    self.charge_timer = 0.55
            elif dist < 300 and self.attack_cd <= 0:
                self.cdx, self.cdy = ux, uy
                self.windup = 0.55
                self.attack_cd = 3.4
            else:
                self._move(ux * sp * 0.7, uy * sp * 0.7, d)

        elif self.ai == "boss":
            if dist > 110:
                self._move(ux * sp, uy * sp, d)
            if dist < touch + 8 and self.melee_cd <= 0:
                player.take_damage(self.dmg * 1.2)
                self.melee_cd = 1.0
            if self.attack_cd <= 0:
                self.pattern ^= 1
                enraged = self.hp <= self.max_hp * 0.5
                if self.pattern:
                    n = 14 if enraged else 8
                    for b in range(n):
                        a = (b / n) * 2 * math.pi + (self.anim % 3)
                        projectiles.append(Projectile(self.x, self.y, math.cos(a) * 190, math.sin(a) * 190,
                                                      self.dmg, False, "#b5179e", "shard", 6, duration=4.0))
                else:
                    a = math.atan2(uy, ux)
                    for s in ((-0.4, -0.2, 0, 0.2, 0.4) if enraged else (-0.25, 0, 0.25)):
                        projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 270, math.sin(a + s) * 270,
                                                      self.dmg, False, "#e0aaff", "shard", 6, duration=3.0))
                self.attack_cd = 1.6 if enraged else 2.1
                AUDIO.play_sfx("boss_roar")


# ==============================================================================
# 8. SPRITES DE PERSONAJES (pixel art 16x16 generado por codigo, 3 frames de
#    caminata, espejado izq/der, con contorno). Nada de bolitas.
# ==============================================================================
SPRITE_SPECS = {
    "Guerrero": dict(body="#9aa5b8", trim="#e63946", pads="#c1c9d6", leg="#4a4e69", boot="#2b2d42",
                     gear=("helm",), metal="#b8c1cf", plume="#e63946", weapon="sword", blade="#eef2f7",
                     shield="#7f5539", emblem="#ffd166", cape="#a4161a"),
    "Mago": dict(body="#3d5a99", trim="#ffd166", robe="#3d5a99", gear=("wizhat",), hat="#2c4577",
                 beard="#f1f1f1", weapon="staff", orb="#4cc9f0"),
    "Pícaro": dict(body="#2d6a4f", trim="#95d5b2", leg="#1b4332", boot="#081c15", gear=("hood",),
                   hood="#1b4332", mask="#081c15", weapon="dagger", blade="#d8f3dc", cape="#14301f",
                   eye="#d8f3dc"),
    "Esqueleto": dict(skin="#e9ecef", body="#ced4da", ribs="#495057", trim="#adb5bd", leg="#dee2e6",
                      boot="#adb5bd", skull=True, eye="#ff3b3b", weapon="sword", blade="#8d6e63"),
    "Zombi Pútrido": dict(skin="#7aa35a", body="#6b5b45", trim="#3a2e25", leg="#3d405b", boot="#222222",
                          hair="#2b2d1e", armsout=True, eye="#ffee32"),
    "Arquero Espectral": dict(skin="#caf0f8", body="#90e0ef", trim="#00b4d8", robe="#90e0ef",
                              gear=("hood",), hood="#48cae4", weapon="bow", eye="#023e8a"),
    "Mago de Fuego": dict(skin="#e8b88a", body="#c1121f", trim="#ffb703", robe="#c1121f",
                          gear=("flame",), weapon="staff", orb="#ff6d00", eye="#ffffff"),
    "Minotauro Brutal": dict(skin="#7f5539", body="#7f5539", trim="#3d2b1f", pads="#a68a64", leg="#5e3c23",
                             boot="#2b1d12", gear=("horns",), horn="#e9d8a6", snout="#a98467",
                             weapon="axe", eye="#ff2a2a", zoom=4),
    "Señor del Abismo (JEFE)": dict(skin="#9d4edd", body="#240046", trim="#ff006e", pads="#5a189a",
                                    leg="#10002b", boot="#10002b", gear=("horns",), horn="#e0aaff",
                                    wings="#3c096c", weapon="bigsword", blade="#e0aaff", eye="#ffea00", zoom=5),
}


#    MODELOS POLIGONALES ESTILO N64: cada personaje es una malla de cajas
#    (caras planas con sombreado por cara, sin texturas) que se rasteriza por
#    software desde una camara 3/4 elevada. Se pre-renderizan 3 frames de
#    caminata y se espejan para mirar izquierda/derecha.
def _P(faces, cx, y0, cz, w, h, d, col, top=1.0, rx=0.0, rz=0.0, piv=None, emit=False):
    """Agrega una caja (o piramide si top=0) a la malla. y0 = base, rx/rz = inclinacion."""
    hw, hd = w / 2.0, d / 2.0
    tw, td = hw * top, hd * top
    V = [(cx - hw, y0, cz - hd), (cx + hw, y0, cz - hd), (cx + hw, y0, cz + hd), (cx - hw, y0, cz + hd),
         (cx - tw, y0 + h, cz - td), (cx + tw, y0 + h, cz - td), (cx + tw, y0 + h, cz + td), (cx - tw, y0 + h, cz + td)]
    if rx or rz:
        px, py, pz = piv if piv else (cx, y0 + h, cz)
        out = []
        for (x, y, z) in V:
            x, y, z = x - px, y - py, z - pz
            if rx:
                y, z = y * math.cos(rx) - z * math.sin(rx), y * math.sin(rx) + z * math.cos(rx)
            if rz:
                x, y = x * math.cos(rz) - y * math.sin(rz), x * math.sin(rz) + y * math.cos(rz)
            out.append((x + px, y + py, z + pz))
        V = out
    cen = (sum(v[0] for v in V) / 8.0, sum(v[1] for v in V) / 8.0, sum(v[2] for v in V) / 8.0)
    for idx in ((3, 2, 6, 7), (1, 0, 4, 5), (2, 1, 5, 6), (0, 3, 7, 4), (7, 6, 5, 4)):
        faces.append(([V[i] for i in idx], col, cen, emit))


def _fill_poly(g, pts, col):
    n = len(g)
    m = len(pts)
    ys = [p[1] for p in pts]
    for y in range(max(0, int(math.floor(min(ys)))), min(n - 1, int(math.ceil(max(ys)))) + 1):
        yc = y + 0.5
        xs = []
        for i in range(m):
            ax, ay = pts[i]
            bx, by = pts[(i + 1) % m]
            if (ay <= yc < by) or (by <= yc < ay):
                xs.append(ax + (yc - ay) * (bx - ax) / (by - ay))
        if len(xs) >= 2:
            xa = max(0, int(math.ceil(min(xs) - 0.5)))
            xb = min(n - 1, int(math.floor(max(xs) - 0.5)))
            row = g[y]
            for x in range(xa, xb + 1):
                row[x] = col


_LIGHT = (-0.40, 0.78, 0.48)
_LN = math.sqrt(sum(c * c for c in _LIGHT))
_LIGHT = tuple(c / _LN for c in _LIGHT)


def render_model(faces, n, yaw=0.70, pitch=0.42):
    """Rasteriza la malla en una grilla n x n de colores (None = transparente)."""
    S = n / 20.0
    cy_, sy_ = math.cos(yaw), math.sin(yaw)
    cp, sp = math.cos(pitch), math.sin(pitch)

    def tr(x, y, z):
        x1 = x * cy_ + z * sy_
        z1 = -x * sy_ + z * cy_
        return x1, y * cp - z1 * sp, z1 * cp + y * sp

    out = []
    for verts, col, cen, emit in faces:
        (ax, ay, az), (bx, by, bz), (cx, cy, cz) = verts[0], verts[1], verts[2]
        ux, uy, uz, vx, vy, vz = bx - ax, by - ay, bz - az, cx - ax, cy - ay, cz - az
        nx, ny, nz = uy * vz - uz * vy, uz * vx - ux * vz, ux * vy - uy * vx
        ln = math.sqrt(nx * nx + ny * ny + nz * nz)
        if ln < 1e-6:
            continue
        fx = sum(v[0] for v in verts) / 4.0 - cen[0]
        fy = sum(v[1] for v in verts) / 4.0 - cen[1]
        fz = sum(v[2] for v in verts) / 4.0 - cen[2]
        if nx * fx + ny * fy + nz * fz < 0:
            nx, ny, nz = -nx, -ny, -nz
        tx_, tu, td_ = tr(nx / ln, ny / ln, nz / ln)
        if td_ < -0.02:
            continue
        pts = [tr(*v) for v in verts]
        depth = sum(p[2] for p in pts) / 4.0
        lum = 1.0 if emit else 0.38 + 0.80 * max(0.0, tx_ * _LIGHT[0] + tu * _LIGHT[1] + td_ * _LIGHT[2])
        out.append((depth, [(n / 2.0 + p[0] * S, n * 0.94 - p[1] * S) for p in pts], shade(col, lum)))
    out.sort(key=lambda t: t[0])
    g = [[None] * n for _ in range(n)]
    for _, poly, c in out:
        _fill_poly(g, poly, c)
    return g


def build_model(s, f):
    """Arma la malla de un personaje a partir de su SPRITE_SPEC. f: 0 neutro, 1/3 pasos."""
    F = []
    B = lambda *a, **k: _P(F, *a, **k)
    body = s["body"]
    trim = s.get("trim", body)
    skin = s.get("skin", "#e8b88a")
    eye = s.get("eye", "#111111")
    gears = s.get("gear", ())
    boot = s.get("boot", "#1a1a1a")
    swing = {0: 0.0, 1: 0.55, 3: -0.55}[f]

    if s.get("wings"):
        w = s["wings"]
        B(-6.2, 6.5, -2.4, 6.0, 9.0, 0.6, w, top=0.55, rz=0.4, piv=(-3.2, 6.5, -2.4))
        B(6.2, 6.5, -2.4, 6.0, 9.0, 0.6, w, top=0.55, rz=-0.4, piv=(3.2, 6.5, -2.4))
    if s.get("cape"):
        B(0, 3.0, -2.4, 7.0, 8.5, 0.7, s["cape"], top=0.85)

    # piernas / tunica
    if s.get("robe"):
        B(0, 0.0, 0, 9.2, 7.5, 6.4, s["robe"], top=0.62)
        B(-1.6, 0.0, 2.7 - swing, 2.2, 1.2, 2.6, boot)
        B(1.6, 0.0, 2.7 + swing, 2.2, 1.2, 2.6, boot)
    else:
        leg = s.get("leg", "#333333")
        for sx, sw in ((-1.6, swing), (1.6, -swing)):
            B(sx, 1.4, 0, 2.6, 4.2, 2.8, leg, rx=-sw, piv=(sx, 5.6, 0))
            B(sx, 0.0, 0.3, 2.8, 1.5, 3.4, boot, rx=-sw, piv=(sx, 5.6, 0))

    # torso
    B(0, 5.6, 0, 6.4, 5.4, 3.6, body, top=1.06)
    B(0, 5.6, 0, 6.6, 1.0, 3.8, trim)
    if s.get("ribs"):
        for ry in (7.3, 9.0):
            B(0, ry, 1.75, 5.6, 0.5, 0.5, s["ribs"])
        B(0, 5.8, 1.8, 1.0, 5.0, 0.5, "#e9ecef")
    if s.get("pads"):
        B(-4.0, 9.8, 0, 2.8, 1.8, 3.2, s["pads"], top=0.9)
        B(4.0, 9.8, 0, 2.8, 1.8, 3.2, s["pads"], top=0.9)

    # brazos
    sl = s.get("sleeve", skin if (s.get("skull") or s.get("armsout")) else body)
    for sx, a in ((-4.3, swing), (4.3, -swing)):
        if s.get("armsout"):
            a = -1.35
        B(sx, 5.8, 0, 1.9, 4.8, 2.1, sl, rx=a, piv=(sx, 10.6, 0))
        B(sx, 4.6, 0, 1.7, 1.4, 1.9, skin, rx=a, piv=(sx, 10.6, 0))

    # cabeza y cara
    B(0, 10.6, 0.1, 4.8, 4.6, 4.6, skin, top=0.96)
    if s.get("skull"):
        for sx in (-1.1, 1.1):
            B(sx, 12.3, 2.3, 1.3, 1.3, 0.3, "#111111")
            B(sx, 12.5, 2.45, 0.6, 0.6, 0.3, eye, emit=True)
        B(0, 10.9, 2.3, 2.6, 0.6, 0.3, "#adb5bd")
    else:
        for sx in (-1.1, 1.1):
            B(sx, 12.5, 2.3, 0.9, 0.9, 0.3, eye, emit=True)
    if s.get("hair"):
        B(0, 14.6, 0.0, 5.0, 1.0, 4.9, s["hair"])
        B(0, 12.0, -2.2, 4.8, 3.0, 0.8, s["hair"])
    if s.get("beard"):
        B(0, 9.9, 2.1, 3.4, 3.0, 1.2, s["beard"], top=0.8)
    if s.get("mask"):
        B(0, 11.0, 2.35, 4.9, 1.8, 0.3, s["mask"])
    if s.get("snout"):
        B(0, 10.9, 2.9, 2.8, 2.2, 2.2, s["snout"])
        for sx in (-0.7, 0.7):
            B(sx, 11.2, 4.05, 0.5, 0.5, 0.2, "#222222")

    # equipo de cabeza
    if "helm" in gears:
        m = s["metal"]
        B(0, 14.3, 0.1, 5.3, 1.9, 5.2, m)
        for sx in (-2.7, 2.7):
            B(sx, 11.6, 0.1, 0.8, 3.2, 4.2, m)
        B(0, 11.6, 2.5, 0.7, 2.2, 0.4, m)
        B(0, 16.0, -0.6, 0.9, 2.4, 3.4, s["plume"], top=0.6)
    if "wizhat" in gears:
        h = s["hat"]
        B(0, 14.9, 0.1, 9.0, 0.6, 9.0, h)
        B(0, 15.4, 0.1, 5.4, 4.5, 5.4, h, top=0.0, rx=-0.25, piv=(0, 15.4, 0.1))
        B(0, 15.1, 0.1, 5.6, 0.7, 5.6, "#ffd166")
    if "hood" in gears:
        h = s["hood"]
        B(0, 10.4, -1.2, 5.4, 5.3, 3.8, h, top=0.94)
        B(0, 14.6, 0.0, 5.4, 1.2, 5.4, h)
        for sx in (-2.9, 2.9):
            B(sx, 10.8, 0.2, 0.8, 4.4, 4.6, h)
    if "horns" in gears:
        for sgn in (-1, 1):
            B(sgn * 2.8, 13.6, 0.0, 1.5, 3.8, 1.5, s["horn"], top=0.0, rz=-sgn * 0.8, piv=(sgn * 2.8, 13.6, 0.0))
    if "flame" in gears:
        B(0, 14.3, 0.1, 5.0, 0.7, 5.0, "#ff6d00", emit=True)
        for x, hgt, col in ((-1.6, 2.5, "#ff6d00"), (0, 3.6, "#ffd23f"), (1.6, 2.5, "#ff6d00")):
            B(x, 14.9, 0.1, 1.6, hgt, 1.6, col, top=0.0, emit=True)

    # armas y escudo
    w = s.get("weapon")
    if w == "sword":
        B(4.6, 6.0, 0.8, 0.9, 8.5, 0.5, s["blade"], top=0.45, rx=0.4, piv=(4.6, 6.0, 0.8))
        B(4.6, 6.0, 0.8, 3.0, 0.6, 0.8, "#8a5a2b")
        B(4.6, 4.8, 0.8, 0.8, 1.3, 0.8, "#5c3d1e")
    elif w == "bigsword":
        B(4.9, 6.0, 0.8, 1.8, 12.5, 0.8, s["blade"], top=0.5, rx=0.35, piv=(4.9, 6.0, 0.8))
        B(4.9, 6.0, 0.8, 4.4, 0.8, 1.0, "#ff006e")
        B(4.9, 4.4, 0.8, 1.0, 1.8, 1.0, "#5c3d1e")
    elif w == "staff":
        B(5.2, 0.0, 0.8, 0.8, 16.0, 0.8, "#7f5539")
        B(5.2, 16.0, 0.8, 2.2, 2.2, 2.2, s["orb"], top=0.9, emit=True)
        B(5.2, 18.2, 0.8, 1.6, 1.6, 1.6, s["orb"], top=0.0, emit=True)
    elif w == "dagger":
        for sgn in (-1, 1):
            B(sgn * 4.5, 5.9, 1.0, 0.7, 3.8, 0.4, s["blade"], top=0.3, rx=0.9, piv=(sgn * 4.5, 5.9, 1.0))
            B(sgn * 4.5, 5.5, 1.0, 1.3, 0.5, 0.5, "#444444")
    elif w == "bow":
        wood = "#8b5e34"
        B(5.2, 2.5, 0.9, 0.7, 10.0, 0.7, wood)
        B(5.2, 12.4, 0.9, 0.7, 3.0, 0.7, wood, rz=0.5, piv=(5.2, 12.4, 0.9))
        B(5.2, 0.0, 0.9, 0.7, 2.6, 0.7, wood, rz=-0.5, piv=(5.2, 2.6, 0.9))
        B(4.5, 2.2, 0.9, 0.2, 10.2, 0.2, "#dddddd")
    elif w == "axe":
        B(5.0, 2.0, 1.0, 0.9, 11.0, 0.9, "#7f5539")
        B(5.0, 10.0, 1.4, 0.8, 4.0, 3.6, "#adb5bd")
        B(5.0, 10.0, 3.0, 0.5, 4.0, 0.5, "#e9ecef")
    if s.get("shield"):
        B(-5.4, 3.6, 0.9, 0.9, 6.2, 5.0, s["shield"], top=0.9)
        B(-5.95, 5.2, 0.9, 0.4, 2.6, 2.6, s["emblem"])
    return F


def outline_grid(g, col="#0b0b10"):
    n = len(g)
    out = [row[:] for row in g]
    for y in range(n):
        for x in range(n):
            if g[y][x] is None:
                for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < n and 0 <= ny < n and g[ny][nx]:
                        out[y][x] = col
                        break
    return out


class SpriteBank:
    def __init__(self):
        self.imgs, self.preview, self.big = {}, {}, {}
        for name, spec in SPRITE_SPECS.items():
            z = spec.get("zoom", 3)
            n = 16 * z
            d = {}
            for f in (0, 1, 3):
                g = outline_grid(render_model(build_model(spec, f), n))
                d[("R", f)] = to_photo(g, n, 1)
                d[("L", f)] = to_photo([row[::-1] for row in g], n, 1)
            self.imgs[name] = d
            if name in CLASS_CONFIGS:
                m0 = build_model(spec, 0)
                self.preview[name] = to_photo(outline_grid(render_model(m0, 84, yaw=0.5)), 84, 1)
                self.big[name] = to_photo(outline_grid(render_model(m0, 160, yaw=0.45)), 160, 1)

    def get(self, name, facing, frame):
        return self.imgs[name][(facing, frame)]


# ==============================================================================
# 9. MOTOR PRINCIPAL  (parte A: inicializacion, interfaz, entrada y ataques)
# ==============================================================================
SKILL_HELP = {
    "Guerrero": ("Tajo en arco frente a vos. Sin costo; mantenelo apretado para repetirlo.",
                 "Golpe sísmico: daño enorme, empuja y congela 1.2s a los golpeados.",
                 "Torbellino: 2.6s de cuchillas giratorias a tu alrededor. Sos invulnerable y más rápido."),
    "Mago": ("Rayo arcano: proyectil veloz sin costo de maná.",
             "Bola de fuego: explota en área y deja a los enemigos ardiendo.",
             "Lluvia de meteoros: 10 meteoros caen alrededor del objetivo (cursor o autoapuntado)."),
    "Pícaro": ("Daga veloz con +10% de crítico. Sin costo.",
               "Abanico: lanza 7 dagas en abanico; cada una atraviesa a 2 enemigos.",
               "Danza de cuchillas: te teletransportás entre hasta 7 enemigos cercanos con golpes críticos."),
}

SLOT_HELP = {
    "Arma": "Sube tu daño físico y mágico.",
    "Armadura": "Da armadura y vida máxima.",
    "Casco": "Da armadura y vida máxima.",
    "Botas": "Da armadura y vida máxima.",
    "Amuleto": "Da maná máximo y probabilidad de crítico.",
    "Anillo": "Da maná máximo y probabilidad de crítico.",
}

TALENT_HELP = {
    "vitalidad": "+25 vida máxima y +0.5 regeneración de vida por punto.",
    "ferocidad": "+4 daño, +2% crítico y +0.1 de multiplicador crítico por punto.",
    "celeridad": "+10 velocidad, +5% reducción de cooldown y +10 stamina por punto.",
    "vampirismo": "+3% de robo de vida por punto: te curás al herir.",
}

GUIDE_SECTIONS = [
    ("CONTROLES", [
        ("WASD / Flechas", "Moverte por la mazmorra."),
        ("SHIFT (mantener)", "Sprint: +55% velocidad, gasta stamina (barra amarilla). Si llega a 0 quedás sin aliento hasta recuperar."),
        ("ESPACIO", "Dash: esquive corto con invulnerabilidad. Tiene cooldown."),
        ("X o click izq.", "Ataque base. Mantenelo apretado para repetirlo."),
        ("C o click der.", "Ataque fuerte: más daño, con cooldown y algo de maná."),
        ("Z", "ULTIMATE: tu habilidad definitiva, cooldown largo y 30 de maná."),
        ("Q / E", "Poción de vida (cura 45%) / poción de maná (restaura 60%)."),
        ("P", "Activa o desactiva el AUTOAPUNTADO."),
        ("M", "Activa o desactiva la música."),
        ("I · T · G", "Mochila · Talentos · Guía."),
    ]),
    ("AUTOAPUNTADO", [
        ("Cómo funciona", "Con P activado, cada ataque, dash y meteoro va solo hacia el enemigo visible más cercano (hasta 480px). "
                          "Aparece una mira roja sobre el objetivo. Sin enemigos cerca apuntás con el mouse. Con P desactivado apuntás siempre con el mouse."),
    ]),
    ("LA MAZMORRA", [
        ("Escaleras", "Bajan al siguiente piso. Cada 5 pisos hay un jefe que bloquea el descenso. El piso 10 es la victoria."),
        ("Cofres", "Caminá sobre ellos: dan oro y un objeto."),
        ("Santuarios", "Curan vida y maná por completo y regalan una poción de vida. El círculo de runas del suelo marca el altar."),
        ("Paredes secretas", "Algunas paredes tienen una grieta. Atacalas (cuerpo a cuerpo, proyectiles o explosiones) y se rompen, "
                             "revelando una cámara oculta con cofre y botín extra."),
        ("Antorchas", "Iluminan la zona; lejos de ellas todo es más oscuro. Lo explorado queda en el minimapa."),
        ("Pociones y drops", "Los rombos en el suelo son objetos o pociones: caminá sobre ellos para recogerlos."),
    ]),
    ("OBJETOS Y ORO", [
        ("Rareza", "Común (gris), Mágico (azul), Raro (amarillo), Épico (violeta), Legendario (naranja). Más rareza, más bonos."),
        ("Mochila", "Equipá lo que te sirva y vendé el resto por oro."),
        ("Oro", "Se junta con enemigos, cofres y ventas. Cuenta como tu puntaje final."),
    ]),
]

PLAY_STATES = ("PLAYING", "INVENTORY", "TALENTS", "GUIDE")


class GameEngine:
    def __init__(self, root):
        self.root = root
        root.title("Chronicles of Aethelgaard: The Abyssal Citadel")
        root.geometry("1100x720")
        root.configure(bg="#0a0a0f")
        root.resizable(False, False)

        self.view_w, self.view_h = 820, 720
        self.canvas = tk.Canvas(root, width=self.view_w, height=self.view_h, bg="#05050a",
                                highlightthickness=0, cursor="crosshair")
        self.canvas.pack(side=tk.LEFT)
        self.side_panel = tk.Frame(root, width=280, bg="#12131a", highlightthickness=1,
                                   highlightbackground="#2a2c3d")
        self.side_panel.pack(side=tk.RIGHT, fill=tk.Y)
        self.side_panel.pack_propagate(False)

        self.font_huge = tkfont.Font(family="Consolas", size=32, weight="bold")
        self.font_title = tkfont.Font(family="Consolas", size=18, weight="bold")
        self.font_big = tkfont.Font(family="Consolas", size=13, weight="bold")
        self.font_bold = tkfont.Font(family="Consolas", size=11, weight="bold")
        self.font_norm = tkfont.Font(family="Consolas", size=10)
        self.font_small = tkfont.Font(family="Consolas", size=8)

        self.sprites = SpriteBank()
        self.atlas = None
        self.state = "CLASS_SELECT"
        self.floor = 1
        self.player = None
        self.dungeon = None
        self.enemies, self.projectiles, self.particles = [], [], []
        self.floating_texts, self.dropped_items, self.effects = [], [], []
        self.spatial_grid = SpatialHashGrid(80)
        self.keys = {}
        self.mouse_x, self.mouse_y = self.view_w / 2, self.view_h / 2
        self.mouse_down = False
        self.camera_x = self.camera_y = 0.0
        self.cx = self.cy = 0.0
        self.cam_init = True
        self.shake = 0.0
        self.now = time.time()
        self._end_drawn = False
        self._lock_msg = 0.0
        self.mini = None
        self.autoaim, self.auto_target = True, None
        self.scroll, self._view_state, self._stone_img = None, None, None

        root.bind("<KeyPress>", self.on_key_down)
        root.bind("<KeyRelease>", self.on_key_up)
        root.bind("<FocusOut>", lambda e: self.keys.clear())
        root.bind("<MouseWheel>", self.on_wheel)
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<B1-Motion>", self.on_mouse_move)
        self.canvas.bind("<ButtonPress-1>", self.on_left_down)
        self.canvas.bind("<ButtonRelease-1>", self.on_left_up)
        self.canvas.bind("<ButtonPress-3>", self.on_right_click)

        self.build_class_selection_screen()
        MUSIC.play_theme(1)
        self.last_frame_time = time.time()
        self.game_loop()

    # ------------------------------------------------------------------ seleccion
    def make_banner(self, parent, title, sub=""):
        w, h = 264, 56
        if getattr(self, "_stone_img", None) is None:
            self._stone_img = make_stone_image(w, h, 3)
        cv = tk.Canvas(parent, width=w, height=h, highlightthickness=2,
                       highlightbackground=UI["moss_d"], bg=UI["bg"])
        cv.create_image(0, 0, image=self._stone_img, anchor="nw")
        cv.create_text(w / 2 + 1, h / 2 - 5, text=title, fill="#000000", font=self.font_big)
        cv.create_text(w / 2, h / 2 - 6, text=title, fill=UI["gold"], font=self.font_big)
        if sub:
            cv.create_text(w / 2, h / 2 + 14, text=sub, fill=UI["dim"], font=self.font_small)
        pts = []
        for i in range(0, w + 8, 8):
            pts += [i, 5 + 3 * math.sin(i * 0.2)]
        cv.create_line(pts, fill=UI["moss_d"], width=2, smooth=True)
        for i in range(10):
            x, y = 10 + i * 26, 6 + 4 * math.sin(i * 1.7)
            cv.create_oval(x - 4, y - 2, x + 4, y + 3, fill=UI["moss"], outline="")
        return cv

    def _stone_btn(self, parent, text, cmd, **kw):
        return tk.Button(parent, text=text, command=cmd, font=kw.pop("font", self.font_norm), bg=UI["btn"],
                         fg=UI["text"], activebackground=UI["btn_a"], activeforeground=UI["gold"],
                         relief=tk.RIDGE, bd=3, takefocus=0, **kw)

    def build_class_selection_screen(self):
        sp = self.side_panel
        for w in sp.winfo_children():
            w.destroy()
        sp.configure(bg=UI["bg"])
        self.scroll = None
        self.make_banner(sp, "ELIGE TU HÉROE", "La Ciudadela Abisal te espera").pack(padx=8, pady=8)
        for cname, cd in CLASS_CONFIGS.items():
            frame = tk.Frame(sp, bg=UI["card"], bd=3, relief=tk.RIDGE, padx=8, pady=6,
                             highlightthickness=1, highlightbackground=UI["moss_d"])
            frame.pack(fill=tk.X, padx=8, pady=5)
            row = tk.Frame(frame, bg=UI["card"])
            row.pack(fill=tk.X)
            tk.Label(row, image=self.sprites.preview[cname], bg=UI["card"]).pack(side=tk.LEFT)
            info = tk.Frame(row, bg=UI["card"])
            info.pack(side=tk.LEFT, padx=6)
            tk.Label(info, text=cname.upper(), font=self.font_big, fg=cd["color"], bg=UI["card"]).pack(anchor="w")
            tk.Label(info, text=cd["desc"], font=self.font_small, fg=UI["dim"], bg=UI["card"],
                     wraplength=130, justify="left").pack(anchor="w")
            tk.Label(frame, text=f"Vida {cd['hp']} · Maná {cd['mp']} · Vel {cd['speed']} · Arm {cd['armor']}",
                     font=self.font_small, fg=UI["green"], bg=UI["card"]).pack(anchor="w", pady=(4, 0))
            k = cd["kit"]
            tk.Label(frame, text=f"X {k[0][0]}  ·  C {k[1][0]}  ·  Z {k[2][0]}", font=self.font_small,
                     fg=UI["gold"], bg=UI["card"], wraplength=240, justify="left").pack(anchor="w", pady=2)
            self._stone_btn(frame, f"Jugar como {cname}", lambda cn=cname: self.start_game(cn),
                            font=self.font_bold).pack(fill=tk.X, pady=2)

    def start_game(self, char_class):
        self.player = Player(char_class)
        self.floor = 1
        self.keys.clear()
        self.mouse_down = False
        self._end_drawn = False
        self.state = "PLAYING"
        self.load_floor(1)
        self.build_ui_panels()

    # ------------------------------------------------------------------ pisos
    def load_floor(self, n):
        self.floor = n
        self.dungeon = d = DungeonMap(n, 60, 60, 48)
        ts = d.tile_size
        if self.atlas is None or self.atlas.bid != d.biome_id:
            self.atlas = TextureAtlas(d.biome_id)
            self.atlas.prewarm()
        MUSIC.play_theme(d.biome_id)
        self.mini = tk.PhotoImage(width=d.width * 2, height=d.height * 2)
        self.mini.put("#05050a", to=(0, 0, d.width * 2, d.height * 2))

        p = self.player
        p.x = d.spawn_pos[0] * ts + ts / 2
        p.y = d.spawn_pos[1] * ts + ts / 2
        p.invuln = 1.0
        for lst in (self.enemies, self.projectiles, self.particles, self.floating_texts,
                    self.dropped_items, self.effects):
            lst.clear()

        pool = [("Esqueleto", 5), ("Zombi Pútrido", 3)]
        if n >= 2: pool.append(("Arquero Espectral", 3))
        if n >= 3: pool.append(("Mago de Fuego", 2))
        if n >= 4: pool.append(("Minotauro Brutal", 2))
        names, weights = [a for a, _ in pool], [w for _, w in pool]
        boss_floor = (n % 5 == 0)
        for r in d.rooms[1:]:
            cells = [c for c in r.cells if d.tiles[c[0]][c[1]] == TILE_FLOOR]
            if not cells:
                continue
            if boss_floor and r is d.rooms[-1]:
                self.enemies.append(Enemy(r.cx * ts + ts / 2, r.cy * ts + ts / 2, "Señor del Abismo (JEFE)", n))
                for _ in range(3):
                    cx, cy = random.choice(cells)
                    self.enemies.append(Enemy(cx * ts + ts / 2, cy * ts + ts / 2, "Esqueleto", n))
                continue
            for _ in range(random.randint(2, 3 + n // 2)):
                cx, cy = random.choice(cells)
                self.enemies.append(Enemy(cx * ts + ts / 2, cy * ts + ts / 2, random.choices(names, weights)[0], n))

        self.cam_init = True
        d.compute_fov(p.x, p.y, 9)
        self.add_floating_text(p.x, p.y - 40, f"PISO {n}: {d.biome['name'].upper()}", "#ffd166")

    # ------------------------------------------------------------------ panel lateral
    def build_ui_panels(self):
        sp = self.side_panel
        for w in sp.winfo_children():
            w.destroy()
        sp.configure(bg=UI["bg"])
        self.make_banner(sp, "AETHELGAARD", "La Ciudadela Abisal").pack(padx=8, pady=(8, 4))

        pf = tk.Frame(sp, bg=UI["panel"], bd=2, relief=tk.GROOVE, padx=8, pady=4)
        pf.pack(fill=tk.X, padx=8, pady=2)
        self.lbl_hero = tk.Label(pf, text="", font=self.font_big, fg=UI["gold"], bg=UI["panel"])
        self.lbl_hero.pack(anchor="w")
        self.hud_hp = tk.Label(pf, text="", font=self.font_norm, fg="#ff6b81", bg=UI["panel"])
        self.hud_hp.pack(anchor="w")
        self.hud_mp = tk.Label(pf, text="", font=self.font_norm, fg="#5ad1f5", bg=UI["panel"])
        self.hud_mp.pack(anchor="w")
        self.hud_xp = tk.Label(pf, text="", font=self.font_norm, fg=UI["green"], bg=UI["panel"])
        self.hud_xp.pack(anchor="w")
        self.hud_gold = tk.Label(pf, text="", font=self.font_bold, fg=UI["gold"], bg=UI["panel"])
        self.hud_gold.pack(anchor="w", pady=2)

        bar = tk.Frame(sp, bg=UI["bg"])
        bar.pack(fill=tk.X, padx=8, pady=3)
        for i, (txt, cmd) in enumerate((("Héroe", self.show_stats), ("Mochila [I]", self.toggle_inventory),
                                        ("Talentos [T]", self.toggle_talents), ("Guía [G]", self.toggle_guide))):
            self._stone_btn(bar, txt, cmd).grid(row=i // 2, column=i % 2, sticky="ew", padx=2, pady=2)
        bar.grid_columnconfigure(0, weight=1)
        bar.grid_columnconfigure(1, weight=1)

        tk.Label(sp, justify="center", font=self.font_small, fg=UI["dim"], bg=UI["bg"],
                 text=("WASD mover · SHIFT sprint · ESPACIO dash\n"
                       "X base · C fuerte · Z ULTI · Q/E pociones\n"
                       "P autoapuntado · M música · G guía")).pack(side=tk.BOTTOM, pady=5)
        outer = tk.Frame(sp, bg=UI["moss_d"], padx=3, pady=3)
        outer.pack(fill=tk.BOTH, expand=True, padx=8, pady=5)
        self.content_frame = outer
        self.scroll = None
        self._view_state = None
        self.update_content_view()

    def update_content_view(self):
        if not hasattr(self, "content_frame"):
            return
        pos = 0.0
        if self.scroll is not None and self._view_state == self.state:
            try:
                pos = self.scroll.cv.yview()[0]
            except tk.TclError:
                pos = 0.0
        self._view_state = self.state
        for w in self.content_frame.winfo_children():
            w.destroy()
        self.scroll = ScrollFrame(self.content_frame, UI["card"])
        self.scroll.pack(fill=tk.BOTH, expand=True)
        self.cf = self.scroll.inner
        if self.state == "INVENTORY":
            self._render_inventory_view()
        elif self.state == "TALENTS":
            self._render_talents_view()
        elif self.state == "GUIDE":
            self._render_guide_view()
        else:
            self._render_stats_view()
        if pos > 0:
            sc = self.scroll
            self.root.after(40, lambda: self._restore_scroll(sc, pos))

    def _restore_scroll(self, sc, pos):
        try:
            sc.cv.yview_moveto(pos)
        except tk.TclError:
            pass

    def on_wheel(self, event):
        if self.scroll is not None:
            try:
                self.scroll.cv.yview_scroll(int(-event.delta / 120), "units")
            except tk.TclError:
                pass

    # ---- piezas de interfaz
    def _section(self, text, hint=None):
        f = tk.Frame(self.cf, bg=UI["card"])
        f.pack(fill=tk.X, padx=4, pady=(9, 2))
        tk.Label(f, text="» " + text, font=self.font_bold, fg=UI["gold"], bg=UI["card"]).pack(anchor="w")
        tk.Frame(f, bg=UI["moss"], height=2).pack(fill=tk.X)
        if hint:
            tk.Label(f, text=hint, font=self.font_small, fg=UI["dim"], bg=UI["card"], justify="left",
                     wraplength=215).pack(anchor="w", pady=(2, 0))

    def _entry(self, head, help_text="", color=None):
        f = tk.Frame(self.cf, bg=UI["card"])
        f.pack(fill=tk.X, padx=6, pady=2)
        tk.Label(f, text=head, font=self.font_norm, fg=color or UI["text"], bg=UI["card"], justify="left",
                 wraplength=215).pack(anchor="w")
        if help_text:
            tk.Label(f, text=help_text, font=self.font_small, fg=UI["dim"], bg=UI["card"], justify="left",
                     wraplength=215).pack(anchor="w")

    def _render_stats_view(self):
        p = self.player
        cfg = CLASS_CONFIGS[p.char_class]
        self._section("HABILIDADES", "Se usan con X, C y Z. Mantené X apretado para repetir el ataque base.")
        for i, key in enumerate("XCZ"):
            nm, cd, cost = cfg["kit"][i]
            extra = f" · {cost} MP" if cost else " · sin costo"
            self._entry(f"[{key}] {nm}{extra}", SKILL_HELP[p.char_class][i], UI["gold"])
        self._section("ESTADÍSTICAS", "Cada número viene de tu clase + talentos + equipo.")
        rows = [
            ("Daño Físico", f"{p.phys_dmg}", "Potencia de tajos, dagas y torbellino."),
            ("Daño Mágico", f"{p.mag_dmg}", "Potencia de rayos, bolas de fuego y meteoros."),
            ("Armadura", f"{p.armor}", "Reduce el daño recibido (más armadura rinde menos a la larga)."),
            ("Prob. Crítico", f"{int(p.crit_chance * 100)}%", "Chance de que un golpe haga daño extra."),
            ("Mult. Crítico", f"{p.crit_mult:.2f}x", "Cuánto multiplica el daño un crítico."),
            ("Robo de Vida", f"{int(p.lifesteal * 100)}%", "Porcentaje del daño que hacés que te cura."),
            ("Evasión", f"{int(p.dodge * 100)}%", "Chance de esquivar un golpe por completo."),
            ("Reducción CD", f"{int(p.cdr * 100)}%", "Acorta la espera de C, Z y del dash."),
            ("Velocidad", f"{int(p.speed)}", "Qué rápido caminás. SHIFT suma +55% gastando stamina."),
            ("Stamina máx", f"{int(p.max_stamina)}", "Energía para correr; se recarga sola al dejar de correr."),
            ("Regen. Vida", f"{p.hp_regen:.1f}/s", "Vida que recuperás por segundo."),
            ("Regen. Maná", f"{p.mp_regen:.1f}/s", "Maná por segundo; C y Z gastan maná."),
            ("Hielo", f"{int(p.freeze_chance * 100)}%", "Chance de congelar 1s al enemigo golpeado."),
            ("Fuego", f"{p.burn_dmg}", "Si es mayor a 0, tus golpes prenden en llamas al enemigo."),
            ("Oro extra", f"{int(p.gold_bonus * 100)}%", "Más oro por cada enemigo derrotado."),
        ]
        for nm, val, hlp in rows:
            self._entry(f"{nm}: {val}", hlp)
        self._section("POCIONES")
        self._entry(f"Vida [Q]: {p.hp_potions}", "Cura el 45% de tu vida máxima.", "#ff6b81")
        self._entry(f"Maná [E]: {p.mp_potions}", "Restaura el 60% de tu maná máximo.", "#5ad1f5")

    def _render_inventory_view(self):
        p = self.player
        self._section("OBJETOS", "Equipá lo que mejore tus stats y vendé el resto por oro. Color = rareza:")
        leg = tk.Frame(self.cf, bg=UI["card"])
        leg.pack(fill=tk.X, padx=6)
        for rn, rc in RARITY_COLORS.items():
            tk.Label(leg, text=rn, font=self.font_small, fg=rc, bg=UI["card"]).pack(side=tk.LEFT, padx=2)
        self._section("EQUIPO PUESTO")
        for slot, item in p.equipment.items():
            row = tk.Frame(self.cf, bg=UI["row"], bd=1, relief=tk.GROOVE)
            row.pack(fill=tk.X, padx=4, pady=2)
            left = tk.Frame(row, bg=UI["row"])
            left.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=3, pady=2)
            if item:
                tk.Label(left, text=f"{slot}: {item.name}", font=self.font_small, fg=RARITY_COLORS[item.rarity],
                         bg=UI["row"], justify="left", wraplength=150).pack(anchor="w")
                tk.Label(left, text=item.stat_text(), font=self.font_small, fg=UI["dim"], bg=UI["row"],
                         justify="left", wraplength=150).pack(anchor="w")
                self._stone_btn(row, "Quitar", lambda s=slot: self._unequip(s), font=self.font_small).pack(side=tk.RIGHT, padx=3)
            else:
                tk.Label(left, text=f"{slot}: [Vacío]", font=self.font_small, fg="#666d5c", bg=UI["row"]).pack(anchor="w")
                tk.Label(left, text=SLOT_HELP[slot], font=self.font_small, fg=UI["dim"], bg=UI["row"],
                         justify="left", wraplength=190).pack(anchor="w")
        self._section(f"MOCHILA ({len(p.inventory)}/{p.max_inv})", "Los objetos se recogen al caminar sobre ellos.")
        for idx, itm in enumerate(p.inventory):
            row = tk.Frame(self.cf, bg=UI["row"], bd=1, relief=tk.RAISED)
            row.pack(fill=tk.X, padx=4, pady=2)
            left = tk.Frame(row, bg=UI["row"])
            left.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=3, pady=2)
            tk.Label(left, text=f"{itm.name} ({itm.slot})", font=self.font_small, fg=RARITY_COLORS[itm.rarity],
                     bg=UI["row"], justify="left", wraplength=125).pack(anchor="w")
            tk.Label(left, text=itm.stat_text(), font=self.font_small, fg=UI["dim"], bg=UI["row"],
                     justify="left", wraplength=125).pack(anchor="w")
            btns = tk.Frame(row, bg=UI["row"])
            btns.pack(side=tk.RIGHT, padx=2, pady=2)
            self._stone_btn(btns, "Equipar", lambda i=idx: self._equip(i), font=self.font_small).pack(fill=tk.X)
            self._stone_btn(btns, f"Vender {itm.value}g", lambda i=idx: self._sell(i), font=self.font_small).pack(fill=tk.X, pady=(2, 0))
        if not p.inventory:
            self._entry("(vacía)", "Derrotá enemigos y abrí cofres para conseguir objetos.")

    def _render_talents_view(self):
        p = self.player
        self._section(f"TALENTOS (puntos: {p.skill_points})",
                      "Ganás 1 punto por cada nivel. Cada punto mejora para siempre estas estadísticas:")
        for name, pts in p.talents.items():
            row = tk.Frame(self.cf, bg=UI["row"], bd=1, relief=tk.GROOVE)
            row.pack(fill=tk.X, padx=4, pady=3)
            left = tk.Frame(row, bg=UI["row"])
            left.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=3)
            tk.Label(left, text=f"{name.capitalize()}: {pts}", font=self.font_bold, fg=UI["text"], bg=UI["row"]).pack(anchor="w")
            tk.Label(left, text=TALENT_HELP[name], font=self.font_small, fg=UI["dim"], bg=UI["row"],
                     justify="left", wraplength=150).pack(anchor="w")
            if p.skill_points > 0:
                tk.Button(row, text="+", font=self.font_bold, bg=UI["moss"], fg="#0b140a", width=3, takefocus=0,
                          activebackground=UI["green"], relief=tk.RIDGE, bd=3,
                          command=lambda tn=name: self._learn_talent(tn)).pack(side=tk.RIGHT, padx=4)

    def _render_guide_view(self):
        for title, items in GUIDE_SECTIONS:
            self._section(title)
            for head, txt in items:
                self._entry(head, txt, UI["gold"])

    def show_stats(self):
        self.state = "PLAYING"
        self.update_content_view()

    def _equip(self, i): self.player.equip_item(i); self.update_content_view()
    def _unequip(self, s): self.player.unequip_item(s); self.update_content_view()

    def _sell(self, i):
        p = self.player
        if 0 <= i < len(p.inventory):
            p.gold += p.inventory.pop(i).value
            AUDIO.play_sfx("gold")
            self.update_content_view()

    def _learn_talent(self, name):
        p = self.player
        if p.skill_points > 0:
            p.skill_points -= 1
            p.talents[name] += 1
            p.recalculate_stats()
            AUDIO.play_sfx("level_up")
            self.update_content_view()

    def toggle_inventory(self):
        self.state = "PLAYING" if self.state == "INVENTORY" else "INVENTORY"
        self.update_content_view()

    def toggle_talents(self):
        self.state = "PLAYING" if self.state == "TALENTS" else "TALENTS"
        self.update_content_view()

    def toggle_guide(self):
        self.state = "PLAYING" if self.state == "GUIDE" else "GUIDE"
        self.update_content_view()

    def toggle_autoaim(self):
        self.autoaim = not self.autoaim
        p = self.player
        self.add_floating_text(p.x, p.y - 44, "Autoapuntado: " + ("ACTIVADO" if self.autoaim else "DESACTIVADO"), "#ffd166")

    # ------------------------------------------------------------------ autoapuntado
    def _find_target(self):
        p, d = self.player, self.dungeon
        ts = d.tile_size
        best, bd = None, 480.0 ** 2
        for e in self.enemies:
            if e.dead:
                continue
            dd = (e.x - p.x) ** 2 + (e.y - p.y) ** 2
            if dd < bd:
                tx, ty = int(e.x // ts), int(e.y // ts)
                if 0 <= tx < d.width and 0 <= ty < d.height and d.visible[tx][ty]:
                    best, bd = e, dd
        return best

    # ------------------------------------------------------------------ entrada
    def on_key_down(self, event):
        key = event.keysym.lower()
        self.keys[key] = True
        if key == 'm':
            MUSIC.toggle()
        if self.state not in PLAY_STATES or self.player is None:
            return
        if key == 'p': self.toggle_autoaim()
        elif key in ('g', 'h'): self.toggle_guide()
        elif key in ('i', 'tab'): self.toggle_inventory()
        elif key in ('t', 'k'): self.toggle_talents()
        elif key == 'q':
            h = self.player.use_hp_potion()
            if h > 0:
                self.add_floating_text(self.player.x, self.player.y - 20, f"+{h} HP", "#06d6a0")
                self.update_content_view()
        elif key == 'e':
            if self.player.use_mp_potion():
                self.add_floating_text(self.player.x, self.player.y - 20, "+MP", "#4cc9f0")
                self.update_content_view()
        elif key == 'space':
            self.execute_dash()

    def on_key_up(self, event):
        self.keys[event.keysym.lower()] = False

    def on_mouse_move(self, event):
        self.mouse_x, self.mouse_y = event.x, event.y

    def on_left_down(self, event):
        if self.state in ("GAMEOVER", "VICTORY"):
            self.restart_game()
        elif self.state in PLAY_STATES:
            self.mouse_down = True

    def on_left_up(self, event):
        self.mouse_down = False

    def on_right_click(self, event):
        if self.state in PLAY_STATES and self.player.cd[1] <= 0 and self.player.ult_time <= 0:
            self.attack_strong()

    def move_vector(self):
        k = self.keys
        mx = (1 if (k.get('d') or k.get('right')) else 0) - (1 if (k.get('a') or k.get('left')) else 0)
        my = (1 if (k.get('s') or k.get('down')) else 0) - (1 if (k.get('w') or k.get('up')) else 0)
        return mx, my

    def aim(self):
        p = self.player
        tg = self.auto_target
        if self.autoaim and tg is not None and not tg.dead:
            return math.atan2(tg.y - p.y, tg.x - p.x)
        return math.atan2(self.mouse_y + self.camera_y - p.y, self.mouse_x + self.camera_x - p.x)

    # ------------------------------------------------------------------ dash
    def execute_dash(self):
        p = self.player
        if p.dash_cd > 0 or p.ult_time > 0:
            return
        mx, my = self.move_vector()
        if mx == 0 and my == 0:
            a = self.aim()
            mx, my = math.cos(a), math.sin(a)
        else:
            ln = math.hypot(mx, my)
            mx, my = mx / ln, my / ln
        p.dash_dx, p.dash_dy = mx, my
        p.dash_cd = 1.6 * (1.0 - p.cdr)
        p.dash_time = 0.18
        p.invuln = max(p.invuln, 0.22)
        AUDIO.play_sfx("dash")
        for _ in range(8):
            self.particles.append(Particle(p.x, p.y + 10, random.uniform(-60, 60), random.uniform(-60, 60), 0.25, "#8ecae6"))

    # ------------------------------------------------------------------ combate
    def roll(self, base, bonus=0.0):
        p = self.player
        crit = random.random() < p.crit_chance + bonus
        return int(base * (p.crit_mult if crit else 1.0)), crit

    def _pay(self, idx):
        p = self.player
        _, cd, cost = CLASS_CONFIGS[p.char_class]["kit"][idx]
        if p.mp < cost:
            self.add_floating_text(p.x, p.y - 34, "Sin maná", "#4cc9f0")
            p.cd[idx] = p.cd_max[idx] = 0.5
            return False
        p.mp -= cost
        p.cd[idx] = p.cd_max[idx] = cd * (1.0 - p.cdr) if idx > 0 else cd
        return True

    def cone_targets(self, x, y, ang, rng, half):
        out = []
        for e in self.spatial_grid.query_radius(x, y, rng + 40):
            if e.dead:
                continue
            dx, dy = e.x - x, e.y - y
            dist = math.hypot(dx, dy)
            if dist - e.radius > rng:
                continue
            if dist < e.radius + 8:
                out.append(e)
                continue
            da = math.atan2(dy, dx) - ang
            if abs(math.atan2(math.sin(da), math.cos(da))) <= half:
                out.append(e)
        return out

    def _shoot(self, ang, speed, dmg, crit, color, ptype, radius, pierce=1, aoe=0, burn=0.0, dur=1.8):
        p = self.player
        self.projectiles.append(Projectile(p.x + math.cos(ang) * 20, p.y + math.sin(ang) * 20,
                                           math.cos(ang) * speed, math.sin(ang) * speed, dmg, True,
                                           color, ptype, radius, pierce, dur, crit, aoe, burn))

    # ---- X : ataque base (spameable) -------------------------------------------
    def attack_base(self):
        p, ang = self.player, self.aim()
        self._pay(0)
        if p.char_class == "Guerrero":
            AUDIO.play_sfx("slash")
            self.hit_secret_walls(p.x, p.y, ang, 88, 1.05, 1)
            for e in self.cone_targets(p.x, p.y, ang, 88, 1.05):
                dmg, cr = self.roll(p.phys_dmg)
                self.damage_enemy(e, dmg, cr, kb=150, src=(p.x, p.y))
            p.swing_dir *= -1
            self.effects.append(Effect("arc", p.x, p.y, 0.2, ang=ang, r=62, span=2.1, width=10,
                                       color="#ffffff", dir=p.swing_dir))
        elif p.char_class == "Mago":
            AUDIO.play_sfx("fireball")
            dmg, cr = self.roll(p.mag_dmg)
            self._shoot(ang, 520, dmg, cr, "#4cc9f0", "bolt", 6, dur=1.6)
        else:
            AUDIO.play_sfx("slash")
            dmg, cr = self.roll(p.phys_dmg * 0.8, 0.10)
            self._shoot(ang + random.uniform(-0.04, 0.04), 640, dmg, cr, "#d8f3dc", "dagger", 5, dur=1.4)

    # ---- C : ataque fuerte (cooldown) ------------------------------------------
    def attack_strong(self):
        p, ang = self.player, self.aim()
        if not self._pay(1):
            return
        if p.char_class == "Guerrero":
            AUDIO.play_sfx("heavy")
            self.hit_secret_walls(p.x, p.y, ang, 135, 0.95, 2)
            for e in self.cone_targets(p.x, p.y, ang, 135, 0.95):
                dmg, cr = self.roll(p.phys_dmg * 2.4)
                self.damage_enemy(e, dmg, cr, kb=320, src=(p.x, p.y))
                e.frozen_time = max(e.frozen_time, 1.2)
            self.effects.append(Effect("arc", p.x, p.y, 0.35, ang=ang, r=105, span=1.9, width=18,
                                       color="#ffb703", dir=1))
            self.effects.append(Effect("ring", p.x + math.cos(ang) * 80, p.y + math.sin(ang) * 80, 0.35,
                                       r=70, color="#ffb703"))
            for _ in range(16):
                a = ang + random.uniform(-0.9, 0.9)
                s = random.uniform(60, 220)
                self.particles.append(Particle(p.x, p.y + 12, math.cos(a) * s, math.sin(a) * s, 0.4, "#c9b79c", 4))
            self.shake = max(self.shake, 0.25)
        elif p.char_class == "Mago":
            AUDIO.play_sfx("fireball")
            dmg, cr = self.roll(p.mag_dmg * 2.6)
            self._shoot(ang, 380, dmg, cr, "#fb8500", "fireball", 10, aoe=95, burn=3.0, dur=2.2)
        else:
            AUDIO.play_sfx("slash")
            for i in range(7):
                dmg, cr = self.roll(p.phys_dmg * 1.0)
                self._shoot(ang + (i - 3) * 0.14, 600, dmg, cr, "#d8f3dc", "dagger", 5, pierce=2, dur=1.2)

    # ---- Z : ULTIMATE -----------------------------------------------------------
    def attack_ult(self):
        p, d = self.player, self.dungeon
        if p.char_class == "Guerrero":
            if not self._pay(2): return
            p.ult_time, p.ult_tick = 2.6, 0.0
            self.effects.append(Effect("spin", p.x, p.y, 2.6))
        elif p.char_class == "Mago":
            if not self._pay(2): return
            at = self.auto_target
            if self.autoaim and at is not None and not at.dead:
                tx, ty = at.x, at.y
            else:
                tx, ty = self.mouse_x + self.camera_x, self.mouse_y + self.camera_y
            for i in range(10):
                a = random.uniform(0, 2 * math.pi)
                rr = 170 * math.sqrt(random.random())
                delay = 0.35 + i * 0.19 + random.uniform(0, 0.1)
                self.effects.append(Effect("meteor", tx + math.cos(a) * rr, ty + math.sin(a) * rr, delay,
                                           r=78, dmg=int(p.mag_dmg * 3.4)))
        else:
            near = [e for e in self.enemies if not e.dead and math.hypot(e.x - p.x, e.y - p.y) < 400]
            if not near:
                self.add_floating_text(p.x, p.y - 34, "Sin objetivos", "#adb5bd")
                p.cd[2] = p.cd_max[2] = 0.5
                return
            if not self._pay(2): return
            cur, order = (p.x, p.y), []
            for _ in range(7):
                if not near: break
                nxt = min(near, key=lambda e: (e.x - cur[0]) ** 2 + (e.y - cur[1]) ** 2)
                near.remove(nxt)
                order.append(nxt)
                cur = (nxt.x, nxt.y)
            for e in order:
                ox, oy = p.x, p.y
                a = math.atan2(e.y - p.y, e.x - p.x)
                nx, ny = e.x - math.cos(a) * 28, e.y - math.sin(a) * 28
                if d.can_move(nx, ny, p.radius * 0.6):
                    p.x, p.y = nx, ny
                self.effects.append(Effect("line", ox, oy, 0.35, x2=p.x, y2=p.y, color="#b7e4c7"))
                self.damage_enemy(e, int(p.phys_dmg * 3.0 * p.crit_mult), True, kb=120, src=(ox, oy))
            p.invuln = max(p.invuln, 0.8)
        AUDIO.play_sfx("ult")
        self.shake = max(self.shake, 0.25)

    # ---- dano / muerte / explosiones ---------------------------------------------
    def damage_enemy(self, e, amount, crit=False, kb=0, src=None):
        if e.dead:
            return
        e.hp -= amount
        self.add_floating_text(e.x + random.randint(-8, 8), e.y - e.radius - 10,
                               f"{amount}!" if crit else str(amount), "#ffd166" if crit else "#ffffff")
        AUDIO.play_sfx("crit" if crit else "hit")
        for _ in range(4):
            self.particles.append(Particle(e.x, e.y, random.uniform(-80, 80), random.uniform(-80, 80), 0.3, "#ba181b", 3))
        if kb > 0 and src:
            dx, dy = e.x - src[0], e.y - src[1]
            dd = math.hypot(dx, dy) or 1.0
            k = kb * (14.0 / e.radius) * (0.3 if e.ai == "boss" else 1.0)
            e.kvx += dx / dd * k
            e.kvy += dy / dd * k
        p = self.player
        if p.freeze_chance > 0 and random.random() < p.freeze_chance:
            e.frozen_time = max(e.frozen_time, 1.0)
        if p.burn_dmg > 0:
            e.burn_time = max(e.burn_time, 2.0)
        if p.lifesteal > 0:
            leech = int(amount * p.lifesteal)
            if leech > 0:
                p.heal(leech)
        if e.hp <= 0:
            self.kill_enemy(e)

    def kill_enemy(self, e):
        if e.dead:
            return
        e.dead = True
        p = self.player
        gg = int(e.gold_reward * (1.0 + p.gold_bonus))
        p.gold += gg
        self.add_floating_text(e.x, e.y - 30, f"+{gg}g", "#ffd166")
        if p.gain_xp(e.xp_reward):
            self.add_floating_text(p.x, p.y - 50, "¡NIVEL SUBIDO!", "#06d6a0")
            self.update_content_view()
        for _ in range(10):
            self.particles.append(Particle(e.x, e.y, random.uniform(-120, 120), random.uniform(-120, 120), 0.5,
                                           random.choice(("#e9ecef", "#ba181b", "#6c757d")), 4))
        r = random.random()
        if e.ai == "boss":
            for _ in range(2):
                self.dropped_items.append((e.x + random.randint(-30, 30), e.y + random.randint(-30, 30),
                                           Item.generate_random(self.floor + 2)))
            self.add_floating_text(e.x, e.y, "¡JEFE DERROTADO!", "#ff5400")
            AUDIO.play_sfx("boss_roar")
            self.shake = 0.4
        elif r < 0.35:
            self.dropped_items.append((e.x, e.y, Item.generate_random(self.floor)))
        elif r < 0.47:
            self.dropped_items.append((e.x, e.y, random.choice(("hp", "hp", "mp"))))

    def explode(self, x, y, r, dmg, burn=0.0):
        AUDIO.play_sfx("meteor" if r >= 70 else "crit")
        tsz = self.dungeon.tile_size
        for (sx, sy) in list(self.dungeon.secrets.keys()):
            if math.hypot(sx * tsz + tsz / 2 - x, sy * tsz + tsz / 2 - y) <= r + tsz * 0.7:
                self.hit_secret(sx, sy, 2)
        for e in self.spatial_grid.query_radius(x, y, r + 34):
            if not e.dead and math.hypot(e.x - x, e.y - y) - e.radius <= r:
                self.damage_enemy(e, dmg, True, kb=220, src=(x, y))
                if burn:
                    e.burn_time = max(e.burn_time, burn)
        self.effects.append(Effect("ring", x, y, 0.4, r=r, color="#ff8c1a"))
        for _ in range(14):
            a, s = random.uniform(0, 6.283), random.uniform(60, 240)
            self.particles.append(Particle(x, y, math.cos(a) * s, math.sin(a) * s, 0.45,
                                           random.choice(("#ff8c1a", "#ffd23f", "#ff4d00")), 4))
        self.shake = max(self.shake, 0.18)

    # ---- paredes secretas ----------------------------------------------------------
    def hit_secret_walls(self, x, y, ang, rng, half, power=1):
        d = self.dungeon
        if not d.secrets:
            return
        ts = d.tile_size
        for (sx, sy) in list(d.secrets.keys()):
            dx, dy = sx * ts + ts / 2 - x, sy * ts + ts / 2 - y
            dist = math.hypot(dx, dy)
            if dist > rng + ts * 0.5:
                continue
            if dist > ts * 1.1:
                da = math.atan2(dy, dx) - ang
                if abs(math.atan2(math.sin(da), math.cos(da))) > half:
                    continue
            self.hit_secret(sx, sy, power)

    def hit_secret(self, sx, sy, power=1):
        d = self.dungeon
        info = d.secrets.get((sx, sy))
        if not info:
            return
        ts = d.tile_size
        wx, wy = sx * ts + ts / 2, sy * ts + ts / 2
        info["hp"] -= power
        for _ in range(7):
            a, s = random.uniform(0, 6.283), random.uniform(40, 170)
            self.particles.append(Particle(wx, wy, math.cos(a) * s, math.sin(a) * s, 0.5,
                                           random.choice(("#6f7f99", "#4a5870", "#9aa8bd")), 4))
        AUDIO.play_sfx("heavy")
        self.shake = max(self.shake, 0.1)
        if info["hp"] > 0:
            if not info["hit"]:
                info["hit"] = True
                self.add_floating_text(wx, wy - 30, "¡La pared se agrieta!", "#9bd0ff")
            return
        del d.secrets[(sx, sy)]
        d.tiles[sx][sy] = TILE_FLOOR
        d.rebake_around(sx, sy)
        d._last_ptile = None
        d.new_revealed.append((sx, sy))
        AUDIO.play_sfx("secret")
        self.shake = max(self.shake, 0.3)
        self.effects.append(Effect("ring", wx, wy, 0.5, r=80, color="#9bd0ff"))
        for _ in range(24):
            a, s = random.uniform(0, 6.283), random.uniform(60, 260)
            self.particles.append(Particle(wx, wy, math.cos(a) * s, math.sin(a) * s, 0.7,
                                           random.choice(("#6f7f99", "#4a5870", "#9aa8bd", "#ffd166")), 5))
        self.add_floating_text(wx, wy - 40, "¡PARED SECRETA!", "#ffd166")
        cx, cy = info["center"]
        bx, by = cx * ts + ts / 2, cy * ts + ts / 2
        self.dropped_items.append((bx - 14, by + 6, Item.generate_random(self.floor + 2)))
        self.dropped_items.append((bx + 14, by + 6, "hp"))

    def add_floating_text(self, x, y, text, color="#fff"):
        self.floating_texts.append(FloatingText(x, y, text, color))


    # ==========================================================================
    # PARTE B: bucle, simulacion, render, HUD
    # ==========================================================================
    def game_loop(self):
        now = time.time()
        dt = min(0.05, now - self.last_frame_time)
        self.last_frame_time = now
        self.now = now
        if self.state in PLAY_STATES:
            self.update_simulation(dt)
            if self.state in PLAY_STATES:
                self.render()
        elif self.state == "CLASS_SELECT":
            self.render_title()
        elif not self._end_drawn:
            self._end_drawn = True
            self.render_game_over() if self.state == "GAMEOVER" else self.render_victory()
        self.root.after(16, self.game_loop)

    def _set(self, lbl, txt):
        if lbl.cget("text") != txt:
            lbl.config(text=txt)

    def update_simulation(self, dt):
        p, d = self.player, self.dungeon
        ts = d.tile_size
        keys = self.keys

        self.spatial_grid.clear()
        for e in self.enemies:
            if not e.dead:
                self.spatial_grid.insert(e)

        self.auto_target = self._find_target() if self.autoaim else None

        # --- timers y regeneracion
        for i in range(3):
            if p.cd[i] > 0: p.cd[i] -= dt
        if p.dash_cd > 0: p.dash_cd -= dt
        if p.invuln > 0: p.invuln -= dt
        if p.hurt > 0: p.hurt -= dt
        p.heal(p.hp_regen * dt)
        p.mp = min(p.max_mp, p.mp + p.mp_regen * dt)

        # --- movimiento: caminar / SPRINT / dash
        mx, my = self.move_vector()
        p.moving = bool(mx or my)
        sprint = keys.get('shift_l') or keys.get('shift_r')
        p.sprinting = False
        vx = vy = 0.0
        spd = p.speed * (1.2 if p.ult_time > 0 else 1.0)
        if p.dash_time > 0:
            p.dash_time -= dt
            vx, vy = p.dash_dx * p.speed * 3.2 * dt, p.dash_dy * p.speed * 3.2 * dt
        elif p.moving:
            ln = math.hypot(mx, my)
            if sprint and not p.exhausted and p.stamina > 0:
                p.sprinting = True
                spd *= 1.55
                p.stamina -= 32 * dt
                p.stam_delay = 0.6
                if p.stamina <= 0:
                    p.stamina, p.exhausted = 0.0, True
            vx, vy = mx / ln * spd * dt, my / ln * spd * dt
        if not p.sprinting:
            if p.stam_delay > 0:
                p.stam_delay -= dt
            else:
                p.stamina = min(p.max_stamina, p.stamina + 24 * dt)
            if p.exhausted and p.stamina >= 25:
                p.exhausted = False
        rp = p.radius * 0.6
        if vx or vy:
            if d.can_move(p.x + vx, p.y, rp): p.x += vx
            if d.can_move(p.x, p.y + vy, rp): p.y += vy
        if p.sprinting and random.random() < 0.5:
            self.particles.append(Particle(p.x, p.y + 20, random.uniform(-20, 20), random.uniform(-25, -5), 0.3, "#8d8d99", 3))
        p.facing = "R" if math.cos(self.aim()) >= 0 else "L"
        p.anim += dt * (1.7 if p.sprinting else 1.0)

        # --- ataques X / C / Z (mantener para repetir)
        if p.ult_time <= 0:
            if (keys.get('x') or self.mouse_down) and p.cd[0] <= 0: self.attack_base()
            if keys.get('c') and p.cd[1] <= 0: self.attack_strong()
            if keys.get('z') and p.cd[2] <= 0: self.attack_ult()
        else:
            p.ult_time -= dt
            p.ult_tick -= dt
            p.invuln = max(p.invuln, 0.1)
            if p.ult_tick <= 0:
                p.ult_tick = 0.11
                AUDIO.play_sfx("slash")
                self.hit_secret_walls(p.x, p.y, 0, 125, 4.0, 1)
                for e in self.spatial_grid.query_radius(p.x, p.y, 150):
                    if not e.dead and math.hypot(e.x - p.x, e.y - p.y) - e.radius <= 120:
                        dmg, cr = self.roll(p.phys_dmg * 0.9)
                        self.damage_enemy(e, dmg, cr, kb=170, src=(p.x, p.y))

        # --- interacciones con el mapa
        ptx, pty = int(p.x // ts), int(p.y // ts)
        t = d.tiles[ptx][pty]
        if t == TILE_STAIRS_DOWN:
            if any(e.ai == "boss" and not e.dead for e in self.enemies):
                if self.now - self._lock_msg > 2:
                    self._lock_msg = self.now
                    self.add_floating_text(p.x, p.y - 40, "¡Derrota al jefe para descender!", "#ff5400")
            elif self.floor >= 10:
                self.state = "VICTORY"
                MUSIC.stop()
                AUDIO.play_sfx("level_up")
                return
            else:
                self.load_floor(self.floor + 1)
                AUDIO.play_sfx("dash")
                return
        elif t == TILE_CHEST:
            d.tiles[ptx][pty] = TILE_FLOOR
            AUDIO.play_sfx("gold")
            g = random.randint(25, 60 + self.floor * 15)
            p.gold += g
            self.dropped_items.append((p.x, p.y, Item.generate_random(self.floor)))
            self.add_floating_text(p.x, p.y - 30, f"+{g} Oro  ¡Cofre abierto!", "#ffd166")
        elif t == TILE_SHRINE:
            d.tiles[ptx][pty] = TILE_FLOOR
            p.heal(p.max_hp)
            p.mp = p.max_mp
            p.hp_potions += 1
            AUDIO.play_sfx("level_up")
            self.add_floating_text(p.x, p.y - 30, "¡SANTUARIO BENDITO!", "#4cc9f0")
            self.update_content_view()

        kept = []
        for ix, iy, obj in self.dropped_items:
            if math.hypot(p.x - ix, p.y - iy) < 32:
                if isinstance(obj, str):
                    if obj == "hp": p.hp_potions += 1
                    else: p.mp_potions += 1
                    AUDIO.play_sfx("potion")
                    self.add_floating_text(p.x, p.y - 35, "+Poción " + obj.upper(), "#ff4d6d" if obj == "hp" else "#4cc9f0")
                    self.update_content_view()
                    continue
                if len(p.inventory) < p.max_inv:
                    p.inventory.append(obj)
                    AUDIO.play_sfx("slash")
                    self.add_floating_text(p.x, p.y - 35, f"+{obj.name}", RARITY_COLORS[obj.rarity])
                    self.update_content_view()
                    continue
            kept.append((ix, iy, obj))
        self.dropped_items = kept

        d.compute_fov(p.x, p.y, 9)

        # --- enemigos
        near = []
        for e in self.enemies:
            if abs(e.x - p.x) < 700 and abs(e.y - p.y) < 700:
                e.update(dt, p, d, self.projectiles)
                near.append(e)
                if e.burn_time > 0 and random.random() < 0.25:
                    self.particles.append(Particle(e.x, e.y - 6, random.uniform(-15, 15), -50, 0.35, "#ff8c1a", 3))
        for e in near:
            if e.dead or e.ai == "boss":
                continue
            for o in self.spatial_grid.query_radius(e.x, e.y, e.radius * 1.5):
                if o is e or o.dead:
                    continue
                dx, dy = e.x - o.x, e.y - o.y
                dd = math.hypot(dx, dy)
                if dd < 0.01:
                    dx, dy, dd = random.uniform(-1, 1), random.uniform(-1, 1), 1.0
                push = (e.radius + o.radius) * 0.8 - dd
                if push > 0:
                    e._move(dx / dd * push * 0.15, dy / dd * push * 0.15, d)
        for e in self.enemies:
            if e.hp <= 0 and not e.dead:
                self.kill_enemy(e)
        self.enemies = [e for e in self.enemies if not e.dead]

        # --- proyectiles
        for pr in self.projectiles:
            pr.update(dt, d)
            if pr.ptype == "fireball" and random.random() < 0.6:
                self.particles.append(Particle(pr.x, pr.y, random.uniform(-30, 30), random.uniform(-30, 30), 0.3,
                                               random.choice(("#ff8c1a", "#ffd23f")), 4))
            if pr.dead:
                if pr.wall_hit and pr.is_player and pr.aoe <= 0:
                    wsx, wsy = int(pr.x // ts), int(pr.y // ts)
                    if (wsx, wsy) in d.secrets:
                        self.hit_secret(wsx, wsy, 1)
                if pr.aoe > 0 and pr.is_player:
                    self.explode(pr.x, pr.y, pr.aoe, pr.dmg, pr.burn)
                continue
            if pr.is_player:
                for e in self.spatial_grid.query_radius(pr.x, pr.y, pr.radius + 40):
                    if e.dead or id(e) in pr.hit:
                        continue
                    if math.hypot(e.x - pr.x, e.y - pr.y) > pr.radius + e.radius:
                        continue
                    if pr.aoe > 0:
                        self.explode(pr.x, pr.y, pr.aoe, pr.dmg, pr.burn)
                        pr.dead = True
                        break
                    self.damage_enemy(e, pr.dmg, pr.crit, kb=90, src=(pr.x - pr.vx * 0.05, pr.y - pr.vy * 0.05))
                    pr.hit.add(id(e))
                    pr.pierce -= 1
                    if pr.pierce <= 0:
                        pr.dead = True
                        break
            elif math.hypot(p.x - pr.x, p.y - pr.y) < p.radius * 0.8 + pr.radius:
                p.take_damage(pr.dmg)
                pr.dead = True
                for _ in range(4):
                    self.particles.append(Particle(pr.x, pr.y, random.uniform(-60, 60), random.uniform(-60, 60), 0.25, pr.color, 3))
        self.projectiles = [pr for pr in self.projectiles if not pr.dead]

        # --- efectos (meteoros, cuchillas)
        for ef in list(self.effects):
            ef.life -= dt
            if ef.kind == "spin":
                ef.x, ef.y = p.x, p.y
            elif ef.kind == "meteor" and ef.life <= 0:
                self.explode(ef.x, ef.y, ef.r, ef.dmg, 2.5)
        self.effects = [ef for ef in self.effects if ef.life > 0]

        for pt in self.particles:
            pt.x += pt.vx * dt
            pt.y += pt.vy * dt
            pt.life -= dt
        self.particles = [pt for pt in self.particles if pt.life > 0]
        for ft in self.floating_texts:
            ft.y -= 28 * dt
            ft.life -= dt
        self.floating_texts = [ft for ft in self.floating_texts if ft.life > 0]
        for txt, col in p.texts:
            self.add_floating_text(p.x + random.randint(-10, 10), p.y - 34, txt, col)
        p.texts.clear()
        self.shake = max(0.0, self.shake - dt)

        if p.hp <= 0:
            self.state = "GAMEOVER"
            MUSIC.stop()
            AUDIO.play_sfx("game_over")

        self._set(self.lbl_hero, f"{p.char_class} Lv.{p.level}")
        self._set(self.hud_hp, f"Salud: {int(p.hp)}/{p.max_hp}")
        self._set(self.hud_mp, f"Maná:  {int(p.mp)}/{p.max_mp}")
        self._set(self.hud_xp, f"XP:    {p.xp}/{p.xp_to_next}")
        self._set(self.hud_gold, f"Oro: {p.gold}g | Piso {self.floor}")

        tx, ty = p.x - self.view_w / 2, p.y - self.view_h / 2
        if self.cam_init:
            self.camera_x, self.camera_y, self.cam_init = tx, ty, False
        else:
            k = min(1.0, 10 * dt)
            self.camera_x += (tx - self.camera_x) * k
            self.camera_y += (ty - self.camera_y) * k

    # ==========================================================================
    # RENDER
    # ==========================================================================
    def render(self):
        c = self.canvas
        c.delete("all")
        d, p, atl, now = self.dungeon, self.player, self.atlas, self.now
        ts = d.tile_size
        amp = self.shake * 40
        cam_x = self.camera_x + (random.uniform(-amp, amp) if amp > 0 else 0)
        cam_y = self.camera_y + (random.uniform(-amp, amp) if amp > 0 else 0)
        self.cx, self.cy = cam_x, cam_y
        ptx, pty = p.x / ts, p.y / ts
        img = c.create_image
        glows = []

        min_tx, max_tx = max(0, int(cam_x // ts)), min(d.width, int((cam_x + self.view_w) // ts) + 1)
        min_ty, max_ty = max(0, int(cam_y // ts)), min(d.height, int((cam_y + self.view_h) // ts) + 1)
        for tx in range(min_tx, max_tx):
            rev, vis, lk, tl, lg = d.revealed[tx], d.visible[tx], d.look[tx], d.tiles[tx], d.light[tx]
            sx = int(tx * ts - cam_x)
            for ty in range(min_ty, max_ty):
                if not rev[ty]:
                    continue
                sy = int(ty * ts - cam_y)
                t = tl[ty]
                kind, var = lk[ty]
                v = vis[ty]
                if v:
                    L = max(1.0 - math.hypot(tx + 0.5 - ptx, ty + 0.5 - pty) / 9.5, lg[ty] * 0.95)
                    lvl = 0 if L > 0.62 else (1 if L > 0.34 else 2)
                else:
                    lvl = 3
                if t == TILE_STAIRS_DOWN:
                    kind, var = "stairs", 0
                img(sx, sy, image=atl.get(kind, var, lvl), anchor="nw")
                if v:
                    if t == TILE_CHEST: img(sx, sy, image=atl.get("chest", 0, lvl), anchor="nw")
                    elif t == TILE_SHRINE: img(sx, sy, image=atl.get("shrine", 0, lvl), anchor="nw")
                    elif t == TILE_PILLAR: img(sx, sy, image=atl.get("pillar", 0, lvl), anchor="nw")
                    elif t == TILE_FLOOR:
                        dk = d.deco.get((tx, ty))
                        if dk: img(sx, sy, image=atl.get(dk, 0, lvl), anchor="nw")
                    elif t == TILE_WALL:
                        if (tx, ty) in d.torch_set:
                            glows.append((sx + 24, sy + 26))
                            img(sx, sy, image=atl.get("torch", int(now * 6 + tx) % 2, 0), anchor="nw")
                        else:
                            wd = d.wall_deco.get((tx, ty))
                            if wd:
                                img(sx, sy, image=atl.get(wd, 0, lvl), anchor="nw")
                    elif t == TILE_SECRET:
                        img(sx, sy, image=atl.get("crack_ov", 0, lvl), anchor="nw")

        for gx, gy in glows:
            c.create_oval(gx - 52, gy - 52, gx + 52, gy + 52, fill=atl.b["accent"], stipple="gray12", outline="")
        if d.rune and d.revealed[d.rune[0]][d.rune[1]]:
            rcol = atl.b["accent"] if d.visible[d.rune[0]][d.rune[1]] else shade(atl.b["accent"], 0.4)
            rx, ry = d.rune[0] * ts + ts / 2 - cam_x, d.rune[1] * ts + ts / 2 - cam_y
            pulse = 2 + int(1.5 * (1 + math.sin(now * 2)))
            c.create_oval(rx - 84, ry - 84, rx + 84, ry + 84, outline=rcol, width=pulse)
            c.create_oval(rx - 68, ry - 68, rx + 68, ry + 68, outline=shade(rcol, 0.7), width=1)
            for k in (0, 1):
                pts = []
                for i in range(4):
                    a = k * 0.5236 * 2 + i * 2.0944 + now * 0.3
                    pts += [rx + math.cos(a) * 66, ry + math.sin(a) * 66]
                pts += pts[:2]
                c.create_line(pts, fill=shade(rcol, 0.85), width=1)

        # --- entidades ordenadas por profundidad (y)
        draws = []
        for e in self.enemies:
            etx, ety = int(e.x // ts), int(e.y // ts)
            if 0 <= etx < d.width and 0 <= ety < d.height and d.visible[etx][ety]:
                draws.append((e.y, 0, e))
        draws.append((p.y, 1, p))
        for it in self.dropped_items:
            draws.append((it[1], 2, it))
        draws.sort(key=lambda t: (t[0], t[1]))
        for _, kind, obj in draws:
            if kind == 0: self._draw_enemy(c, obj)
            elif kind == 1: self._draw_player(c, obj)
            else: self._draw_drop(c, obj)

        tg = self.auto_target if self.autoaim else None
        if tg is not None and not tg.dead:
            tx_, ty_ = tg.x - cam_x, tg.y - cam_y - 4
            rr = tg.radius + 8 + math.sin(now * 8) * 2
            c.create_oval(tx_ - rr, ty_ - rr, tx_ + rr, ty_ + rr, outline="#ff4d6d", width=2, dash=(4, 4))
            for ax, ay in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                c.create_line(tx_ + ax * (rr - 4), ty_ + ay * (rr - 4), tx_ + ax * (rr + 5), ty_ + ay * (rr + 5),
                              fill="#ff4d6d", width=2)
        for ef in self.effects: self._draw_effect(c, ef)
        for pr in self.projectiles: self._draw_proj(c, pr)
        for pt in self.particles:
            s = max(1.0, pt.size * pt.life / pt.max_life)
            sx, sy = pt.x - cam_x, pt.y - cam_y
            c.create_rectangle(sx - s, sy - s, sx + s, sy + s, fill=pt.color, outline="")
        for ft in self.floating_texts:
            sx, sy = ft.x - cam_x, ft.y - cam_y
            c.create_text(sx + 1, sy + 1, text=ft.text, fill="#000000", font=self.font_bold)
            c.create_text(sx, sy, text=ft.text, fill=ft.color, font=self.font_bold)
        self._render_hud(c)

    # --- sprites
    def _actor(self, c, name, facing, frame, x, y, z):
        sx, sy = x - self.cx, y - self.cy
        c.create_oval(sx - 5 * z, sy + 6 * z, sx + 5 * z, sy + 8 * z, fill="#000000", stipple="gray50", outline="")
        c.create_image(sx, sy - z, image=self.sprites.get(name, facing, frame))
        return sx, sy

    def _draw_player(self, c, p):
        if p.invuln > 0 and p.ult_time <= 0 and int(self.now * 20) % 2 == 0:
            return
        fr = (1, 0, 3, 0)[int(p.anim * 8) % 4] if p.moving else 0
        sx, sy = self._actor(c, p.char_class, p.facing, fr, p.x, p.y, 3)
        a = self.aim()
        tip = (sx + math.cos(a) * 46, sy + math.sin(a) * 46)
        l, r = a + 2.7, a - 2.7
        c.create_polygon(tip[0], tip[1], tip[0] + math.cos(l) * 9, tip[1] + math.sin(l) * 9,
                         tip[0] + math.cos(r) * 9, tip[1] + math.sin(r) * 9, fill="#ffd166", outline="")

    def _draw_enemy(self, c, e):
        z = SPRITE_SPECS[e.name].get("zoom", 3)
        fr = (1, 0, 3, 0)[int(e.anim * 7) % 4] if e.moved else 0
        sx, sy = self._actor(c, e.name, e.facing, fr, e.x, e.y, z)
        if e.frozen_time > 0:
            c.create_rectangle(sx - 4 * z, sy - 9 * z, sx + 4 * z, sy + 7 * z, fill="#a8dadc", stipple="gray50", outline="#a8dadc")
        if e.windup > 0:
            c.create_text(sx, sy - 11 * z, text="!", fill="#ff0000", font=self.font_huge)
        bw, top = max(26, z * 10), sy - 9 * z - 8
        c.create_rectangle(sx - bw / 2, top, sx + bw / 2, top + 4, fill="#2b2d42", outline="#000000")
        c.create_rectangle(sx - bw / 2, top, sx - bw / 2 + bw * max(0.0, e.hp / e.max_hp), top + 4,
                           fill="#e63946", outline="")

    def _draw_drop(self, c, it):
        ix, iy, obj = it
        sx, sy = ix - self.cx, iy - self.cy + math.sin(self.now * 3 + ix) * 3
        if isinstance(obj, str):
            col, name, rare = ("#ff4d6d" if obj == "hp" else "#4cc9f0"), None, False
        else:
            col, name, rare = RARITY_COLORS[obj.rarity], obj.name, obj.rarity in ("Raro", "Épico", "Legendario")
        if rare:
            c.create_line(sx, sy - 10, sx, sy - 40, fill=col, width=2)
        c.create_polygon(sx, sy - 9, sx + 7, sy, sx, sy + 9, sx - 7, sy, fill=col, outline="#ffffff")
        if name and math.hypot(ix - self.player.x, iy - self.player.y) < 120:
            c.create_text(sx, sy - 18, text=name, fill=col, font=self.font_small)

    def _draw_proj(self, c, pr):
        sx, sy = pr.x - self.cx, pr.y - self.cy
        a = math.atan2(pr.vy, pr.vx)
        ca, sa = math.cos(a), math.sin(a)

        def T(pts):
            out = []
            for u, v in pts:
                out += [sx + u * ca - v * sa, sy + u * sa + v * ca]
            return out
        t = pr.ptype
        if t == "dagger":
            c.create_polygon(T([(-12, 0), (-4, -3), (11, 0), (-4, 3)]), fill="#d8f3dc", outline="#52b788")
        elif t == "bolt":
            c.create_polygon(T([(-14, 0), (-2, -5), (11, 0), (-2, 5)]), fill="#4cc9f0", outline="#caf0f8")
            c.create_polygon(T([(-6, 0), (0, -2), (6, 0), (0, 2)]), fill="#ffffff", outline="")
        elif t == "fireball":
            c.create_polygon(T([(-16, 0), (-7, -8), (-2, -3), (4, -9), (7, -2), (13, 0), (7, 2), (4, 9), (-2, 3), (-7, 8)]),
                             fill="#fb8500", outline="#ffb703")
            c.create_polygon(T([(-7, 0), (-1, -4), (6, 0), (-1, 4)]), fill="#ffd23f", outline="")
        elif t == "arrow":
            c.create_line(T([(-12, 0), (8, 0)]), fill="#9ae6ff", width=2)
            c.create_polygon(T([(8, -3), (14, 0), (8, 3)]), fill="#ffffff", outline="")
        elif t == "orb":
            c.create_polygon(T([(-9, 0), (-3, -6), (2, -3), (8, 0), (2, 3), (-3, 6)]), fill="#ff7b00", outline="#ffd23f")
        else:
            c.create_polygon(T([(-9, 0), (0, -5), (10, 0), (0, 5)]), fill=pr.color, outline="#ffffff")

    def _draw_effect(self, c, ef):
        sx, sy = ef.x - self.cx, ef.y - self.cy
        t = 1.0 - ef.life / ef.max
        k = ef.kind
        if k == "arc":
            sweep, n, pts = min(1.0, t * 2.2), 10, []
            for i in range(n + 1):
                a = ef.ang - ef.dir * ef.span / 2 + ef.dir * ef.span * sweep * i / n
                pts += [sx + math.cos(a) * ef.r, sy + math.sin(a) * ef.r]
            c.create_line(pts, fill=ef.color, width=max(2, int(ef.width * (1 - t * 0.6))), capstyle="round", joinstyle="round")
            pts2 = [pts[i] * 1.0 for i in range(len(pts))]
            for i in range(0, len(pts2), 2):
                pts2[i] = sx + (pts[i] - sx) * 0.82
                pts2[i + 1] = sy + (pts[i + 1] - sy) * 0.82
            c.create_line(pts2, fill="#ffffff", width=2)
        elif k == "ring":
            r, pts = ef.r * (0.2 + 0.8 * min(1.0, t * 1.5)), []
            for i in range(21):
                a = i / 20 * 6.2832
                pts += [sx + math.cos(a) * r, sy + math.sin(a) * r]
            c.create_line(pts, fill=ef.color, width=max(1, int(5 * (1 - t))))
        elif k == "spin":
            rot = self.now * 16
            for i in range(3):
                a = rot + i * 2.0944
                ux, uy = math.cos(a), math.sin(a)
                vx, vy = -uy, ux
                c.create_polygon(sx + ux * 30, sy + uy * 30, sx + ux * 70 + vx * 10, sy + uy * 70 + vy * 10,
                                 sx + ux * 122, sy + uy * 122, sx + ux * 70 - vx * 10, sy + uy * 70 - vy * 10,
                                 fill="#dfe6ee", outline="#ffb703", width=2)
            pts = []
            for i in range(25):
                a = i / 24 * 6.2832
                pts += [sx + math.cos(a) * 105, sy + math.sin(a) * 105]
            c.create_line(pts, fill="#ffb703", width=2, dash=(6, 6))
        elif k == "meteor":
            r, pts = ef.r * (0.35 + 0.65 * t), []
            for i in range(19):
                a = i / 18 * 6.2832
                pts += [sx + math.cos(a) * r, sy + math.sin(a) * r * 0.7]
            c.create_line(pts, fill="#ff4d00", width=2)
            c.create_line(sx - 8, sy, sx + 8, sy, fill="#ff4d00")
            fy = sy - ef.life * 520
            c.create_line(sx, fy - 10, sx, fy - 80, fill="#ff8c1a", width=8, capstyle="round")
            c.create_polygon(sx, fy - 20, sx + 7, fy - 8, sx + 18, fy - 10, sx + 10, fy, sx + 18, fy + 10, sx + 7, fy + 8,
                             sx, fy + 22, sx - 7, fy + 8, sx - 18, fy + 10, sx - 10, fy, sx - 18, fy - 10, sx - 7, fy - 8,
                             fill="#fb8500", outline="#ffd23f")
        elif k == "line":
            w = max(1, int(7 * ef.life / ef.max))
            c.create_line(sx, sy, ef.x2 - self.cx, ef.y2 - self.cy, fill=ef.color, width=w + 2)
            c.create_line(sx, sy, ef.x2 - self.cx, ef.y2 - self.cy, fill="#ffffff", width=1)

    # --- HUD
    def _render_hud(self, c):
        p, d = self.player, self.dungeon
        W, H = self.view_w, self.view_h

        def bar(x, y, w, h, val, mx, col, label=""):
            c.create_rectangle(x, y, x + w, y + h, fill="#10121a", outline="#000000")
            if mx > 0:
                c.create_rectangle(x + 1, y + 1, x + 1 + (w - 2) * max(0.0, min(1.0, val / mx)), y + h - 1, fill=col, outline="")
            if label:
                c.create_text(x + w / 2, y + h / 2, text=label, fill="#ffffff", font=self.font_small)
        bar(12, 12, 210, 16, p.hp, p.max_hp, "#d62839", f"{int(p.hp)}/{p.max_hp}")
        bar(12, 32, 210, 12, p.mp, p.max_mp, "#3a86ff", f"{int(p.mp)}/{p.max_mp}")
        bar(12, 48, 210, 10, p.stamina, p.max_stamina, "#8d6e00" if p.exhausted else "#ffbe0b",
            "SIN ALIENTO" if p.exhausted else "")
        bar(0, H - 5, W, 5, p.xp, p.xp_to_next, "#06d6a0")
        c.create_text(W / 2, 14, text=f"PISO {self.floor} · {d.biome['name']}", fill="#adb5bd", font=self.font_small)
        c.create_text(W / 2, H - 32, text=f"AUTOAPUNTADO [P]: {'ON' if self.autoaim else 'OFF'}",
                      fill="#ff6b81" if self.autoaim else "#6c757d", font=self.font_small)
        c.create_text(W / 2, H - 18, text=f"MÚSICA [M]: {'OFF' if MUSIC.muted else 'ON'}   ·   GUÍA [G]",
                      fill="#8d99ae", font=self.font_small)

        # habilidades X / C / Z
        cfg = CLASS_CONFIGS[p.char_class]
        for i, key in enumerate("XCZ"):
            bx, by, w, h = 14 + i * 96, H - 74, 90, 60
            ready = p.cd[i] <= 0
            c.create_rectangle(bx, by, bx + w, by + h, fill="#10121a", outline=cfg["color"] if ready else "#3a3d4d", width=2)
            c.create_text(bx + 14, by + 14, text=key, fill="#ffd166" if ready else "#6c757d", font=self.font_big)
            c.create_text(bx + w - 8, by + 12, text=("BASE", "FUERTE", "ULTI")[i], fill="#8d99ae", font=self.font_small, anchor="e")
            c.create_text(bx + w / 2, by + 38, text=cfg["kit"][i][0], fill="#e0e0e0", font=self.font_small, width=w - 6)
            if cfg["kit"][i][2]:
                c.create_text(bx + w - 5, by + h - 7, text=f"{cfg['kit'][i][2]}MP", fill="#4cc9f0", font=self.font_small, anchor="e")
            if not ready:
                frac = min(1.0, p.cd[i] / max(0.01, p.cd_max[i]))
                c.create_rectangle(bx, by, bx + w, by + h * frac, fill="#000000", stipple="gray50", outline="")
                c.create_text(bx + w / 2, by + h / 2, text=f"{p.cd[i]:.1f}", fill="#ffffff", font=self.font_bold)

        # dash y sprint
        dx0, dy0 = W - 210, H - 74
        rd = p.dash_cd <= 0
        c.create_rectangle(dx0, dy0, dx0 + 96, dy0 + 28, fill="#10121a", outline="#3a86ff" if rd else "#3a3d4d", width=2)
        c.create_text(dx0 + 48, dy0 + 14, text="DASH [ESP]" if rd else f"{p.dash_cd:.1f}s", fill="#ffffff", font=self.font_small)
        c.create_rectangle(dx0 + 104, dy0, dx0 + 200, dy0 + 28, fill="#3a2e00" if p.sprinting else "#10121a",
                           outline="#ffbe0b" if p.sprinting else "#3a3d4d", width=2)
        c.create_text(dx0 + 152, dy0 + 14, text="SPRINT [SHIFT]", fill="#ffffff", font=self.font_small)

        # jefe
        for e in self.enemies:
            if e.ai == "boss" and not e.dead and math.hypot(e.x - p.x, e.y - p.y) < 650:
                bw, bx = 360, (W - 360) / 2
                c.create_text(W / 2, 38, text="SEÑOR DEL ABISMO", fill="#e0aaff", font=self.font_bold)
                bar(bx, 48, bw, 14, e.hp, e.max_hp, "#b5179e")
                break

        # minimapa
        if self.mini is not None:
            cols = {TILE_WALL: "#4a4f66", TILE_SECRET: "#4a4f66", TILE_PILLAR: "#4a4f66", TILE_FLOOR: "#2c3046", TILE_STAIRS_DOWN: "#4895ef",
                    TILE_CHEST: "#e76f51", TILE_SHRINE: "#06d6a0"}
            for (x, y) in d.new_revealed:
                self.mini.put(cols.get(d.tiles[x][y], "#2c3046"), to=(x * 2, y * 2, x * 2 + 2, y * 2 + 2))
            d.new_revealed.clear()
            mx0, my0 = W - d.width * 2 - 10, 70 if any(e.ai == "boss" for e in self.enemies) else 10
            c.create_rectangle(mx0 - 2, my0 - 2, mx0 + d.width * 2 + 2, my0 + d.height * 2 + 2, fill="#05050a", outline="#2a2c3d")
            c.create_image(mx0, my0, image=self.mini, anchor="nw")
            px, py = int(p.x // d.tile_size) * 2, int(p.y // d.tile_size) * 2
            c.create_rectangle(mx0 + px - 2, my0 + py - 2, mx0 + px + 4, my0 + py + 4, fill="#ffd166", outline="")

        if p.hurt > 0:
            c.create_rectangle(3, 3, W - 3, H - 3, outline="#ff0000", width=8, stipple="gray50")

    # ==========================================================================
    # PANTALLAS: TITULO, GAME OVER, VICTORIA
    # ==========================================================================
    def render_title(self):
        c, t = self.canvas, self.now
        W, H = self.view_w, self.view_h
        c.delete("all")
        c.create_rectangle(0, 0, W, H, fill="#07070d", outline="")
        for i in range(46):
            x, y = (i * 131 + t * (8 + i % 5 * 4)) % W, (i * 71) % H
            c.create_rectangle(x, y, x + 2, y + 2, fill="#2a2d44", outline="")
        c.create_text(W / 2, 110, text="CHRONICLES OF", fill="#8d99ae", font=self.font_big)
        c.create_text(W / 2, 152, text="AETHELGAARD", fill="#ffd166", font=self.font_huge)
        c.create_text(W / 2, 196, text="THE ABYSSAL CITADEL", fill="#c77dff", font=self.font_big)
        for i, name in enumerate(CLASS_CONFIGS):
            x, y = W * (i + 1) / 4, H * 0.52 + math.sin(t * 2 + i) * 4
            c.create_oval(x - 50, y + 62, x + 50, y + 76, fill="#000000", stipple="gray50", outline="")
            c.create_image(x, y, image=self.sprites.big[name])
            c.create_text(x, y + 100, text=name.upper(), fill=CLASS_CONFIGS[name]["color"], font=self.font_big)
        c.create_text(W / 2, H - 70, text="Elegí tu héroe en el panel de la derecha", fill="#adb5bd", font=self.font_norm)
        c.create_text(W / 2, H - 46, text="X base · C fuerte · Z ulti · SHIFT sprint · ESPACIO dash · P autoapuntado · M música", fill="#6c757d", font=self.font_small)

    def render_game_over(self):
        c, W, H = self.canvas, self.view_w, self.view_h
        c.delete("all")
        c.create_rectangle(0, 0, W, H, fill="#0b090a")
        c.create_text(W / 2, H / 2 - 60, text="HAS SUCUMBIDO AL ABISMO", fill="#e63946", font=self.font_title)
        c.create_text(W / 2, H / 2, text=f"Llegaste al Piso {self.floor} con nivel {self.player.level}", fill="#f1faee", font=self.font_big)
        c.create_text(W / 2, H / 2 + 35, text=f"Oro acumulado: {self.player.gold}g", fill="#ffd166", font=self.font_norm)
        c.create_text(W / 2, H / 2 + 80, text="Click para volver a intentarlo", fill="#a8dadc", font=self.font_norm)

    def render_victory(self):
        c, W, H = self.canvas, self.view_w, self.view_h
        c.delete("all")
        c.create_rectangle(0, 0, W, H, fill="#0d1b2a")
        c.create_text(W / 2, H / 2 - 60, text="¡VICTORIA ABSOLUTA!", fill="#ffd166", font=self.font_title)
        c.create_text(W / 2, H / 2, text="Derrotaste al Señor del Abismo y purificaste la Ciudadela", fill="#f1faee", font=self.font_big)
        c.create_text(W / 2, H / 2 + 40, text=f"Oro final: {self.player.gold}g | Nivel final: {self.player.level}", fill="#06d6a0", font=self.font_norm)
        c.create_text(W / 2, H / 2 + 85, text="Click para jugar otra partida con otra clase", fill="#a8dadc", font=self.font_norm)

    def restart_game(self):
        self.keys.clear()
        self.mouse_down = False
        self._end_drawn = False
        self.state = "CLASS_SELECT"
        self.build_class_selection_screen()
        MUSIC.play_theme(1)


# ==============================================================================
# PUNTO DE ENTRADA
# ==============================================================================
def main():
    root = tk.Tk()
    GameEngine(root)
    root.mainloop()


if __name__ == "__main__":
    main()
