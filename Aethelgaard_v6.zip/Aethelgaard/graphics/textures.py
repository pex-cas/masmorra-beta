# -*- coding: utf-8 -*-
"""Atlas de texturas generadas por codigo (4 niveles de luz)."""
import random
from game.assets import find_asset, load_png_grid
from graphics.utils import _rect, shade, to_photo
from world.dungeon import BIOME_THEMES


# ==============================================================================
class TextureAtlas:
    """Texturas 24x24 (se muestran a 48px) con 4 niveles de luz.
    Estilo: piedra azulada, paredes con borde brillante bien marcado, vacio negro."""
    LEVELS = (1.0, 0.74, 0.52, 0.30)

    def __init__(self, biome_id):
        self.bid = biome_id
        self.b = BIOME_THEMES[biome_id]
        self.grids, self.imgs = {}, {}

    def get(self, kind, var, lvl):
        key = (kind, var, lvl)
        im = self.imgs.get(key)
        if im is None:
            g = self.grids.get((kind, var))
            if g is None:
                g = self.grids[(kind, var)] = self._external(kind, var) or self._make(kind, var)
            f = self.LEVELS[lvl]
            sg = [[shade(c, f) if c else None for c in row] for row in g]
            im = self.imgs[key] = to_photo(sg, 24, 2)
        return im

    def _external(self, kind, var):
        """Textura 24x24 opcional: assets/textures/<tipo>_<variante>.png o <tipo>.png."""
        p = find_asset("textures", ["%s_%d" % (kind, var), kind], [".png"])
        return load_png_grid(p, 24) if p else None

    def prewarm(self):
        for lvl in range(4):
            for v in range(4):
                self.get("floor", v, lvl)
            for v in range(2):
                self.get("floor_sh", v, lvl)
            for v in range(8):
                self.get("wall_face", v, lvl)
                self.get("wall_cap", v, lvl)
            self.get("void", 0, lvl)

    # ---- terreno estilo caricatura seria: losas y ladrillos gruesos con contorno oscuro, luz arriba-izquierda,
    #      sombra abajo-derecha y colores planos (cel-shading). Texturas de 24x24 mostradas a 48 px.
    def _ink(self):
        return shade(self.b["top"], 0.7)

    def _slab(self, g, x0, y0, w, h, col, ink, hi=1.28, lo=0.72):
        """Losa/ladrillo con esquinas redondeadas, contorno, brillo arriba-izquierda y sombra abajo-derecha."""
        for y in range(y0, y0 + h):
            for x in range(x0, x0 + w):
                if not (0 <= x < 24 and 0 <= y < 24):
                    continue
                edge = x in (x0, x0 + w - 1) or y in (y0, y0 + h - 1)
                corner = x in (x0, x0 + w - 1) and y in (y0, y0 + h - 1)
                if corner:
                    continue
                if edge:
                    g[y][x] = ink
                elif y == y0 + 1 or x == x0 + 1:
                    g[y][x] = shade(col, hi)
                elif y == y0 + h - 2 or x == x0 + w - 2:
                    g[y][x] = shade(col, lo)
                else:
                    g[y][x] = col

    def _terrain(self, kind, var, rnd):
        b = self.b
        st, rim, ink = b["wall"], b["rim"], self._ink()
        g = [[ink] * 24 for _ in range(24)]

        def speck(col, n, x0=2, y0=2, x1=22, y1=22):
            for _ in range(n):
                g[rnd.randint(y0, y1 - 1)][rnd.randint(x0, x1 - 1)] = col

        if kind in ("floor", "floor_sh"):
            c1, c2 = b["floor"], b["floor2"]
            if var == 0:
                self._slab(g, 0, 0, 24, 24, c1, ink)
            elif var == 1:
                self._slab(g, 0, 0, 12, 24, c1, ink)
                self._slab(g, 11, 0, 13, 12, c2, ink)
                self._slab(g, 11, 11, 13, 13, c1, ink)
            elif var == 2:
                self._slab(g, 0, 0, 24, 12, c2, ink)
                self._slab(g, 0, 11, 13, 13, c1, ink)
                self._slab(g, 12, 11, 12, 13, c2, ink)
            else:
                self._slab(g, 0, 0, 24, 24, c2, ink)
            dark = shade(c1, 0.6)
            if var in (0, 3):                                   # grietas y guijarros
                x = 8 + var
                for y in range(6, 16):
                    g[y][x] = dark
                    x += rnd.choice((-1, 0, 1))
                speck(shade(c1, 1.35), 3)
            speck(shade(c1, 1.2), 2)
            if kind == "floor_sh":                              # sombra que cae de la pared
                for y in range(10):
                    f = 0.45 + 0.55 * (y / 10.0)
                    for x in range(24):
                        g[y][x] = shade(g[y][x], f)

        elif kind == "wall_face":
            mask, bv = var % 4, var // 4
            g = [[shade(ink, 0.8)] * 24 for _ in range(24)]
            rows = ((3, 7), (10, 7), (17, 7))
            for ri, (y0, h) in enumerate(rows):
                off = 0 if (ri + bv) % 2 == 0 else 6
                xs = [-12 + off + 12 * k for k in range(4)]
                for k, x0 in enumerate(xs):
                    col = shade(st, 0.92 + 0.08 * ((ri * 3 + k + bv) % 3))
                    if y0 >= 17:
                        col = shade(col, 0.82)
                    self._slab(g, x0, y0, 12, h, col, shade(ink, 1.0))
            for x in range(24):                                 # cornisa superior brillante
                g[0][x] = shade(rim, 0.9)
                g[1][x] = shade(b["top"], 1.6)
                g[2][x] = shade(ink, 0.9)
            for y in range(24):                                 # bordes con piso al costado
                if mask & 1:
                    g[y][0], g[y][1] = rim, shade(rim, 0.7)
                if mask & 2:
                    g[y][23], g[y][22] = rim, shade(rim, 0.7)

        elif kind == "wall_cap":
            top = shade(b["top"], 1.9)
            g = [[shade(top, 0.75)] * 24 for _ in range(24)]
            for (x0, y0) in ((0, 0), (12, 0), (0, 12), (12, 12)):
                self._slab(g, x0, y0, 12, 12, shade(top, 1.0 + 0.06 * ((x0 + y0 + var) % 3)), shade(b["top"], 0.7), hi=1.18, lo=0.85)
            for k in range(24):
                if var & 1:
                    g[0][k], g[1][k], g[2][k] = rim, shade(rim, 0.8), shade(rim, 0.45)
                if var & 2:
                    g[k][23], g[k][22], g[k][21] = rim, shade(rim, 0.8), shade(rim, 0.45)
                if var & 4:
                    g[k][0], g[k][1], g[k][2] = rim, shade(rim, 0.8), shade(rim, 0.45)

        else:                                                   # void
            g = [[shade(b["top"], 0.55)] * 24 for _ in range(24)]
        return g

    def _outline(self, g, col="#0b0b10"):
        """Contorno de caricatura alrededor de objetos sueltos (fondo transparente)."""
        out = [row[:] for row in g]
        for y in range(24):
            for x in range(24):
                if g[y][x] is None:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < 24 and 0 <= ny < 24 and g[ny][nx]:
                            out[y][x] = col
                            break
        return out

    def _make(self, kind, var):
        b = self.b
        rnd = random.Random(var * 7919 + self.bid * 131 + sum(map(ord, kind)))
        g = [[None] * 24 for _ in range(24)]
        st, rim, ac = b["wall"], b["rim"], b["accent"]
        li, da = shade(st, 1.35), shade(st, 0.6)

        if kind in ("floor", "floor_sh", "wall_face", "wall_cap", "void"):
            g = self._terrain(kind, var, rnd)

        elif kind == "crack_ov":      # grieta que delata una pared secreta
            x = 11
            col, hi = shade(b["top"], 0.45), shade(rim, 1.0)
            for y in range(2, 22):
                _rect(g, x - 1, y, 3, 1, "#05050a")
                _rect(g, x, y, 1, 1, col)
                if y % 3 == 0:
                    _rect(g, x + 1, y, 1, 1, hi)
                x = max(5, min(18, x + rnd.choice((-1, 0, 0, 1))))
            for i in range(6):
                _rect(g, 11 + i, 12 + i // 2, 1, 1, col)

        elif kind == "pillar":
            _rect(g, 4, 18, 16, 5, da)
            _rect(g, 5, 17, 14, 2, st)
            _rect(g, 7, 6, 10, 12, st)
            _rect(g, 7, 6, 3, 12, li)
            _rect(g, 14, 6, 3, 12, da)
            for yy in (9, 13):
                _rect(g, 7, yy, 10, 1, shade(st, 0.55))
            _rect(g, 5, 2, 14, 5, li)
            _rect(g, 5, 5, 14, 2, da)
            g = self._outline(g, shade(b["top"], 0.45))

        elif kind == "torch":
            _rect(g, 11, 12, 2, 8, "#6b4a2b")
            _rect(g, 8, 11, 8, 2, "#2a2f3a")
            _rect(g, 9, 13, 6, 1, "#4a4f5c")
            mid = shade(ac, 1.5)
            if var == 0:
                _rect(g, 9, 4, 6, 8, ac)
                _rect(g, 10, 1, 4, 4, mid)
                _rect(g, 11, 5, 2, 5, "#fffbe0")
            else:
                _rect(g, 9, 5, 6, 7, ac)
                _rect(g, 11, 2, 3, 4, mid)
                _rect(g, 12, 6, 2, 4, "#fffbe0")
            g = self._outline(g, "#0b0b10")

        elif kind == "stairs":
            g = [["#07070d"] * 24 for _ in range(24)]
            for i in range(5):
                y = 2 + i * 4
                col = shade(st, 1.35 - i * 0.24)
                _rect(g, 2 + i, y, 20 - 2 * i, 4, "#0b0b10")
                _rect(g, 3 + i, y + 1, 18 - 2 * i, 2, col)
                _rect(g, 3 + i, y + 1, 18 - 2 * i, 1, shade(col, 1.35))
            for k in range(24):
                g[0][k] = g[23][k] = ac
                g[k][0] = g[k][23] = ac
                g[1][k] = g[22][k] = shade(ac, 0.5)
                g[k][1] = g[k][22] = shade(ac, 0.5)

        elif kind == "chest":
            _rect(g, 3, 7, 18, 15, "#2a1a0e")
            _rect(g, 4, 8, 16, 6, "#b9742f")             # tapa abombada
            _rect(g, 4, 8, 16, 2, "#d99445")
            _rect(g, 4, 14, 16, 7, "#8a5427")
            _rect(g, 4, 14, 16, 1, "#2a1a0e")
            _rect(g, 6, 8, 3, 13, "#aab2bd")             # herrajes
            _rect(g, 15, 8, 3, 13, "#aab2bd")
            _rect(g, 6, 8, 1, 13, "#e3e8ee")
            _rect(g, 15, 8, 1, 13, "#e3e8ee")
            _rect(g, 10, 12, 4, 5, "#ffcf3f")            # cerradura dorada
            _rect(g, 11, 14, 2, 2, "#7a5200")
            _rect(g, 10, 12, 4, 1, "#fff2a8")

        elif kind == "shrine":
            _rect(g, 4, 17, 16, 5, "#10101a")
            _rect(g, 5, 16, 14, 5, da)
            _rect(g, 6, 15, 12, 3, st)
            _rect(g, 6, 15, 12, 1, li)
            for (x, y, w, h) in ((11, 3, 2, 3), (9, 6, 6, 3), (8, 9, 8, 4), (9, 13, 6, 2)):
                _rect(g, x, y, w, h, shade(ac, 1.15))
            _rect(g, 10, 7, 2, 5, "#ffffff")
            g = self._outline(g, "#0b0b10")

        elif kind == "bones":
            _rect(g, 4, 15, 9, 2, "#e9e4d4")
            _rect(g, 3, 14, 3, 4, "#e9e4d4")
            _rect(g, 12, 14, 3, 4, "#e9e4d4")
            _rect(g, 13, 8, 8, 7, "#f2eee0")
            _rect(g, 14, 10, 2, 2, "#111111")
            _rect(g, 18, 10, 2, 2, "#111111")
            _rect(g, 15, 14, 4, 1, "#9b9684")
            g = self._outline(g, "#1a1612")

        elif kind == "moss":
            for _ in range(5):
                cx, cy = rnd.randint(4, 19), rnd.randint(4, 19)
                for _k in range(4):
                    _rect(g, cx + rnd.randint(-2, 2), cy + rnd.randint(-2, 2), 3, 3, "#3f8a4a")
                _rect(g, cx, cy, 2, 1, "#7ed58a")
            g = self._outline(g, "#0f2a14")

        elif kind == "crack":
            x, y = rnd.randint(4, 10), rnd.randint(1, 4)
            col = shade(b["floor"], 0.35)
            for _ in range(16):
                _rect(g, x, y, 2, 1, col)
                y += 1
                x += rnd.choice((-1, 0, 1, 1))

        elif kind == "barrel":
            _rect(g, 5, 4, 14, 18, "#2a1a0e")
            _rect(g, 6, 5, 12, 16, "#8a5e34")
            _rect(g, 6, 5, 4, 16, "#b07c47")
            _rect(g, 15, 5, 3, 16, "#5e3d1f")
            for yy in (7, 17):
                _rect(g, 5, yy, 14, 2, "#2a2f3a")
                _rect(g, 6, yy, 12, 1, "#8b95a5")
            _rect(g, 7, 4, 10, 1, "#d09a5c")

        elif kind == "crate":
            _rect(g, 3, 6, 18, 16, "#2a1a0e")
            _rect(g, 4, 7, 16, 14, "#9a7444")
            for i in range(12):
                g[8 + i][5 + i] = "#4a321a"
                g[8 + i][18 - i] = "#4a321a"
            _rect(g, 4, 7, 16, 2, "#c29a62")
            _rect(g, 4, 19, 16, 2, "#6a4a28")

        elif kind in ("web_l", "web_r"):
            pts = set()
            for r in (5, 9, 13):
                for i in range(r + 1):
                    pts.add((i, r - i))
            for i in range(15):
                pts.add((i, 0))
                pts.add((0, i))
            for i in range(11):
                pts.add((i, i))
            for (x, y) in pts:
                if 0 <= x < 24 and 0 <= y < 24:
                    g[y][x if kind == "web_l" else 23 - x] = "#cfdcec"

        elif kind == "chains":
            for y in range(0, 18):
                _rect(g, 10 + (y % 2) * 2, y, 2, 1, "#a9b4c2")
            for y in range(0, 18, 3):
                _rect(g, 9, y, 5, 2, "#7d8794")
            _rect(g, 7, 18, 10, 4, "#59616c")
            _rect(g, 8, 18, 8, 1, "#b4bdc9")
            g = self._outline(g, "#0b0b10")

        return g
