# -*- coding: utf-8 -*-
"""Punto de entrada de Chronicles of Aethelgaard: The Abyssal Citadel.

Ejecutar desde la carpeta raiz:  python main.py
"""
import sys


def main():
    try:
        import tkinter as tk
    except ImportError:
        sys.exit("Tkinter no esta disponible. Instala Python desde python.org (incluye Tkinter).")
    from game.engine import GameEngine
    import traceback
    from game.assets import log
    if sys.platform == "win32":                 # sin esto el temporizador de Windows va a ~64 Hz y baja los fps
        try:
            import ctypes
            ctypes.windll.winmm.timeBeginPeriod(1)
        except Exception:
            pass
    root = tk.Tk()

    def report(exc, val, tb):             # errores dentro de callbacks de Tk -> logs/game.log
        log.error("Error en el juego", exc_info=(exc, val, tb))
        traceback.print_exception(exc, val, tb)
    root.report_callback_exception = report
    GameEngine(root)
    root.mainloop()


if __name__ == "__main__":
    main()
