# Aethelgaard — versión 10

## Cambios visuales
- Se ajustaron las siluetas de personajes y enemigos para que se vean un poco más cúbicas, cabezonas y robustas, manteniendo el estilo pixel art de la versión anterior.
- Se agregó un frame de respiración/idle sutil para que personajes y enemigos no queden completamente estáticos cuando están quietos.
- Se conservan los frames alternados de caminata cuando se mueven.
- La aura de los jefes sigue animada con pulso, runas y partículas; el jefe final ahora usa una paleta violeta/magenta más distintiva.
- Los cambios son procedurales y no requieren descargar recursos externos ni instalar paquetes adicionales.

## Compatibilidad
- Se mantienen los controles, combate, progresión, generación de mazmorras, inventario y balance de V9.
- El juego continúa ejecutándose con `python main.py` o `ejecutar.bat` en Windows.

## Pruebas
- Las pruebas de lógica, mapas, sprites y sintaxis pasaron.
- Las pruebas que requieren una ventana gráfica real no pudieron completarse en este entorno sin servidor gráfico (Tkinter/display); deben probarse localmente al abrir el juego.
