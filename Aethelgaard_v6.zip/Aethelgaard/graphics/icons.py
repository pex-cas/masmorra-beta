# -*- coding: utf-8 -*-
"""Iconos pixel art en estilo caricatura seria: botella de pocion y monedas / montones de oro."""
from graphics.utils import to_photo

INK = "#140c10"

POTION_ART = (
    "................",
    ".....oooooo.....",
    ".....occCco.....",
    ".....occcco.....",
    "......oggo......",
    "......oggo......",
    ".....ogggho.....",
    "....oghrrrro....",
    "...oghhrrrrRo...",
    "..oghrrrrrrrRo..",
    "..ogrrwrrrrrRo..",
    "..ogrrrrrrrrRo..",
    "..oorrrrrrrRRo..",
    "...oorrrRRRRo...",
    "....ooRRRRoo....",
    ".....oooooo.....",
)
POTION_PAL = {"o": INK, "c": "#b9803f", "C": "#e0a65f", "g": "#d8eef5", "h": "#ffffff",
              "r": "#e0243f", "R": "#8f1230", "w": "#ff9aae"}


def art_grid(art, pal):
    return [[pal.get(ch) for ch in row] for row in art]


def potion_grid():
    return art_grid(POTION_ART, POTION_PAL)


def _coin(g, cx, cy, hw, hh=6):
    """Moneda de canto/frente: elipse de semiancho `hw` con borde oscuro, brillo y marca central."""
    n = len(g)
    for y in range(cy - hh - 1, cy + hh + 2):
        for x in range(cx - hw - 1, cx + hw + 2):
            if not (0 <= x < n and 0 <= y < n):
                continue
            dx, dy = (x - cx) / max(0.6, hw + 0.4), (y - cy) / (hh + 0.4)
            d = dx * dx + dy * dy
            if d <= 1.0:
                col = "#ffcf3f"
                if d > 0.62:
                    col = "#e0a31a"
                if dx + dy < -0.55 and d > 0.25:
                    col = "#fff3a6"
                if dx + dy > 0.9:
                    col = "#b97a0a"
                g[y][x] = col
            elif d <= 1.45:
                g[y][x] = INK
    if hw >= 3 and hh >= 5:                                             # marca grabada en el centro
        for y in range(cy - 2, cy + 3):
            if 0 <= y < n:
                g[y][cx] = "#a8680a"
        if 0 <= cy - 3 < n:
            g[cy - 3][cx] = "#a8680a"
            g[cy + 3][cx] = "#a8680a"


def coin_grid(frame=0):
    """Moneda girando: 4 cuadros (frente, tres cuartos, canto, tres cuartos)."""
    g = [[None] * 16 for _ in range(16)]
    _coin(g, 8, 8, (6, 4, 1, 4)[frame % 4])
    return g


def pile_grid(level):
    """Montoncito de monedas (0 pocas, 1 medio, 2 grande con bolsa)."""
    g = [[None] * 16 for _ in range(16)]
    if level == 0:
        _coin(g, 6, 11, 4, 3); _coin(g, 10, 10, 4, 3); _coin(g, 8, 7, 4, 3)
    elif level == 1:
        for cx, cy in ((4, 12), (8, 12), (12, 12), (6, 8), (10, 8), (8, 4)):
            _coin(g, cx, cy, 3, 3)
    else:
        for cx, cy in ((3, 13), (7, 13), (11, 13), (13, 11)):
            _coin(g, cx, cy, 3, 3)
        sack = {"o": INK, "s": "#9a6b3a", "S": "#c58f52", "t": "#6e4a24", "y": "#ffcf3f"}
        art = ("....oo..oo......", "....osooso......", ".....osso.......", "....otttto......",
               "...osSSsssto....", "..osSSsssssto...", "..osSyysssst....", "..ossyyssstto...")
        for j, row in enumerate(art):
            for i, ch in enumerate(row):
                if ch != "." and sack.get(ch):
                    g[j + 1][i + 1] = sack[ch]
        _coin(g, 8, 9, 3, 3); _coin(g, 6, 10, 2, 3)
    return g


class IconBank:
    """PhotoImages de los iconos (HUD 16 px, objetos en el suelo 32 px)."""

    def __init__(self):
        self.potion = to_photo(potion_grid(), 16, 2)
        self.potion_s = to_photo(potion_grid(), 16, 1)
        self.coin_s = to_photo(coin_grid(0), 16, 1)
        self.coins = [to_photo(coin_grid(i), 16, 2) for i in range(4)]
        self.piles = [to_photo(pile_grid(i), 16, 2) for i in range(3)]
