# -*- coding: utf-8 -*-
"""Imagen del mapa completo del piso (se genera entera al cargar el piso y solo se muestra con la pasiva)."""
import tkinter as tk
from world.dungeon import TILE_CHEST, TILE_FLOOR, TILE_PILLAR, TILE_SECRET, TILE_SHRINE, TILE_STAIRS_DOWN, TILE_WALL

PX = 5   # pixeles por casilla en la imagen base (el mapa ampliado la agranda con zoom entero)


def _pattern(fill, marks=()):
    g = [[fill] * PX for _ in range(PX)]
    for (r, c, col) in marks:
        g[r][c] = col
    return [" ".join(row) for row in g]


def _box(a, b, col):
    return [(r, c, col) for r in range(a, b + 1) for c in range(a, b + 1)]


_PATTERNS = {
    "void": _pattern("#05050a"),
    "floor0": _pattern("#262c44", [(0, 0, "#323a5c"), (0, 1, "#323a5c"), (1, 0, "#323a5c")]),
    "floor1": _pattern("#242a41", [(2, 2, "#2f3654"), (3, 3, "#2f3654")]),
    "wall": _pattern("#454c73", [(0, c, "#6770a3") for c in range(PX)] + [(PX - 1, c, "#2f3552") for c in range(PX)]),
    "torch": _pattern("#454c73", [(0, c, "#6770a3") for c in range(PX)] + [(2, 2, "#ffb703"), (1, 2, "#ff8c1a")]),
    "stairs": _pattern("#1d4f91", _box(1, 3, "#4895ef") + [(2, 2, "#d7ecff")]),
    "chest": _pattern("#262c44", _box(1, 3, "#b5532f") + [(2, 2, "#ffd166")]),
    "pillar": _pattern("#262c44", _box(1, 3, "#6d6b86")),
    "shrine": _pattern("#262c44", _box(1, 3, "#06d6a0")),
    "secret": _pattern("#262c44", _box(1, 3, "#e040fb")),
}


def build_map_image(d):
    """PhotoImage con TODO el piso (muros, suelo, escaleras, cofres, antorchas). Las camaras secretas
    sin descubrir quedan ocultas; las ya abiertas aparecen."""
    W, H, T = d.width, d.height, d.tiles
    hidden = set()
    for info in d.secrets.values():
        hidden.update(info["cells"])
    solid = (TILE_WALL, TILE_SECRET, 0)

    def is_open(x, y):
        return 0 <= x < W and 0 <= y < H and T[x][y] not in solid and (x, y) not in hidden

    rows = []
    for y in range(H):
        names = []
        for x in range(W):
            t = T[x][y]
            if (x, y) in hidden:
                names.append("void")
            elif t in solid:
                near = any(is_open(x + dx, y + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1))
                names.append("void" if not near else ("torch" if (x, y) in d.torch_set else "wall"))
            elif t == TILE_STAIRS_DOWN:
                names.append("stairs")
            elif t == TILE_CHEST:
                names.append("chest")
            elif t == TILE_PILLAR:
                names.append("pillar")
            elif t == TILE_SHRINE:
                names.append("shrine")
            else:
                names.append("floor0" if (x + y) % 2 == 0 else "floor1")
        for r in range(PX):
            rows.append("{" + " ".join(_PATTERNS[n][r] for n in names) + "}")
    img = tk.PhotoImage(width=W * PX, height=H * PX)
    img.put(" ".join(rows), to=(0, 0))
    return img
