# -*- coding: utf-8 -*-
"""Render del mundo, entidades y efectos."""

import math
import random
from combat.entities import GoldPile
from graphics.sprites import SPRITE_SPECS
from graphics.utils import shade
from inventory.items import RARITY_COLORS
from world.dungeon import TILE_CHEST, TILE_FLOOR, TILE_PILLAR, TILE_SECRET, TILE_SHRINE, TILE_STAIRS_DOWN, TILE_WALL


class RenderMixin:
    # ==========================================================================
    # RENDER
    # ==========================================================================
    def render(self):
        c = self.canvas
        c.delete("all")
        d, p, atl, now = self.dungeon, self.player, self.atlas, self.now
        ts = d.tile_size
        amp = self.shake * 40
        cam_x = self.camera_x + (random.uniform(-amp, amp) if amp > 0 else 0)
        cam_y = self.camera_y + (random.uniform(-amp, amp) if amp > 0 else 0)
        self.cx, self.cy = cam_x, cam_y
        ptx, pty = p.x / ts, p.y / ts
        img = c.create_image
        glows = []

        min_tx, max_tx = max(0, int(cam_x // ts)), min(d.width, int((cam_x + self.view_w) // ts) + 1)
        min_ty, max_ty = max(0, int(cam_y // ts)), min(d.height, int((cam_y + self.view_h) // ts) + 1)
        for tx in range(min_tx, max_tx):
            rev, vis, lk, tl, lg = d.revealed[tx], d.visible[tx], d.look[tx], d.tiles[tx], d.light[tx]
            sx = int(tx * ts - cam_x)
            for ty in range(min_ty, max_ty):
                if not rev[ty]:
                    continue
                sy = int(ty * ts - cam_y)
                t = tl[ty]
                kind, var = lk[ty]
                v = vis[ty]
                if v:
                    L = max(1.0 - math.hypot(tx + 0.5 - ptx, ty + 0.5 - pty) / 9.5, lg[ty] * 0.95)
                    lvl = 0 if L > 0.62 else (1 if L > 0.34 else 2)
                else:
                    lvl = 3
                if t == TILE_STAIRS_DOWN:
                    kind, var = "stairs", 0
                img(sx, sy, image=atl.get(kind, var, lvl), anchor="nw")
                if v:
                    if t == TILE_CHEST: img(sx, sy, image=atl.get("chest", 0, lvl), anchor="nw")
                    elif t == TILE_SHRINE: img(sx, sy, image=atl.get("shrine", 0, lvl), anchor="nw")
                    elif t == TILE_PILLAR: img(sx, sy, image=atl.get("pillar", 0, lvl), anchor="nw")
                    elif t == TILE_FLOOR:
                        dk = d.deco.get((tx, ty))
                        if dk: img(sx, sy, image=atl.get(dk, 0, lvl), anchor="nw")
                    elif t == TILE_WALL:
                        if (tx, ty) in d.torch_set:
                            glows.append((sx + 24, sy + 26))
                            img(sx, sy, image=atl.get("torch", int(now * 6 + tx) % 2, 0), anchor="nw")
                    elif t == TILE_SECRET:
                        img(sx, sy, image=atl.get("crack_ov", 0, lvl), anchor="nw")

        for gx, gy in glows:
            c.create_oval(gx - 52, gy - 52, gx + 52, gy + 52, fill=atl.b["accent"], stipple="gray12", outline="")
        if d.rune and d.revealed[d.rune[0]][d.rune[1]]:
            rcol = atl.b["accent"] if d.visible[d.rune[0]][d.rune[1]] else shade(atl.b["accent"], 0.4)
            rx, ry = d.rune[0] * ts + ts / 2 - cam_x, d.rune[1] * ts + ts / 2 - cam_y
            pulse = 2 + int(1.5 * (1 + math.sin(now * 2)))
            c.create_oval(rx - 84, ry - 84, rx + 84, ry + 84, outline=rcol, width=pulse)
            c.create_oval(rx - 68, ry - 68, rx + 68, ry + 68, outline=shade(rcol, 0.7), width=1)
            for k in (0, 1):
                pts = []
                for i in range(4):
                    a = k * 0.5236 * 2 + i * 2.0944 + now * 0.3
                    pts += [rx + math.cos(a) * 66, ry + math.sin(a) * 66]
                pts += pts[:2]
                c.create_line(pts, fill=shade(rcol, 0.85), width=1)

        # --- entidades ordenadas por profundidad (y)
        draws = []
        for e in self.enemies:
            etx, ety = int(e.x // ts), int(e.y // ts)
            if 0 <= etx < d.width and 0 <= ety < d.height and d.visible[etx][ety]:
                draws.append((e.y, 0, e))
        draws.append((p.y, 1, p))
        for it in self.dropped_items:
            draws.append((it[1], 2, it))
        draws.sort(key=lambda t: (t[0], t[1]))
        for _, kind, obj in draws:
            if kind == 0: self._draw_enemy(c, obj)
            elif kind == 1: self._draw_player(c, obj)
            else: self._draw_drop(c, obj)

        tg = self.auto_target if self.autoaim else None
        if tg is not None and not tg.dead:
            tx_, ty_ = tg.x - cam_x, tg.y - cam_y - 4
            rr = tg.radius + 8 + math.sin(now * 8) * 2
            c.create_oval(tx_ - rr, ty_ - rr, tx_ + rr, ty_ + rr, outline="#ff4d6d", width=2, dash=(4, 4))
            for ax, ay in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                c.create_line(tx_ + ax * (rr - 4), ty_ + ay * (rr - 4), tx_ + ax * (rr + 5), ty_ + ay * (rr + 5),
                              fill="#ff4d6d", width=2)
        for ef in self.effects: self._draw_effect(c, ef)
        for pr in self.projectiles: self._draw_proj(c, pr)
        for pt in self.particles:
            s = max(1.0, pt.size * pt.life / pt.max_life)
            sx, sy = pt.x - cam_x, pt.y - cam_y
            c.create_rectangle(sx - s, sy - s, sx + s, sy + s, fill=pt.color, outline="")
        for ft in self.floating_texts:
            sx, sy = ft.x - cam_x, ft.y - cam_y
            c.create_text(sx + 1, sy + 1, text=ft.text, fill="#000000", font=self.font_bold)
            c.create_text(sx, sy, text=ft.text, fill=ft.color, font=self.font_bold)
        self._render_hud(c)

    # --- sprites
    def _actor(self, c, name, facing, frame, x, y, z):
        sx, sy = x - self.cx, y - self.cy
        c.create_oval(sx - 5 * z, sy + 6 * z, sx + 5 * z, sy + 8 * z, fill="#000000", stipple="gray50", outline="")
        c.create_image(sx, sy - z, image=self.sprites.get(name, facing, frame))
        return sx, sy

    def _draw_player(self, c, p):
        if p.invuln > 0 and p.ult_time <= 0 and int(self.now * 20) % 2 == 0:
            return
        fr = (1, 0, 3, 0)[int(p.anim * 8) % 4] if p.moving else 0
        sx, sy = self._actor(c, p.char_class, p.facing, fr, p.x, p.y, 3)
        if p.guarding:                                    # escudo de energia alrededor del heroe
            r = 30 + 2 * math.sin(self.now * 10)
            c.create_oval(sx - r, sy - r - 4, sx + r, sy + r - 4, fill="#4a90c2", stipple="gray25", outline="#8ecae6", width=3)
            c.create_oval(sx - r + 8, sy - r + 4, sx + r - 8, sy + r - 12, outline="#d8f1ff", width=1)
        a = self.aim()
        tip = (sx + math.cos(a) * 46, sy + math.sin(a) * 46)
        l, r = a + 2.7, a - 2.7
        c.create_polygon(tip[0], tip[1], tip[0] + math.cos(l) * 9, tip[1] + math.sin(l) * 9,
                         tip[0] + math.cos(r) * 9, tip[1] + math.sin(r) * 9, fill="#ffd166", outline="")

    def _draw_enemy(self, c, e):
        z = SPRITE_SPECS[e.name].get("zoom", 4)
        fr = (1, 0, 3, 0)[int(e.anim * 7) % 4] if e.moved else 0
        boss = e.ai == "boss"
        if boss:
            self._draw_boss_aura(c, e)
        sx, sy = self._actor(c, e.name, e.facing, fr, e.x, e.y - (4 + 3 * math.sin(self.now * 2.5) if boss else 0), z)
        if e.frozen_time > 0:
            c.create_rectangle(sx - 4 * z, sy - 9 * z, sx + 4 * z, sy + 7 * z, fill="#a8dadc", stipple="gray50", outline="#a8dadc")
        if e.windup > 0:
            c.create_text(sx, sy - 11 * z, text="!", fill="#ff0000", font=self.font_huge)
        bw, top = max(26, z * 10), sy - 9 * z - 8
        c.create_rectangle(sx - bw / 2, top, sx + bw / 2, top + 4, fill="#2b2d42", outline="#000000")
        c.create_rectangle(sx - bw / 2, top, sx - bw / 2 + bw * max(0.0, e.hp / e.max_hp), top + 4,
                           fill="#e63946", outline="")

    def _draw_boss_aura(self, c, e):
        """Aura abisal del jefe: halo que late, anillo runico y brasas que orbitan (mas intensos al enfurecer)."""
        sx, sy = e.x - self.cx, e.y - self.cy - 10
        enr = e.hp <= e.max_hp * 0.5
        now = self.now
        r = 78 + 7 * math.sin(now * 2.2)
        c.create_oval(sx - r, sy - r * 0.8 + 10, sx + r, sy + r * 0.8 + 10, fill="#4a0a2a" if not enr else "#7a0a1e",
                      stipple="gray12", outline="")
        c.create_oval(sx - r * 0.7, sy - r * 0.56 + 10, sx + r * 0.7, sy + r * 0.56 + 10, fill="#6a0f36" if not enr else "#a00c24",
                      stipple="gray25", outline="")
        c.create_oval(sx - 96, sy + 24, sx + 96, sy + 70, outline="#b5179e" if not enr else "#ff1744", width=2)
        for k in range(5):                       # runas sobre el suelo
            a = now * 0.6 + k * 1.2566
            c.create_rectangle(sx + math.cos(a) * 96 - 2, sy + 47 + math.sin(a) * 23 - 2,
                               sx + math.cos(a) * 96 + 2, sy + 47 + math.sin(a) * 23 + 2, fill="#ff4d6d", outline="")
        for k in range(10 if enr else 7):
            a = now * 1.3 + k * 6.2832 / (10 if enr else 7)
            rr = 74 + 10 * math.sin(now * 3 + k)
            ex, ey = sx + math.cos(a) * rr, sy + math.sin(a) * rr * 0.6 - 6
            c.create_rectangle(ex - 2, ey - 2, ex + 2, ey + 2, fill="#ff3b6b" if k % 2 else "#ffd23f", outline="")

    def _draw_drop(self, c, it):
        ix, iy, obj = it
        sx, sy = ix - self.cx, iy - self.cy + math.sin(self.now * 3 + ix) * 3
        if isinstance(obj, GoldPile):
            lvl = 0 if obj.amount < 15 else (1 if obj.amount < 50 else 2)
            c.create_oval(sx - 11, sy + 8, sx + 11, sy + 15, fill="#000000", stipple="gray50", outline="")
            img = self.icons.piles[lvl] if lvl or obj.amount >= 8 else self.icons.coins[int(self.now * 8 + ix) % 4]
            c.create_image(sx, sy - 4, image=img)
            return
        if isinstance(obj, str):                          # pocion de vida: botella con brillo
            c.create_oval(sx - 11, sy + 6, sx + 11, sy + 14, fill="#000000", stipple="gray50", outline="")
            c.create_oval(sx - 18, sy - 22, sx + 18, sy + 14, fill="#ff4d6d", stipple="gray12", outline="")
            c.create_image(sx, sy - 4, image=self.icons.potion)
            return
        else:
            col, name, rare = RARITY_COLORS[obj.rarity], obj.name, obj.rarity in ("Raro", "Épico", "Legendario")
        if rare:
            c.create_line(sx, sy - 10, sx, sy - 40, fill=col, width=2)
        c.create_polygon(sx, sy - 9, sx + 7, sy, sx, sy + 9, sx - 7, sy, fill=col, outline="#ffffff")
        if name and math.hypot(ix - self.player.x, iy - self.player.y) < 120:
            c.create_text(sx, sy - 18, text=name, fill=col, font=self.font_small)

    def _draw_proj(self, c, pr):
        sx, sy = pr.x - self.cx, pr.y - self.cy
        a = math.atan2(pr.vy, pr.vx)
        ca, sa = math.cos(a), math.sin(a)

        def T(pts):
            out = []
            for u, v in pts:
                out += [sx + u * ca - v * sa, sy + u * sa + v * ca]
            return out
        t = pr.ptype
        if t == "dagger":
            c.create_polygon(T([(-12, 0), (-4, -3), (11, 0), (-4, 3)]), fill="#d8f3dc", outline="#52b788")
        elif t == "bolt":
            c.create_polygon(T([(-14, 0), (-2, -5), (11, 0), (-2, 5)]), fill="#4cc9f0", outline="#caf0f8")
            c.create_polygon(T([(-6, 0), (0, -2), (6, 0), (0, 2)]), fill="#ffffff", outline="")
        elif t == "fireball":
            c.create_polygon(T([(-16, 0), (-7, -8), (-2, -3), (4, -9), (7, -2), (13, 0), (7, 2), (4, 9), (-2, 3), (-7, 8)]),
                             fill="#fb8500", outline="#ffb703")
            c.create_polygon(T([(-7, 0), (-1, -4), (6, 0), (-1, 4)]), fill="#ffd23f", outline="")
        elif t == "arrow":
            c.create_line(T([(-12, 0), (8, 0)]), fill="#9ae6ff", width=2)
            c.create_polygon(T([(8, -3), (14, 0), (8, 3)]), fill="#ffffff", outline="")
        elif t == "orb":
            c.create_polygon(T([(-9, 0), (-3, -6), (2, -3), (8, 0), (2, 3), (-3, 6)]), fill="#ff7b00", outline="#ffd23f")
        else:
            c.create_polygon(T([(-9, 0), (0, -5), (10, 0), (0, 5)]), fill=pr.color, outline="#ffffff")

    def _draw_effect(self, c, ef):
        sx, sy = ef.x - self.cx, ef.y - self.cy
        t = 1.0 - ef.life / ef.max
        k = ef.kind
        if k == "arc":
            sweep, n, pts = min(1.0, t * 2.2), 10, []
            for i in range(n + 1):
                a = ef.ang - ef.dir * ef.span / 2 + ef.dir * ef.span * sweep * i / n
                pts += [sx + math.cos(a) * ef.r, sy + math.sin(a) * ef.r]
            c.create_line(pts, fill=ef.color, width=max(2, int(ef.width * (1 - t * 0.6))), capstyle="round", joinstyle="round")
            pts2 = [pts[i] * 1.0 for i in range(len(pts))]
            for i in range(0, len(pts2), 2):
                pts2[i] = sx + (pts[i] - sx) * 0.82
                pts2[i + 1] = sy + (pts[i + 1] - sy) * 0.82
            c.create_line(pts2, fill="#ffffff", width=2)
        elif k == "ring":
            r, pts = ef.r * (0.2 + 0.8 * min(1.0, t * 1.5)), []
            for i in range(21):
                a = i / 20 * 6.2832
                pts += [sx + math.cos(a) * r, sy + math.sin(a) * r]
            c.create_line(pts, fill=ef.color, width=max(1, int(5 * (1 - t))))
        elif k == "spin":
            rot = self.now * 16
            for i in range(3):
                a = rot + i * 2.0944
                ux, uy = math.cos(a), math.sin(a)
                vx, vy = -uy, ux
                c.create_polygon(sx + ux * 30, sy + uy * 30, sx + ux * 70 + vx * 10, sy + uy * 70 + vy * 10,
                                 sx + ux * 122, sy + uy * 122, sx + ux * 70 - vx * 10, sy + uy * 70 - vy * 10,
                                 fill="#dfe6ee", outline="#ffb703", width=2)
            pts = []
            for i in range(25):
                a = i / 24 * 6.2832
                pts += [sx + math.cos(a) * 105, sy + math.sin(a) * 105]
            c.create_line(pts, fill="#ffb703", width=2, dash=(6, 6))
        elif k == "meteor":
            r, pts = ef.r * (0.35 + 0.65 * t), []
            for i in range(19):
                a = i / 18 * 6.2832
                pts += [sx + math.cos(a) * r, sy + math.sin(a) * r * 0.7]
            c.create_line(pts, fill="#ff4d00", width=2)
            c.create_line(sx - 8, sy, sx + 8, sy, fill="#ff4d00")
            fy = sy - ef.life * 520
            c.create_line(sx, fy - 10, sx, fy - 80, fill="#ff8c1a", width=8, capstyle="round")
            c.create_polygon(sx, fy - 20, sx + 7, fy - 8, sx + 18, fy - 10, sx + 10, fy, sx + 18, fy + 10, sx + 7, fy + 8,
                             sx, fy + 22, sx - 7, fy + 8, sx - 18, fy + 10, sx - 10, fy, sx - 18, fy - 10, sx - 7, fy - 8,
                             fill="#fb8500", outline="#ffd23f")
        elif k == "line":
            w = max(1, int(7 * ef.life / ef.max))
            c.create_line(sx, sy, ef.x2 - self.cx, ef.y2 - self.cy, fill=ef.color, width=w + 2)
            c.create_line(sx, sy, ef.x2 - self.cx, ef.y2 - self.cy, fill="#ffffff", width=1)
