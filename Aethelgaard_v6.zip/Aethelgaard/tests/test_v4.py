# -*- coding: utf-8 -*-
"""Pruebas v4: mapa solo de rectangulos, sala del jefe cuadrada con entrada que se sella, jefe nerfeado, audio."""
import random
import sys
import types
import unittest

from tests._helpers import have_tk, install_fake_tk

install_fake_tk()
from world.dungeon import DungeonMap, BOSS_ROOM_SIZE, TILE_FLOOR, TILE_WALL  # noqa: E402


class TestRectMap(unittest.TestCase):
    def test_all_rooms_rect_and_valid(self):
        for fl in list(range(1, 11)) * 6:
            d = DungeonMap(fl)
            self.assertEqual(d.problems, [], "piso %d" % fl)
            for r in d.rooms:
                self.assertEqual(r.shape, "rect")
                self.assertEqual(len(r.cells), r.w * r.h)

    def test_boss_room_is_square_with_single_entrance(self):
        for _ in range(30):
            d = DungeonMap(5)
            r = d.boss_room
            self.assertEqual((r.w, r.h), (BOSS_ROOM_SIZE, BOSS_ROOM_SIZE))
            self.assertIs(r, d.rooms[-1])
            self.assertIn(d.stairs_pos, r.cells)
            self.assertTrue(1 <= len(d.boss_door) <= 3)
            self.assertEqual(d.boss_door, d._room_ring_floor(r))
            # sellada la entrada, la sala queda cerrada: el spawn ya no llega a ninguna celda de la sala
            for (x, y) in d.boss_door:
                d.tiles[x][y] = TILE_WALL
            reach = d._reachable(d.spawn_pos)
            self.assertFalse(reach & set(r.cells))

    def test_non_boss_floor_has_no_boss_room(self):
        self.assertIsNone(DungeonMap(3).boss_room)


@unittest.skipUnless(have_tk(), "sin tkinter")
class TestBossGate(unittest.TestCase):
    def _engine(self, seed):
        from tests.test_engine_headless import TestEngineHeadless
        random.seed(seed)
        eng = TestEngineHeadless("build").build("Guerrero")
        eng.load_floor(5)
        return eng

    def test_gate_seals_on_enter_and_reopens_on_boss_death(self):
        eng = self._engine(11)
        d, p = eng.dungeon, eng.player
        r = d.boss_room
        eng.update_simulation(0.016)
        self.assertFalse(d.boss_sealed)                       # en el spawn no se cierra
        p.x, p.y = (r.x + 3) * 48 + 24, (r.y + 3) * 48 + 24   # dentro de la arena
        eng.update_simulation(0.016)
        self.assertTrue(d.boss_sealed)
        for (x, y) in d.boss_door:
            self.assertEqual(d.tiles[x][y], TILE_WALL)
        for e in eng.enemies:
            if e.ai == "boss":
                eng.kill_enemy(e)
        eng.update_simulation(0.016)
        self.assertFalse(d.boss_sealed)
        for (x, y) in d.boss_door:
            self.assertEqual(d.tiles[x][y], TILE_FLOOR)


class TestAudioStop(unittest.TestCase):
    def test_stop_uses_playsound_none_not_only_purge(self):
        import audio.music as m
        calls = []
        fake = types.SimpleNamespace(SND_ASYNC=1, SND_PURGE=2, SND_FILENAME=4, SND_LOOP=8,
                                     PlaySound=lambda snd, fl: calls.append((snd, fl)))
        old = (m.winsound, m.HAS_WINSOUND)
        m.winsound, m.HAS_WINSOUND = fake, True
        try:
            m.MusicEngine._stop_winsound()
        finally:
            m.winsound, m.HAS_WINSOUND = old
        self.assertIn((None, 1), calls)                        # PlaySound(None, SND_ASYNC) si corta el loop


if __name__ == "__main__":
    unittest.main()
