# Chronicles of Aethelgaard: The Abyssal Citadel

ARPG / dungeon crawler roguelike en Python + Tkinter (sin paquetes externos).

## Instalación y ejecución (Windows)
1. Instalá Python 3.8+ desde python.org (el instalador incluye Tkinter).
2. Extraé el ZIP y, desde la carpeta raíz, ejecutá `ejecutar.bat` o:
   `python main.py`
3. Pruebas (opcional): `python -m unittest discover -s tests -t . -v`

En Linux/macOS corre igual (`python3 main.py`) pero sin audio (usa `winsound`).

## Controles
WASD/flechas mover · SHIFT sprint · ESPACIO dash · L defensa · X/C/Z ataque base/fuerte/definitivo ·
mouse apuntar · Q poción · I mochila · T talentos · B tienda · G guía · P autoapuntado · M música ·
O pausa · F11 pantalla completa · ESC cierra el menú abierto o reanuda la pausa (los menús ocupan toda la pantalla y pausan el juego).

**O = pausa** (antes abría el menú de opciones, que se quitó). Con el juego pausado solo O / Esc reanudan.

## Gráficos (v6)
Personajes y enemigos: el mismo pixel art 16x16 de la versión original; el **Señor del Abismo** (jefe) es un diseño nuevo en ese estilo
(cuernos, alas, núcleo rúnico, espadón). Escenarios en estilo caricatura seria: losas y ladrillos con contorno grueso, colores planos
y luz arriba-izquierda. Las botellas de poción y el oro (monedas y montones) tienen diseño propio (`graphics/icons.py`).
Música propia: poné un .mp3 en `assets/music/` y suena en lugar de la generada.

## Defensa [L]
Mantené **L** para cubrirte: absorbés el 80 % del daño, pero no atacás, no corrés y caminás lento. La barra de defensa (donde estaba
el maná) se gasta mientras te cubrís y con cada golpe absorbido; si se vacía la guardia se rompe hasta recuperar un 30 %. Al soltar
espera 1,5 s y se recupera lento. Ya no hay maná, pociones de maná ni robo de vida.

## Jefe del piso 5
Vive solo en una sala **cuadrada** (13x13) con una única entrada y las escaleras al piso siguiente. Al entrar, **la entrada se
sella** hasta que lo derrotes. Tiene 1,25x de vida (antes 2,4x), +15 % de daño, +5 % de velocidad, tres patrones de ataque,
casi no se congela, invoca esbirros al 75/50/25 % de vida y da el doble de oro. Las escaleras no funcionan hasta derrotarlo.
Los valores se ajustan en `combat/enemies.py` (`HARD_BOSS_HP_MULT`, `HARD_BOSS_DMG_MULT`, `HARD_BOSS_SPEED_MULT`).

## Mapa
Todas las salas son rectángulos y los pasillos son tramos rectos (sin salas redondas, en cruz ni biseladas, sin erosión).

## Estructura
| Carpeta | Contenido |
|---|---|
| `main.py` | punto de entrada |
| `game/` | `engine.py` (estado, entrada, simulación), `assets.py` (rutas, log, recursos externos) |
| `player/` | clases y jugador |
| `combat/` | enemigos/IA, entidades, habilidades y daño, grilla espacial |
| `world/` | generador de mazmorras, validación, paletas por piso |
| `graphics/` | texturas, sprites poligonales, render del mundo |
| `audio/` | efectos y música sintetizada |
| `ui/` | paneles, HUD, tema, textos de ayuda |
| `inventory/` | objetos y afijos |
| `assets/` | recursos externos opcionales (ver `assets/README.txt`) |
| `logs/` | `game.log` |
| `tests/` | pruebas |
| `docs/` | `juego_v3_original.py` (respaldo intacto) y `CAMBIOS.md` |

Detalle de los cambios: `docs/CAMBIOS.md`.
