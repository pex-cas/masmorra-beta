# -*- coding: utf-8 -*-
"""Audio: efectos y musica. winsound solo existe en Windows; sin el, el juego corre en silencio."""
try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    winsound = None
    HAS_WINSOUND = False
