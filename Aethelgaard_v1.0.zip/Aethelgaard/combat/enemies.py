# -*- coding: utf-8 -*-
"""Enemigos e inteligencia artificial."""
import math
import random
from audio.sfx import AUDIO
from combat.entities import Projectile


# ==============================================================================
ENEMY_ARCHETYPES = {
    "Esqueleto": {"hp": 35, "dmg": 8, "speed": 95, "xp": 15, "ai": "swarmer", "radius": 14},
    "Zombi Pútrido": {"hp": 65, "dmg": 14, "speed": 65, "xp": 22, "ai": "tank", "radius": 17},
    "Arquero Espectral": {"hp": 28, "dmg": 10, "speed": 110, "xp": 25, "ai": "ranger", "radius": 13},
    "Mago de Fuego": {"hp": 40, "dmg": 16, "speed": 90, "xp": 35, "ai": "caster", "radius": 15},
    "Minotauro Brutal": {"hp": 130, "dmg": 24, "speed": 125, "xp": 65, "ai": "charger", "radius": 22},
    "Señor del Abismo (JEFE)": {"hp": 550, "dmg": 28, "speed": 85, "xp": 350, "ai": "boss", "radius": 32},
    # Jefes de piso intermedio (reutilizan los sprites existentes; cada uno con su propio comportamiento)
    "Minotauro Rey": {"hp": 420, "dmg": 22, "speed": 105, "xp": 200, "ai": "boss", "radius": 26,
                      "sprite": "Minotauro Brutal", "kind": "charge"},
    "Reina Pútrida": {"hp": 520, "dmg": 16, "speed": 60, "xp": 250, "ai": "boss", "radius": 24,
                      "sprite": "Zombi Pútrido", "kind": "toxic"},
    "Rey Espectral": {"hp": 380, "dmg": 16, "speed": 120, "xp": 300, "ai": "boss", "radius": 20,
                      "sprite": "Arquero Espectral", "kind": "archer"},
    "Archimago Ígneo": {"hp": 450, "dmg": 20, "speed": 85, "xp": 350, "ai": "boss", "radius": 22,
                        "sprite": "Mago de Fuego", "kind": "mage"},
}
BOSS_BY_FLOOR = {2: "Minotauro Rey", 4: "Reina Pútrida", 6: "Rey Espectral", 8: "Archimago Ígneo"}
HARD_BOSS_FLOORS = (5, 10)   # el piso 10 es el jefe final, extremadamente dificil


HARD_BOSS_FLOOR = 5          # el jefe de este piso es la version dificil
HARD_BOSS_HP_MULT = 2.15     # antes 2.4 (~2480 de vida): ahora ~1290
BOSS_DMG_NERF = 0.80          # todos los jefes hacen un 20% menos de dano
HARD_BOSS_DMG_MULT = 1.55    # antes 1.35
HARD_BOSS_SPEED_MULT = 1.12  # antes 1.15


class Enemy:
    def __init__(self, x, y, name, floor=1):
        cfg = ENEMY_ARCHETYPES[name]
        self.name, self.ai = name, cfg["ai"]
        self.sprite, self.kind = cfg.get("sprite", name), cfg.get("kind")
        self.title = name.replace(" (JEFE)", "").upper()
        self.x, self.y = float(x), float(y)
        self.radius = cfg["radius"]
        mult = 1.0 + (floor - 1) * 0.22
        self.max_hp = int(cfg["hp"] * mult)
        self.hp = float(self.max_hp)
        self.dmg = int(cfg["dmg"] * mult * 1.28)
        self.speed = cfg["speed"] + floor * 2
        # Jefe del piso 5: version "dificil" (mas vida, dano y velocidad, tercer patron, invocaciones, casi inmune al hielo)
        self.hard = self.ai == "boss" and self.kind is None and floor in HARD_BOSS_FLOORS
        if self.hard:
            self.max_hp = int(self.max_hp * HARD_BOSS_HP_MULT)
            self.hp = float(self.max_hp)
            self.dmg = int(self.dmg * HARD_BOSS_DMG_MULT)
            self.speed *= HARD_BOSS_SPEED_MULT
        if self.ai == "boss":
            self.dmg = max(1, int(self.dmg * BOSS_DMG_NERF))
        self.summon_marks = [0.75, 0.50, 0.25] if self.hard else []
        self.pending_summons = 0
        self.xp_reward = int(cfg["xp"] * mult)
        self.gold_reward = int((min(65, random.randint(8, 28 + floor * 3)) if self.ai != "boss" else random.randint(28, 58 + floor * 5)) * 0.75)
        self.attack_cd = random.uniform(0.2, 1.2)
        self.melee_cd = 0.0
        self.charge_timer = self.windup = 0.0
        self.cdx = self.cdy = 0.0
        self.pattern = 0
        self.casts = 0
        self.dead = False
        self.frozen_time = self.burn_time = 0.0
        self.kvx = self.kvy = 0.0
        self.anim = random.uniform(0, 5)
        self.facing = "R"
        self.moved = False

    def _move(self, mx, my, d):
        r = min(self.radius * 0.6, 20)
        ok = False
        if d.can_move(self.x + mx, self.y, r):
            self.x += mx
            ok = True
        if d.can_move(self.x, self.y + my, r):
            self.y += my
            ok = True
        if ok:
            self.moved = True
        return ok

    def update(self, dt, player, d, projectiles):
        if self.dead:
            return
        self.anim += dt
        if abs(self.kvx) + abs(self.kvy) > 5:
            self._move(self.kvx * dt, self.kvy * dt, d)
            k = max(0.0, 1.0 - 9.0 * dt)
            self.kvx *= k
            self.kvy *= k
        self.moved = False

        if self.burn_time > 0:
            self.burn_time -= dt
            self.hp -= 8 * dt
        if self.hard and self.frozen_time > 0.3:
            self.frozen_time = 0.3                    # el jefe dificil apenas se congela
        if self.frozen_time > 0:
            self.frozen_time -= dt
            return

        self.attack_cd -= dt
        self.melee_cd -= dt
        dx, dy = player.x - self.x, player.y - self.y
        dist = math.hypot(dx, dy)
        if dist > 520 or dist < 0.001:
            return
        ux, uy = dx / dist, dy / dist
        self.facing = "R" if ux >= 0 else "L"
        sp = self.speed * dt
        touch = self.radius + player.radius * 0.8 + 4

        if self.ai in ("swarmer", "tank"):
            if dist > touch:
                self._move(ux * sp, uy * sp, d)
            elif self.attack_cd <= 0:
                player.take_damage(self.dmg)
                self.attack_cd = 1.1

        elif self.ai == "ranger":
            if dist < 180:
                self._move(-ux * sp, -uy * sp, d)
            elif dist > 260:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0 and dist < 360:
                projectiles.append(Projectile(self.x, self.y, ux * 280, uy * 280, self.dmg, False,
                                              "#9ae6ff", "arrow", 4))
                self.attack_cd = 1.8

        elif self.ai == "caster":
            if dist < 210:
                self._move(-ux * sp, -uy * sp, d)
            elif dist > 300:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0 and dist < 380:
                self.casts += 1
                spreads = (-0.25, 0, 0.25) if self.casts % 3 == 0 else (0,)
                a = math.atan2(uy, ux)
                for s in spreads:
                    projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 210, math.sin(a + s) * 210,
                                                  self.dmg, False, "#ff7b00", "orb", 7))
                self.attack_cd = 2.3

        elif self.ai == "charger":
            if self.charge_timer > 0:
                self.charge_timer -= dt
                if not self._move(self.cdx * self.speed * 2.8 * dt, self.cdy * self.speed * 2.8 * dt, d):
                    self.charge_timer = 0
                if dist < touch:
                    player.take_damage(self.dmg * 1.4)
                    self.charge_timer = 0
            elif self.windup > 0:
                self.windup -= dt
                if self.windup <= 0:
                    self.charge_timer = 0.55
            elif dist < 300 and self.attack_cd <= 0:
                self.cdx, self.cdy = ux, uy
                self.windup = 0.55
                self.attack_cd = 3.4
            else:
                self._move(ux * sp * 0.7, uy * sp * 0.7, d)

        elif self.ai == "boss" and self.kind:
            self._boss_kind(dt, ux, uy, dist, sp, touch, player, d, projectiles)

        elif self.ai == "boss":
            while self.summon_marks and self.hp <= self.max_hp * self.summon_marks[0]:
                self.summon_marks.pop(0)
                self.pending_summons += 2             # el motor crea los esbirros (ver GameEngine)
            if dist > 110:
                self._move(ux * sp, uy * sp, d)
            if dist < touch + 8 and self.melee_cd <= 0:
                player.take_damage(self.dmg * 1.2)
                self.melee_cd = 0.8 if self.hard else 1.0
            if self.attack_cd <= 0 and self.hard:
                self._hard_boss_attack(ux, uy, projectiles)
            elif self.attack_cd <= 0:
                self.pattern ^= 1
                enraged = self.hp <= self.max_hp * 0.5
                if self.pattern:
                    n = 14 if enraged else 8
                    for b in range(n):
                        a = (b / n) * 2 * math.pi + (self.anim % 3)
                        projectiles.append(Projectile(self.x, self.y, math.cos(a) * 190, math.sin(a) * 190,
                                                      self.dmg, False, "#b5179e", "shard", 6, duration=4.0))
                else:
                    a = math.atan2(uy, ux)
                    for s in ((-0.4, -0.2, 0, 0.2, 0.4) if enraged else (-0.25, 0, 0.25)):
                        projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 270, math.sin(a + s) * 270,
                                                      self.dmg, False, "#e0aaff", "shard", 6, duration=3.0))
                self.attack_cd = 1.6 if enraged else 2.1
                AUDIO.play_sfx("boss_roar")

    def _shoot(self, pr, a, spd, col, pt="shard", r=6, dur=3.0):
        pr.append(Projectile(self.x, self.y, math.cos(a) * spd, math.sin(a) * spd, self.dmg, False, col, pt, r, duration=dur))

    def _ring(self, pr, n, spd, col, off=0.0, pt="shard"):
        for b in range(n):
            self._shoot(pr, b * 6.2832 / n + off, spd, col, pt, dur=3.5)

    def _blink(self, player, d, rmin, rmax):
        for _ in range(16):
            a, r = random.uniform(0, 6.2832), random.uniform(rmin, rmax)
            x, y = player.x + math.cos(a) * r, player.y + math.sin(a) * r
            if d.can_move(x, y, self.radius * 0.6):
                self.x, self.y = x, y
                return

    def _boss_kind(self, dt, ux, uy, dist, sp, touch, player, d, pr):
        """Jefes de piso de jefe: cada `kind` tiene su propio patron de ataque."""
        enr = self.hp <= self.max_hp * 0.5
        k, a = self.kind, math.atan2(uy, ux)
        if k in ("charge", "toxic") and dist < touch + 8 and self.melee_cd <= 0:
            player.take_damage(self.dmg * 1.2)
            self.melee_cd = 1.0
        if k == "charge":                       # embestidas con aviso + onda de proyectiles al chocar
            if self.charge_timer > 0:
                self.charge_timer -= dt
                blocked = not self._move(self.cdx * self.speed * 3.2 * dt, self.cdy * self.speed * 3.2 * dt, d)
                if dist < touch:
                    player.take_damage(self.dmg * 1.5)
                    blocked = True
                if blocked or self.charge_timer <= 0:
                    self.charge_timer, self.attack_cd = 0.0, 1.2
                    self._ring(pr, 12 if enr else 8, 220, "#ff9e00")
                    AUDIO.play_sfx("boss_roar")
            elif self.windup > 0:
                self.windup -= dt
                if self.windup <= 0:
                    self.charge_timer = 0.8
            elif self.attack_cd <= 0:
                self.pattern = (self.pattern + 1) % 3
                if self.pattern == 1:
                    for s in (-0.3, -0.15, 0, 0.15, 0.3):
                        self._shoot(pr, a + s, 300, "#ff9e00")
                    self.attack_cd = 1.4
                else:
                    self.cdx, self.cdy = ux, uy
                    self.windup = 0.45 if enr else 0.6
            elif dist > touch:
                self._move(ux * sp * 0.8, uy * sp * 0.8, d)
        elif k == "toxic":                      # lenta: orbes venenosos, anillos y esbirros
            if dist > touch:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0:
                self.pattern = (self.pattern + 1) % 3
                if self.pattern == 0:
                    for s in (-0.35, 0, 0.35):
                        self._shoot(pr, a + s, 170, "#4dff88", "orb", 9, 3.5)
                elif self.pattern == 1:
                    self._ring(pr, 16 if enr else 12, 140, "#80ed99", self.anim % 3)
                else:
                    self.pending_summons = 2
                self.attack_cd = 1.4 if enr else 2.0
                AUDIO.play_sfx("boss_roar")
        elif k == "archer":                     # distancia, abanicos, teletransporte
            if dist < 200:
                self._move(-ux * sp * 1.2, -uy * sp * 1.2, d)
            elif dist > 320:
                self._move(ux * sp, uy * sp, d)
            else:
                sg = 1 if int(self.anim // 2) % 2 else -1
                self._move(-uy * sp * 0.8 * sg, ux * sp * 0.8 * sg, d)
            if self.attack_cd <= 0:
                self.pattern = (self.pattern + 1) % 3
                if self.pattern == 0:
                    for s in ((-0.45, -0.3, -0.15, 0, 0.15, 0.3, 0.45) if enr else (-0.3, -0.15, 0, 0.15, 0.3)):
                        self._shoot(pr, a + s, 340, "#9ae6ff", "arrow", 4)
                elif self.pattern == 1:
                    self._blink(player, d, 170, 260)
                    self._ring(pr, 10, 200, "#9ae6ff", 0.0, "arrow")
                else:
                    for spd in (300, 370, 440):
                        self._shoot(pr, a, spd, "#caf0f8", "arrow", 4)
                self.attack_cd = 1.0 if enr else 1.5
                AUDIO.play_sfx("boss_roar")
        elif k == "mage":                       # espirales, bolas de fuego y nova tras teletransportarse
            if dist < 220:
                self._move(-ux * sp, -uy * sp, d)
            elif dist > 320:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0:
                self.pattern = (self.pattern + 1) % 3
                if self.pattern == 0:
                    for arm in range(3):
                        for j in range(5):
                            self._shoot(pr, self.anim * 2 + arm * 2.094 + j * 0.12, 140 + j * 28, "#ff7b00", "shard", 6, 3.5)
                elif self.pattern == 1:
                    for s in (-0.2, 0, 0.2):
                        self._shoot(pr, a + s, 230, "#ff7b00", "fireball", 8, 3.0)
                else:
                    self._blink(player, d, 250, 330)
                    self._ring(pr, 16, 190, "#ffd23f")
                self.attack_cd = 1.2 if enr else 1.7
                AUDIO.play_sfx("boss_roar")

    def _hard_boss_attack(self, ux, uy, projectiles):
        """Tres patrones rotativos: abanico dirigido, anillo y doble espiral. Mas rapido y denso al enfurecer."""
        enraged = self.hp <= self.max_hp * 0.5
        self.pattern = (self.pattern + 1) % 3
        if self.pattern == 0:
            a = math.atan2(uy, ux)
            spread = (-0.5, -0.33, -0.17, 0, 0.17, 0.33, 0.5) if enraged else (-0.3, -0.15, 0, 0.15, 0.3)
            for s in spread:
                projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 320, math.sin(a + s) * 320,
                                              self.dmg, False, "#e0aaff", "shard", 6, duration=3.0))
        elif self.pattern == 1:
            n = 18 if enraged else 12
            for b in range(n):
                a = (b / n) * 2 * math.pi + (self.anim % 3)
                projectiles.append(Projectile(self.x, self.y, math.cos(a) * 210, math.sin(a) * 210,
                                              self.dmg, False, "#b5179e", "shard", 6, duration=4.0))
        else:
            n = 10 if enraged else 7
            for ring, spd in ((0.0, 160), (math.pi / n, 250)):
                for b in range(n):
                    a = (b / n) * 2 * math.pi + ring + (self.anim % 2)
                    projectiles.append(Projectile(self.x, self.y, math.cos(a) * spd, math.sin(a) * spd,
                                                  self.dmg, False, "#ff006e", "shard", 6, duration=4.0))
        self.attack_cd = 1.15 if enraged else 1.6
        AUDIO.play_sfx("boss_roar")
