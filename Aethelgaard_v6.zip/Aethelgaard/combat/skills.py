# -*- coding: utf-8 -*-
"""Ataques X/C/Z, dano, muertes, explosiones y paredes secretas."""

import math
import random
from audio.sfx import AUDIO
from combat.entities import Effect, FloatingText, GoldPile, Particle, Projectile
from player.player import CLASS_CONFIGS
from world.dungeon import TILE_FLOOR


class CombatMixin:
    # ------------------------------------------------------------------ combate
    def roll(self, base, bonus=0.0):
        p = self.player
        crit = random.random() < p.crit_chance + bonus
        return int(base * (p.crit_mult if crit else 1.0)), crit

    def _pay(self, idx):
        p = self.player
        _, cd = CLASS_CONFIGS[p.char_class]["kit"][idx]
        p.cd[idx] = p.cd_max[idx] = cd * (1.0 - p.cdr) if idx > 0 else cd
        return True

    def cone_targets(self, x, y, ang, rng, half):
        out = []
        for e in self.spatial_grid.query_radius(x, y, rng + 40):
            if e.dead:
                continue
            dx, dy = e.x - x, e.y - y
            dist = math.hypot(dx, dy)
            if dist - e.radius > rng:
                continue
            if dist < e.radius + 8:
                out.append(e)
                continue
            da = math.atan2(dy, dx) - ang
            if abs(math.atan2(math.sin(da), math.cos(da))) <= half:
                out.append(e)
        return out

    def _shoot(self, ang, speed, dmg, crit, color, ptype, radius, pierce=1, aoe=0, burn=0.0, dur=1.8):
        p = self.player
        self.projectiles.append(Projectile(p.x + math.cos(ang) * 20, p.y + math.sin(ang) * 20,
                                           math.cos(ang) * speed, math.sin(ang) * speed, dmg, True,
                                           color, ptype, radius, pierce, dur, crit, aoe, burn))

    # ---- X : ataque base (spameable) -------------------------------------------
    def attack_base(self):
        p, ang = self.player, self.aim()
        self._pay(0)
        if p.char_class == "Guerrero":
            AUDIO.play_sfx("slash")
            self.hit_secret_walls(p.x, p.y, ang, 88, 1.05, 1)
            for e in self.cone_targets(p.x, p.y, ang, 88, 1.05):
                dmg, cr = self.roll(p.phys_dmg)
                self.damage_enemy(e, dmg, cr, kb=150, src=(p.x, p.y))
            p.swing_dir *= -1
            self.effects.append(Effect("arc", p.x, p.y, 0.2, ang=ang, r=62, span=2.1, width=10,
                                       color="#ffffff", dir=p.swing_dir))
        elif p.char_class == "Mago":
            AUDIO.play_sfx("fireball")
            dmg, cr = self.roll(p.mag_dmg)
            self._shoot(ang, 520, dmg, cr, "#4cc9f0", "bolt", 6, dur=1.6)
        else:
            AUDIO.play_sfx("slash")
            dmg, cr = self.roll(p.phys_dmg * 0.8, 0.10)
            self._shoot(ang + random.uniform(-0.04, 0.04), 640, dmg, cr, "#d8f3dc", "dagger", 5, dur=1.4)

    # ---- C : ataque fuerte (cooldown) ------------------------------------------
    def attack_strong(self):
        p, ang = self.player, self.aim()
        if not self._pay(1):
            return
        if p.char_class == "Guerrero":
            AUDIO.play_sfx("heavy")
            self.hit_secret_walls(p.x, p.y, ang, 135, 0.95, 2)
            for e in self.cone_targets(p.x, p.y, ang, 135, 0.95):
                dmg, cr = self.roll(p.phys_dmg * 2.4)
                self.damage_enemy(e, dmg, cr, kb=320, src=(p.x, p.y))
                e.frozen_time = max(e.frozen_time, 1.2)
            self.effects.append(Effect("arc", p.x, p.y, 0.35, ang=ang, r=105, span=1.9, width=18,
                                       color="#ffb703", dir=1))
            self.effects.append(Effect("ring", p.x + math.cos(ang) * 80, p.y + math.sin(ang) * 80, 0.35,
                                       r=70, color="#ffb703"))
            for _ in range(16):
                a = ang + random.uniform(-0.9, 0.9)
                s = random.uniform(60, 220)
                self.particles.append(Particle(p.x, p.y + 12, math.cos(a) * s, math.sin(a) * s, 0.4, "#c9b79c", 4))
            self.shake = max(self.shake, 0.25)
        elif p.char_class == "Mago":
            AUDIO.play_sfx("fireball")
            dmg, cr = self.roll(p.mag_dmg * 2.6)
            self._shoot(ang, 380, dmg, cr, "#fb8500", "fireball", 10, aoe=95, burn=3.0, dur=2.2)
        else:
            AUDIO.play_sfx("slash")
            for i in range(7):
                dmg, cr = self.roll(p.phys_dmg * 1.0)
                self._shoot(ang + (i - 3) * 0.14, 600, dmg, cr, "#d8f3dc", "dagger", 5, pierce=2, dur=1.2)

    # ---- Z : ULTIMATE -----------------------------------------------------------
    def attack_ult(self):
        p, d = self.player, self.dungeon
        if p.char_class == "Guerrero":
            if not self._pay(2): return
            p.ult_time, p.ult_tick = 2.6, 0.0
            self.effects.append(Effect("spin", p.x, p.y, 2.6))
        elif p.char_class == "Mago":
            if not self._pay(2): return
            at = self.auto_target
            if self.autoaim and at is not None and not at.dead:
                tx, ty = at.x, at.y
            else:
                tx, ty = self.mouse_x + self.camera_x, self.mouse_y + self.camera_y
            for i in range(10):
                a = random.uniform(0, 2 * math.pi)
                rr = 170 * math.sqrt(random.random())
                delay = 0.35 + i * 0.19 + random.uniform(0, 0.1)
                self.effects.append(Effect("meteor", tx + math.cos(a) * rr, ty + math.sin(a) * rr, delay,
                                           r=78, dmg=int(p.mag_dmg * 3.4)))
        else:
            near = [e for e in self.enemies if not e.dead and math.hypot(e.x - p.x, e.y - p.y) < 400]
            if not near:
                self.add_floating_text(p.x, p.y - 34, "Sin objetivos", "#adb5bd")
                p.cd[2] = p.cd_max[2] = 0.5
                return
            if not self._pay(2): return
            cur, order = (p.x, p.y), []
            for _ in range(7):
                if not near: break
                nxt = min(near, key=lambda e: (e.x - cur[0]) ** 2 + (e.y - cur[1]) ** 2)
                near.remove(nxt)
                order.append(nxt)
                cur = (nxt.x, nxt.y)
            for e in order:
                ox, oy = p.x, p.y
                a = math.atan2(e.y - p.y, e.x - p.x)
                nx, ny = e.x - math.cos(a) * 28, e.y - math.sin(a) * 28
                if d.can_move(nx, ny, p.radius * 0.6):
                    p.x, p.y = nx, ny
                self.effects.append(Effect("line", ox, oy, 0.35, x2=p.x, y2=p.y, color="#b7e4c7"))
                self.damage_enemy(e, int(p.phys_dmg * 3.0 * p.crit_mult), True, kb=120, src=(ox, oy))
            p.invuln = max(p.invuln, 0.8)
        AUDIO.play_sfx("ult")
        self.shake = max(self.shake, 0.25)

    # ---- dano / muerte / explosiones ---------------------------------------------
    def damage_enemy(self, e, amount, crit=False, kb=0, src=None):
        if e.dead:
            return
        e.hp -= amount
        self.add_floating_text(e.x + random.randint(-8, 8), e.y - e.radius - 10,
                               f"{amount}!" if crit else str(amount), "#ffd166" if crit else "#ffffff")
        AUDIO.play_sfx("crit" if crit else "hit")
        for _ in range(4):
            self.particles.append(Particle(e.x, e.y, random.uniform(-80, 80), random.uniform(-80, 80), 0.3, "#ba181b", 3))
        if kb > 0 and src:
            dx, dy = e.x - src[0], e.y - src[1]
            dd = math.hypot(dx, dy) or 1.0
            k = kb * (14.0 / e.radius) * (0.3 if e.ai == "boss" else 1.0)
            e.kvx += dx / dd * k
            e.kvy += dy / dd * k
        p = self.player
        if p.freeze_chance > 0 and random.random() < p.freeze_chance:
            e.frozen_time = max(e.frozen_time, 1.0)
        if p.burn_dmg > 0:
            e.burn_time = max(e.burn_time, 2.0)
        if e.hp <= 0:
            self.kill_enemy(e)

    def kill_enemy(self, e):
        if e.dead:
            return
        e.dead = True
        p = self.player
        gg = int(e.gold_reward * (1.0 + p.gold_bonus))
        self.drop_gold(e.x, e.y, gg)
        if p.gain_xp(e.xp_reward):
            self.add_floating_text(p.x, p.y - 50, "¡NIVEL SUBIDO!", "#06d6a0")
            self.update_content_view()
        for _ in range(10):
            self.particles.append(Particle(e.x, e.y, random.uniform(-120, 120), random.uniform(-120, 120), 0.5,
                                           random.choice(("#e9ecef", "#ba181b", "#6c757d")), 4))
        r = random.random()
        if e.ai == "boss":
            bonus = (150 + 60 * self.floor) * (2 if e.hard else 1)   # el jefe ya no suelta equipo: da oro
            self.drop_gold(e.x, e.y + 20, bonus)
            self.add_floating_text(e.x, e.y, "¡JEFE DERROTADO!", "#ff5400")
            self.add_floating_text(e.x, e.y + 30, "Las escaleras de la sala están abiertas", "#4cc9f0")
            AUDIO.play_sfx("boss_roar")
            self.shake = 0.4
        elif 0.35 <= r < 0.47:
            self.dropped_items.append((e.x, e.y, "hp"))

    def explode(self, x, y, r, dmg, burn=0.0):
        AUDIO.play_sfx("meteor" if r >= 70 else "crit")
        tsz = self.dungeon.tile_size
        for (sx, sy) in list(self.dungeon.secrets.keys()):
            if math.hypot(sx * tsz + tsz / 2 - x, sy * tsz + tsz / 2 - y) <= r + tsz * 0.7:
                self.hit_secret(sx, sy, 2)
        for e in self.spatial_grid.query_radius(x, y, r + 34):
            if not e.dead and math.hypot(e.x - x, e.y - y) - e.radius <= r:
                self.damage_enemy(e, dmg, True, kb=220, src=(x, y))
                if burn:
                    e.burn_time = max(e.burn_time, burn)
        self.effects.append(Effect("ring", x, y, 0.4, r=r, color="#ff8c1a"))
        for _ in range(14):
            a, s = random.uniform(0, 6.283), random.uniform(60, 240)
            self.particles.append(Particle(x, y, math.cos(a) * s, math.sin(a) * s, 0.45,
                                           random.choice(("#ff8c1a", "#ffd23f", "#ff4d00")), 4))
        self.shake = max(self.shake, 0.18)

    # ---- paredes secretas ----------------------------------------------------------
    def hit_secret_walls(self, x, y, ang, rng, half, power=1):
        d = self.dungeon
        if not d.secrets:
            return
        ts = d.tile_size
        for (sx, sy) in list(d.secrets.keys()):
            dx, dy = sx * ts + ts / 2 - x, sy * ts + ts / 2 - y
            dist = math.hypot(dx, dy)
            if dist > rng + ts * 0.5:
                continue
            if dist > ts * 1.1:
                da = math.atan2(dy, dx) - ang
                if abs(math.atan2(math.sin(da), math.cos(da))) > half:
                    continue
            self.hit_secret(sx, sy, power)

    def hit_secret(self, sx, sy, power=1):
        d = self.dungeon
        info = d.secrets.get((sx, sy))
        if not info:
            return
        ts = d.tile_size
        wx, wy = sx * ts + ts / 2, sy * ts + ts / 2
        info["hp"] -= power
        for _ in range(7):
            a, s = random.uniform(0, 6.283), random.uniform(40, 170)
            self.particles.append(Particle(wx, wy, math.cos(a) * s, math.sin(a) * s, 0.5,
                                           random.choice(("#6f7f99", "#4a5870", "#9aa8bd")), 4))
        AUDIO.play_sfx("heavy")
        self.shake = max(self.shake, 0.1)
        if info["hp"] > 0:
            if not info["hit"]:
                info["hit"] = True
                self.add_floating_text(wx, wy - 30, "¡La pared se agrieta!", "#9bd0ff")
            return
        del d.secrets[(sx, sy)]
        d.tiles[sx][sy] = TILE_FLOOR
        d.rebake_around(sx, sy)
        d._last_ptile = None
        d.new_revealed.append((sx, sy))
        AUDIO.play_sfx("secret")
        self.shake = max(self.shake, 0.3)
        self.effects.append(Effect("ring", wx, wy, 0.5, r=80, color="#9bd0ff"))
        for _ in range(24):
            a, s = random.uniform(0, 6.283), random.uniform(60, 260)
            self.particles.append(Particle(wx, wy, math.cos(a) * s, math.sin(a) * s, 0.7,
                                           random.choice(("#6f7f99", "#4a5870", "#9aa8bd", "#ffd166")), 5))
        self.add_floating_text(wx, wy - 40, "¡PARED SECRETA!", "#ffd166")
        cx, cy = info["center"]
        bx, by = cx * ts + ts / 2, cy * ts + ts / 2
        bonus = 60 + 25 * self.floor                            # cámara secreta: oro extra + poción
        self.drop_gold(bx, by, bonus)
        self.dropped_items.append((bx + 14, by + 6, "hp"))

    def drop_gold(self, x, y, amount):
        """Suelta oro en el suelo (monedas / montones); si es mucho se reparte en varios montones."""
        amount = int(amount)
        if amount <= 0:
            return
        n = 1 if amount < 40 else (2 if amount < 120 else 4)
        for i in range(n):
            part = amount // n + (amount % n if i == 0 else 0)
            a = random.uniform(0, 6.283)
            r = 0 if n == 1 else random.uniform(10, 34)
            self.dropped_items.append((x + math.cos(a) * r, y + math.sin(a) * r, GoldPile(part)))

    def add_floating_text(self, x, y, text, color="#fff"):
        self.floating_texts.append(FloatingText(x, y, text, color))
