# -*- coding: utf-8 -*-
"""Enemigos e inteligencia artificial."""
import math
import random
from audio.sfx import AUDIO
from combat.entities import Projectile


# ==============================================================================
ENEMY_ARCHETYPES = {
    "Esqueleto": {"hp": 35, "dmg": 8, "speed": 95, "xp": 15, "ai": "swarmer", "radius": 14},
    "Zombi Pútrido": {"hp": 65, "dmg": 14, "speed": 65, "xp": 22, "ai": "tank", "radius": 17},
    "Arquero Espectral": {"hp": 28, "dmg": 10, "speed": 110, "xp": 25, "ai": "ranger", "radius": 13},
    "Mago de Fuego": {"hp": 40, "dmg": 16, "speed": 90, "xp": 35, "ai": "caster", "radius": 15},
    "Minotauro Brutal": {"hp": 130, "dmg": 24, "speed": 125, "xp": 65, "ai": "charger", "radius": 22},
    "Señor del Abismo (JEFE)": {"hp": 550, "dmg": 28, "speed": 85, "xp": 350, "ai": "boss", "radius": 32},
}


HARD_BOSS_FLOOR = 5          # el jefe de este piso es la version dificil
HARD_BOSS_HP_MULT = 1.25     # antes 2.4 (~2480 de vida): ahora ~1290
HARD_BOSS_DMG_MULT = 1.15    # antes 1.35
HARD_BOSS_SPEED_MULT = 1.05  # antes 1.15


class Enemy:
    def __init__(self, x, y, name, floor=1):
        cfg = ENEMY_ARCHETYPES[name]
        self.name, self.ai = name, cfg["ai"]
        self.x, self.y = float(x), float(y)
        self.radius = cfg["radius"]
        mult = 1.0 + (floor - 1) * 0.22
        self.max_hp = int(cfg["hp"] * mult)
        self.hp = float(self.max_hp)
        self.dmg = int(cfg["dmg"] * mult)
        self.speed = cfg["speed"] + floor * 2
        # Jefe del piso 5: version "dificil" (mas vida, dano y velocidad, tercer patron, invocaciones, casi inmune al hielo)
        self.hard = self.ai == "boss" and floor == HARD_BOSS_FLOOR
        if self.hard:
            self.max_hp = int(self.max_hp * HARD_BOSS_HP_MULT)
            self.hp = float(self.max_hp)
            self.dmg = int(self.dmg * HARD_BOSS_DMG_MULT)
            self.speed *= HARD_BOSS_SPEED_MULT
        self.summon_marks = [0.75, 0.50, 0.25] if self.hard else []
        self.pending_summons = 0
        self.xp_reward = int(cfg["xp"] * mult)
        self.gold_reward = random.randint(5, 12 + floor * 4)
        self.attack_cd = random.uniform(0.2, 1.2)
        self.melee_cd = 0.0
        self.charge_timer = self.windup = 0.0
        self.cdx = self.cdy = 0.0
        self.pattern = 0
        self.casts = 0
        self.dead = False
        self.frozen_time = self.burn_time = 0.0
        self.kvx = self.kvy = 0.0
        self.anim = random.uniform(0, 5)
        self.facing = "R"
        self.moved = False

    def _move(self, mx, my, d):
        r = min(self.radius * 0.6, 20)
        ok = False
        if d.can_move(self.x + mx, self.y, r):
            self.x += mx
            ok = True
        if d.can_move(self.x, self.y + my, r):
            self.y += my
            ok = True
        if ok:
            self.moved = True
        return ok

    def update(self, dt, player, d, projectiles):
        if self.dead:
            return
        self.anim += dt
        if abs(self.kvx) + abs(self.kvy) > 5:
            self._move(self.kvx * dt, self.kvy * dt, d)
            k = max(0.0, 1.0 - 9.0 * dt)
            self.kvx *= k
            self.kvy *= k
        self.moved = False

        if self.burn_time > 0:
            self.burn_time -= dt
            self.hp -= 8 * dt
        if self.hard and self.frozen_time > 0.3:
            self.frozen_time = 0.3                    # el jefe dificil apenas se congela
        if self.frozen_time > 0:
            self.frozen_time -= dt
            return

        self.attack_cd -= dt
        self.melee_cd -= dt
        dx, dy = player.x - self.x, player.y - self.y
        dist = math.hypot(dx, dy)
        if dist > 520 or dist < 0.001:
            return
        ux, uy = dx / dist, dy / dist
        self.facing = "R" if ux >= 0 else "L"
        sp = self.speed * dt
        touch = self.radius + player.radius * 0.8 + 4

        if self.ai in ("swarmer", "tank"):
            if dist > touch:
                self._move(ux * sp, uy * sp, d)
            elif self.attack_cd <= 0:
                player.take_damage(self.dmg)
                self.attack_cd = 1.1

        elif self.ai == "ranger":
            if dist < 180:
                self._move(-ux * sp, -uy * sp, d)
            elif dist > 260:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0 and dist < 360:
                projectiles.append(Projectile(self.x, self.y, ux * 280, uy * 280, self.dmg, False,
                                              "#9ae6ff", "arrow", 4))
                self.attack_cd = 1.8

        elif self.ai == "caster":
            if dist < 210:
                self._move(-ux * sp, -uy * sp, d)
            elif dist > 300:
                self._move(ux * sp, uy * sp, d)
            if self.attack_cd <= 0 and dist < 380:
                self.casts += 1
                spreads = (-0.25, 0, 0.25) if self.casts % 3 == 0 else (0,)
                a = math.atan2(uy, ux)
                for s in spreads:
                    projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 210, math.sin(a + s) * 210,
                                                  self.dmg, False, "#ff7b00", "orb", 7))
                self.attack_cd = 2.3

        elif self.ai == "charger":
            if self.charge_timer > 0:
                self.charge_timer -= dt
                if not self._move(self.cdx * self.speed * 2.8 * dt, self.cdy * self.speed * 2.8 * dt, d):
                    self.charge_timer = 0
                if dist < touch:
                    player.take_damage(self.dmg * 1.4)
                    self.charge_timer = 0
            elif self.windup > 0:
                self.windup -= dt
                if self.windup <= 0:
                    self.charge_timer = 0.55
            elif dist < 300 and self.attack_cd <= 0:
                self.cdx, self.cdy = ux, uy
                self.windup = 0.55
                self.attack_cd = 3.4
            else:
                self._move(ux * sp * 0.7, uy * sp * 0.7, d)

        elif self.ai == "boss":
            while self.summon_marks and self.hp <= self.max_hp * self.summon_marks[0]:
                self.summon_marks.pop(0)
                self.pending_summons += 2             # el motor crea los esbirros (ver GameEngine)
            if dist > 110:
                self._move(ux * sp, uy * sp, d)
            if dist < touch + 8 and self.melee_cd <= 0:
                player.take_damage(self.dmg * 1.2)
                self.melee_cd = 0.8 if self.hard else 1.0
            if self.attack_cd <= 0 and self.hard:
                self._hard_boss_attack(ux, uy, projectiles)
            elif self.attack_cd <= 0:
                self.pattern ^= 1
                enraged = self.hp <= self.max_hp * 0.5
                if self.pattern:
                    n = 14 if enraged else 8
                    for b in range(n):
                        a = (b / n) * 2 * math.pi + (self.anim % 3)
                        projectiles.append(Projectile(self.x, self.y, math.cos(a) * 190, math.sin(a) * 190,
                                                      self.dmg, False, "#b5179e", "shard", 6, duration=4.0))
                else:
                    a = math.atan2(uy, ux)
                    for s in ((-0.4, -0.2, 0, 0.2, 0.4) if enraged else (-0.25, 0, 0.25)):
                        projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 270, math.sin(a + s) * 270,
                                                      self.dmg, False, "#e0aaff", "shard", 6, duration=3.0))
                self.attack_cd = 1.6 if enraged else 2.1
                AUDIO.play_sfx("boss_roar")

    def _hard_boss_attack(self, ux, uy, projectiles):
        """Tres patrones rotativos: abanico dirigido, anillo y doble espiral. Mas rapido y denso al enfurecer."""
        enraged = self.hp <= self.max_hp * 0.5
        self.pattern = (self.pattern + 1) % 3
        if self.pattern == 0:
            a = math.atan2(uy, ux)
            spread = (-0.5, -0.33, -0.17, 0, 0.17, 0.33, 0.5) if enraged else (-0.3, -0.15, 0, 0.15, 0.3)
            for s in spread:
                projectiles.append(Projectile(self.x, self.y, math.cos(a + s) * 320, math.sin(a + s) * 320,
                                              self.dmg, False, "#e0aaff", "shard", 6, duration=3.0))
        elif self.pattern == 1:
            n = 18 if enraged else 12
            for b in range(n):
                a = (b / n) * 2 * math.pi + (self.anim % 3)
                projectiles.append(Projectile(self.x, self.y, math.cos(a) * 210, math.sin(a) * 210,
                                              self.dmg, False, "#b5179e", "shard", 6, duration=4.0))
        else:
            n = 10 if enraged else 7
            for ring, spd in ((0.0, 160), (math.pi / n, 250)):
                for b in range(n):
                    a = (b / n) * 2 * math.pi + ring + (self.anim % 2)
                    projectiles.append(Projectile(self.x, self.y, math.cos(a) * spd, math.sin(a) * spd,
                                                  self.dmg, False, "#ff006e", "shard", 6, duration=4.0))
        self.attack_cd = 1.15 if enraged else 1.6
        AUDIO.play_sfx("boss_roar")
