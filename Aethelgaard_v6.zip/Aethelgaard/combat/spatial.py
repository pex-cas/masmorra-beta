# -*- coding: utf-8 -*-
"""Grilla espacial para consultas por radio."""


class SpatialHashGrid:
    def __init__(self, cell_size=80):
        self.cell_size = cell_size
        self.grid = {}

    def clear(self):
        self.grid.clear()

    def insert(self, e):
        key = (int(e.x // self.cell_size), int(e.y // self.cell_size))
        self.grid.setdefault(key, []).append(e)

    def query_radius(self, x, y, radius):
        cs = self.cell_size
        res = []
        r_sq = radius * radius
        for cx in range(int((x - radius) // cs), int((x + radius) // cs) + 1):
            for cy in range(int((y - radius) // cs), int((y + radius) // cs) + 1):
                cell = self.grid.get((cx, cy))
                if cell:
                    for e in cell:
                        if (e.x - x) ** 2 + (e.y - y) ** 2 <= r_sq:
                            res.append(e)
        return res
