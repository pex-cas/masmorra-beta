# -*- coding: utf-8 -*-
"""Preferencias del jugador para musica y skins propias (se eligen DENTRO del juego, menu [O]).

- Musica: una cancion (.mp3/.wav/.wma) o una carpeta con varias. Reemplaza a la musica sintetizada.
- Skins: una carpeta con PNG nombrados como el personaje (guerrero.png, esqueleto.png...) y/o un PNG
  elegido para un personaje concreto. Los PNG miden 48x48 (clases), 64x64 (Minotauro) u 80x80 (jefe),
  o un multiplo exacto.
Todo se guarda en config/mods.json. Si una ruta ya no existe o el archivo esta danado, se ignora
(se registra en logs/game.log) y se usa el recurso original del juego.
"""
import json
import os

from game.assets import BASE_DIR, MUSIC_EXTS, log, slug

CONFIG_PATH = os.path.join(BASE_DIR, "config", "mods.json")
_cfg = {"music": None, "skin_dir": None, "skin_files": {}}


def load(path=None):
    """Lee la configuracion guardada (si no existe o esta rota, queda la de fabrica)."""
    global _cfg
    _cfg = {"music": None, "skin_dir": None, "skin_files": {}}
    try:
        with open(path or CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            _cfg["music"] = data.get("music") if isinstance(data.get("music"), str) else None
            _cfg["skin_dir"] = data.get("skin_dir") if isinstance(data.get("skin_dir"), str) else None
            sf = data.get("skin_files")
            if isinstance(sf, dict):
                _cfg["skin_files"] = {k: v for k, v in sf.items() if isinstance(k, str) and isinstance(v, str)}
    except FileNotFoundError:
        pass
    except (OSError, ValueError) as exc:
        log.warning("config/mods.json ilegible (%s): se usan los valores de fabrica", exc)


def save(path=None):
    p = path or CONFIG_PATH
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as f:
            json.dump(_cfg, f, ensure_ascii=False, indent=2)
        return True
    except OSError as exc:
        log.warning("No se pudo guardar %s: %s", p, exc)
        return False


def get(key):
    return _cfg.get(key)


def set_music(path):
    _cfg["music"] = path or None
    save()


def set_skin_dir(path):
    _cfg["skin_dir"] = path or None
    save()


def set_skin_file(name, path):
    if path:
        _cfg["skin_files"][name] = path
    else:
        _cfg["skin_files"].pop(name, None)
    save()


def clear_skins():
    _cfg["skin_dir"], _cfg["skin_files"] = None, {}
    save()


def music_files():
    """Canciones elegidas por el jugador (lista vacia = usar la musica del juego)."""
    p = _cfg.get("music")
    if not p:
        return []
    if os.path.isfile(p) and p.lower().endswith(MUSIC_EXTS):
        return [p]
    if os.path.isdir(p):
        try:
            return [os.path.join(p, n) for n in sorted(os.listdir(p))
                    if n.lower().endswith(MUSIC_EXTS) and os.path.isfile(os.path.join(p, n))]
        except OSError:
            return []
    log.warning("Musica elegida no encontrada: %s", p)
    return []


def skin_png(name):
    """PNG elegido por el jugador para el personaje `name` (archivo propio > carpeta de skins), o None."""
    f = _cfg["skin_files"].get(name)
    if f and os.path.isfile(f):
        return f
    d = _cfg.get("skin_dir")
    if d:
        p = os.path.join(d, slug(name) + ".png")
        if os.path.isfile(p):
            return p
    return None


load()
