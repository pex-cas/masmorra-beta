# -*- coding: utf-8 -*-
"""HUD y pantallas de titulo / game over / victoria."""

import math
from audio.music import MUSIC
from player.player import CLASS_CONFIGS
from world.dungeon import TILE_CHEST, TILE_FLOOR, TILE_PILLAR, TILE_SECRET, TILE_SHRINE, TILE_STAIRS_DOWN, TILE_WALL


class HudMixin:
    # --- HUD
    def _render_hud(self, c):
        p, d = self.player, self.dungeon
        W, H = self.view_w, self.view_h

        def bar(x, y, w, h, val, mx, col, label=""):
            c.create_rectangle(x, y, x + w, y + h, fill="#10121a", outline="#000000")
            if mx > 0:
                c.create_rectangle(x + 1, y + 1, x + 1 + (w - 2) * max(0.0, min(1.0, val / mx)), y + h - 1, fill=col, outline="")
            if label:
                c.create_text(x + w / 2, y + h / 2, text=label, fill="#ffffff", font=self.font_small)
        bar(12, 12, 210, 16, p.hp, p.max_hp, "#d62839", f"{int(p.hp)}/{p.max_hp}")
        bar(12, 32, 210, 12, p.defense, p.max_def, "#6b7a8f" if p.guard_broken else ("#8ecae6" if p.guarding else "#4a90c2"),
            "GUARDIA ROTA" if p.guard_broken else f"DEFENSA [L]  {int(p.defense)}/{p.max_def}")
        bar(12, 48, 210, 10, p.stamina, p.max_stamina, "#8d6e00" if p.exhausted else "#ffbe0b",
            "SIN ALIENTO" if p.exhausted else "")
        bar(0, H - 5, W, 5, p.xp, p.xp_to_next, "#06d6a0")
        c.create_text(W / 2, 14, text=f"PISO {self.floor} · {d.biome['name']}", fill="#adb5bd", font=self.font_small)
        c.create_text(W / 2, H - 32, text=f"AUTOAPUNTADO [P]: {'ON' if self.autoaim else 'OFF'}",
                      fill="#ff6b81" if self.autoaim else "#6c757d", font=self.font_small)
        c.create_text(W / 2, H - 18, text=f"MÚSICA [M]: {'OFF' if MUSIC.muted else 'ON'}   ·   DEFENSA [L]   ·   PAUSA [O]   ·   GUÍA [G]   ·   F11 PANTALLA COMPLETA",
                      fill="#8d99ae", font=self.font_small)

        # habilidades X / C / Z
        cfg = CLASS_CONFIGS[p.char_class]
        for i, key in enumerate("XCZ"):
            bx, by, w, h = 14 + i * 96, H - 74, 90, 60
            ready = p.cd[i] <= 0
            c.create_rectangle(bx, by, bx + w, by + h, fill="#10121a", outline=cfg["color"] if ready else "#3a3d4d", width=2)
            c.create_text(bx + 14, by + 14, text=key, fill="#ffd166" if ready else "#6c757d", font=self.font_big)
            c.create_text(bx + w - 8, by + 12, text=("BASE", "FUERTE", "ULTI")[i], fill="#8d99ae", font=self.font_small, anchor="e")
            c.create_text(bx + w / 2, by + 38, text=cfg["kit"][i][0], fill="#e0e0e0", font=self.font_small, width=w - 6)
            if not ready:
                frac = min(1.0, p.cd[i] / max(0.01, p.cd_max[i]))
                c.create_rectangle(bx, by, bx + w, by + h * frac, fill="#000000", stipple="gray50", outline="")
                c.create_text(bx + w / 2, by + h / 2, text=f"{p.cd[i]:.1f}", fill="#ffffff", font=self.font_bold)

        # pociones y oro (iconos propios)
        ic = self.icons
        c.create_image(14, 64, image=ic.potion_s, anchor="nw")
        c.create_text(34, 72, text=f"x{p.hp_potions} [Q]", fill="#ff8fa3", font=self.font_small, anchor="w")
        c.create_image(88, 64, image=ic.coin_s, anchor="nw")
        c.create_text(108, 72, text=f"{p.gold}", fill="#ffd166", font=self.font_bold, anchor="w")

        # dash y sprint
        dx0, dy0 = W - 210, H - 74
        rd = p.dash_cd <= 0
        c.create_rectangle(dx0, dy0, dx0 + 96, dy0 + 28, fill="#10121a", outline="#3a86ff" if rd else "#3a3d4d", width=2)
        c.create_text(dx0 + 48, dy0 + 14, text="DASH [ESP]" if rd else f"{p.dash_cd:.1f}s", fill="#ffffff", font=self.font_small)
        c.create_rectangle(dx0 + 104, dy0, dx0 + 200, dy0 + 28, fill="#3a2e00" if p.sprinting else "#10121a",
                           outline="#ffbe0b" if p.sprinting else "#3a3d4d", width=2)
        c.create_text(dx0 + 152, dy0 + 14, text="SPRINT [SHIFT]", fill="#ffffff", font=self.font_small)
        c.create_rectangle(dx0, dy0 + 32, dx0 + 200, dy0 + 60, fill="#14202c" if p.guarding else "#10121a",
                           outline="#8ecae6" if p.guarding else ("#6b7a8f" if p.guard_broken else "#4a90c2"), width=2)
        c.create_text(dx0 + 100, dy0 + 46, text="DEFENSA [L] mantener", fill="#ffffff", font=self.font_small)

        # jefe: barra ornamentada con cuernos, marcas de fase (75/50/25 %) y aviso de furia
        for e in self.enemies:
            if e.ai == "boss" and not e.dead and math.hypot(e.x - p.x, e.y - p.y) < 650:
                bw, bx, by = 420, (W - 420) / 2, 44
                enr = e.hp <= e.max_hp * 0.5
                c.create_text(W / 2 + 1, 31, text="SEÑOR DEL ABISMO", fill="#000000", font=self.font_bold)
                c.create_text(W / 2, 30, text="SEÑOR DEL ABISMO", fill="#ff4d6d" if enr else "#e8c2d0", font=self.font_bold)
                c.create_rectangle(bx - 5, by - 5, bx + bw + 5, by + 21, fill="#14060c", outline="#7a1030", width=2)
                frac = max(0.0, min(1.0, e.hp / e.max_hp))
                c.create_rectangle(bx, by, bx + bw, by + 16, fill="#0b0408", outline="")
                c.create_rectangle(bx, by, bx + bw * frac, by + 16, fill="#a3123f" if not enr else "#d90429", outline="")
                c.create_rectangle(bx, by, bx + bw * frac, by + 5, fill="#e5385f", outline="")
                for mk in (0.25, 0.5, 0.75):
                    c.create_line(bx + bw * mk, by - 3, bx + bw * mk, by + 19, fill="#2a0a14", width=2)
                for sg, ex in ((-1, bx - 5), (1, bx + bw + 5)):      # cuernos en los extremos
                    c.create_polygon(ex, by - 6, ex + sg * 20, by - 22, ex + sg * 10, by + 2, fill="#d8c8a8", outline="#3a2a2a")
                if enr:
                    c.create_text(W / 2, by + 34, text="¡ENFURECIDO!", fill="#ff1744" if int(self.now * 4) % 2 else "#7a1030",
                                  font=self.font_small)
                break

        # minimapa
        if self.mini is not None:
            cols = {TILE_WALL: "#4a4f66", TILE_SECRET: "#4a4f66", TILE_PILLAR: "#4a4f66", TILE_FLOOR: "#2c3046", TILE_STAIRS_DOWN: "#4895ef",
                    TILE_CHEST: "#e76f51", TILE_SHRINE: "#06d6a0"}
            for (x, y) in d.new_revealed:
                self.mini.put(cols.get(d.tiles[x][y], "#2c3046"), to=(x * 2, y * 2, x * 2 + 2, y * 2 + 2))
            d.new_revealed.clear()
            mx0, my0 = W - d.width * 2 - 10, 80 if any(e.ai == "boss" for e in self.enemies) else 10
            c.create_rectangle(mx0 - 2, my0 - 2, mx0 + d.width * 2 + 2, my0 + d.height * 2 + 2, fill="#05050a", outline="#2a2c3d")
            c.create_image(mx0, my0, image=self.mini, anchor="nw")
            px, py = int(p.x // d.tile_size) * 2, int(p.y // d.tile_size) * 2
            c.create_rectangle(mx0 + px - 2, my0 + py - 2, mx0 + px + 4, my0 + py + 4, fill="#ffd166", outline="")

        if p.hurt > 0:
            c.create_rectangle(3, 3, W - 3, H - 3, outline="#ff0000", width=8, stipple="gray50")

    # ==========================================================================
    # PANTALLAS: TITULO, GAME OVER, VICTORIA
    # ==========================================================================
    def render_title(self):
        """Portada: el elenco de la Ciudadela Abisal (heroes al frente, enemigos y jefe detras)."""
        c, t = self.canvas, self.now
        W, H = self.view_w, self.view_h
        c.delete("all")
        c.create_rectangle(0, 0, W, H, fill="#06040a", outline="")
        cx = W / 2
        pulse = 0.5 + 0.5 * math.sin(t * 1.4)
        for r, col in ((330, "#0e0509"), (270, "#14060d"), (210, "#1c0813"), (150, "#260a18")):
            r2 = r + pulse * 6
            c.create_oval(cx - r2, H * 0.46 - r2, cx + r2, H * 0.46 + r2, fill=col, outline="")
        for i in range(6):                                    # niebla que deriva
            y = H * (0.34 + 0.11 * i) + math.sin(t * 0.4 + i) * 7
            x = ((t * 12 * (1 + i % 2) + i * 197) % (W + 500)) - 250
            c.create_oval(x - 240, y - 16, x + 240, y + 16, fill="#2d0d19", stipple="gray12", outline="")
        c.create_rectangle(0, H * 0.74, W, H, fill="#0b070b", outline="")           # suelo de piedra
        c.create_rectangle(0, H * 0.74, W, H * 0.74 + 2, fill="#2a0e18", outline="")

        sp = self.sprites.stage
        def stand(name, x, ground, h, bob=0.0, sh=0.5):
            c.create_oval(x - h * sh, ground - 6, x + h * sh, ground + 8, fill="#000000", stipple="gray50", outline="")
            c.create_image(x, ground - h / 2 + 4 + bob, image=sp[name])
        stand("Minotauro Brutal", W * 0.12, H * 0.76, 160, math.sin(t * 1.1) * 2)
        stand("Zombi Pútrido", W * 0.29, H * 0.745, 128, math.sin(t * 1.3 + 1) * 2)
        stand("Mago de Fuego", W * 0.71, H * 0.745, 128, math.sin(t * 1.2 + 2) * 2)
        stand("Esqueleto", W * 0.88, H * 0.76, 128, math.sin(t * 1.0 + 3) * 2)
        stand("Señor del Abismo (JEFE)", cx, H * 0.73, 336, math.sin(t * 1.0) * 6, 0.32)
        ground = H * 0.88
        for i, name in enumerate(CLASS_CONFIGS):
            x = W * (0.2 + 0.3 * i)
            stand(name, x, ground, 192, math.sin(t * 2 + i) * 3, 0.42)
            col = CLASS_CONFIGS[name]["color"]
            c.create_text(x + 1, ground + 23, text=name.upper(), fill="#000000", font=self.font_big)
            c.create_text(x, ground + 22, text=name.upper(), fill=col, font=self.font_big)
        for i in range(44):                                   # brasas que suben
            x = (i * 97 + math.sin(t * 0.7 + i) * 18) % W
            y = H - ((t * (18 + i % 7 * 9) + i * 53) % H)
            s = 1 + i % 3
            c.create_rectangle(x, y, x + s, y + s, fill=("#ff3b3b", "#ff7b3b", "#8a1c2c")[i % 3], outline="")
        c.create_rectangle(0, 0, W, 34, fill="#000000", stipple="gray25", outline="")
        c.create_rectangle(0, H - 34, W, H, fill="#000000", stipple="gray25", outline="")
        for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (2, 2)):                 # titulo con resplandor carmesí
            c.create_text(cx + dx, 112 + dy, text="AETHELGAARD", fill="#4a0a18", font=self.font_huge)
        c.create_text(cx, 70, text="CHRONICLES OF", fill="#9a7a82", font=self.font_big)
        c.create_text(cx, 112, text="AETHELGAARD", fill="#e8c2a0", font=self.font_huge)
        c.create_text(cx, 152, text="THE ABYSSAL CITADEL", fill="#c2184b", font=self.font_big)
        c.create_text(cx, H - 26, text="Elegí tu héroe en el panel de la derecha", fill="#a8989c", font=self.font_norm)
        c.create_text(cx, H - 10, text="X base · C fuerte · Z ulti · L defensa · SHIFT sprint · ESPACIO dash · P autoapuntado · O pausa",
                      fill="#8a7a80", font=self.font_small)

    def render_game_over(self):
        c, W, H = self.canvas, self.view_w, self.view_h
        c.delete("all")
        c.create_rectangle(0, 0, W, H, fill="#0b090a")
        c.create_text(W / 2, H / 2 - 60, text="HAS SUCUMBIDO AL ABISMO", fill="#e63946", font=self.font_title)
        c.create_text(W / 2, H / 2, text=f"Llegaste al Piso {self.floor} con nivel {self.player.level}", fill="#f1faee", font=self.font_big)
        c.create_text(W / 2, H / 2 + 35, text=f"Oro acumulado: {self.player.gold}g", fill="#ffd166", font=self.font_norm)
        c.create_text(W / 2, H / 2 + 80, text="Click para volver a intentarlo", fill="#a8dadc", font=self.font_norm)

    def render_victory(self):
        c, W, H = self.canvas, self.view_w, self.view_h
        c.delete("all")
        c.create_rectangle(0, 0, W, H, fill="#0d1b2a")
        c.create_text(W / 2, H / 2 - 60, text="¡VICTORIA ABSOLUTA!", fill="#ffd166", font=self.font_title)
        c.create_text(W / 2, H / 2, text="Derrotaste al Señor del Abismo y purificaste la Ciudadela", fill="#f1faee", font=self.font_big)
        c.create_text(W / 2, H / 2 + 40, text=f"Oro final: {self.player.gold}g | Nivel final: {self.player.level}", fill="#06d6a0", font=self.font_norm)
        c.create_text(W / 2, H / 2 + 85, text="Click para jugar otra partida con otra clase", fill="#a8dadc", font=self.font_norm)
