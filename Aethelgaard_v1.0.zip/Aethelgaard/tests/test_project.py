# -*- coding: utf-8 -*-
"""Pruebas del proyecto (sin ventana grafica). Ejecutar:  python -m unittest discover -s tests -v"""
import ast
import importlib
import os
import time
import unittest

from tests._helpers import ROOT, have_tk, install_fake_tk

PKGS = ("audio", "graphics", "world", "player", "combat", "inventory", "ui", "game")
ORIGINAL = os.path.join(ROOT, "docs", "juego_v3_original.py")


def py_files():
    for base, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in ("docs", "__pycache__", ".git")]
        for f in files:
            if f.endswith(".py"):
                yield os.path.join(base, f)


def read(*parts):
    with open(os.path.join(ROOT, *parts), encoding="utf-8") as fh:
        return fh.read()


def parse(path):
    with open(path, encoding="utf-8") as fh:
        return ast.parse(fh.read())


def classes(tree):
    return {n.name: n for n in ast.walk(tree) if isinstance(n, ast.ClassDef)}


def methods(cls):
    return {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}


class TestSyntaxAndImports(unittest.TestCase):
    def test_syntax_all_files(self):
        n = 0
        for f in py_files():
            with open(f, encoding="utf-8") as fh:
                compile(fh.read(), f, "exec")
            n += 1
        self.assertGreater(n, 15)

    def test_imports_all_modules(self):
        install_fake_tk()          # si no hay Tkinter se simula SOLO para comprobar las importaciones
        for pkg in PKGS:
            for f in os.listdir(os.path.join(ROOT, pkg)):
                if f.endswith(".py") and f != "__init__.py":
                    importlib.import_module("%s.%s" % (pkg, f[:-3]))
        importlib.import_module("main")

    def test_entry_point_and_requirements(self):
        install_fake_tk()
        main = importlib.import_module("main")
        self.assertTrue(callable(main.main))
        self.assertTrue(os.path.isfile(os.path.join(ROOT, "requirements.txt")))

    def test_no_circular_imports(self):
        graph = {}
        for pkg in PKGS:
            for f in os.listdir(os.path.join(ROOT, pkg)):
                if f.endswith(".py") and f != "__init__.py":
                    t = parse(os.path.join(ROOT, pkg, f))
                    graph["%s.%s" % (pkg, f[:-3])] = {n.module for n in ast.walk(t) if isinstance(n, ast.ImportFrom)
                                                      and n.module and n.module.split(".")[0] in PKGS}
        def visit(n, stack):
            self.assertNotIn(n, stack, "ciclo: %s" % (stack + [n]))
            for d in graph.get(n, ()):
                visit(d, stack + [n])
        for n in graph:
            visit(n, [])


class TestAssets(unittest.TestCase):
    def test_asset_folders_and_fallbacks(self):
        from game import assets
        for sub in ("images", "textures", "music"):
            self.assertTrue(os.path.isdir(os.path.join(assets.ASSETS_DIR, sub)), sub)
        self.assertIsNone(assets.find_asset("textures", ["no_existe"], [".png"]))
        self.assertIsNone(assets.find_music(1))              # sin WAV externo -> musica sintetizada
        self.assertEqual(assets.slug("Señor del Abismo (JEFE)"), "senor_del_abismo_jefe")

    def test_corrupt_music_falls_back_and_is_logged(self):
        from game import assets
        p = os.path.join(assets.ASSETS_DIR, "music", "bioma_3.wav")
        try:
            with open(p, "wb") as fh:
                fh.write(b"esto no es un wav")
            self.assertIsNone(assets.find_music(3))
        finally:
            os.remove(p)

    def test_internal_music_synth_still_available(self):
        from audio.music import MusicEngine
        self.assertEqual(set(MusicEngine.THEMES), {1, 2, 3, 4})


class TestMapGeneration(unittest.TestCase):
    N = 240

    @classmethod
    def setUpClass(cls):
        from world.dungeon import DungeonMap
        cls.maps = [DungeonMap(1 + i % 12) for i in range(cls.N)]

    def test_all_valid_and_secret_rooms_generated_probabilistically(self):
        for d in self.maps:
            self.assertEqual(d.problems, [])
            self.assertEqual(d.validate(), [])
            self.assertGreaterEqual(len(d.secrets), 1)

    def test_borders_closed_and_stairs_reachable(self):
        for d in self.maps:
            for x in range(d.width):
                self.assertFalse(d.is_walkable(x, 0) or d.is_walkable(x, d.height - 1))
            for y in range(d.height):
                self.assertFalse(d.is_walkable(0, y) or d.is_walkable(d.width - 1, y))
            self.assertIn(d.stairs_pos, d._reachable(d.spawn_pos))

    def test_secret_rooms_sealed_then_accessible(self):
        from world.dungeon import TILE_SECRET
        for d in self.maps:
            sealed, opened = d._reachable(d.spawn_pos), d._reachable(d.spawn_pos, through_secrets=True)
            for (sx, sy), info in d.secrets.items():
                self.assertEqual(d.tiles[sx][sy], TILE_SECRET)
                self.assertFalse(set(info["cells"]) & sealed)
                self.assertTrue(set(info["cells"]) <= opened)
                cx, cy = info["center"]
                self.assertIn((cx, cy), info["cells"])
            # las camaras no se superponen entre si
            allc = [c for i in d.secrets.values() for c in i["cells"]]
            self.assertEqual(len(allc), len(set(allc)))

    def test_collisions_match_logical_map(self):
        from world.dungeon import TILE_PILLAR, TILE_SECRET, TILE_WALL
        d = self.maps[0]
        ts = d.tile_size
        for x in range(d.width):
            for y in range(d.height):
                solid = d.tiles[x][y] in (TILE_WALL, TILE_PILLAR, TILE_SECRET)
                self.assertEqual(d.is_walkable(x, y), not solid)
                self.assertEqual(d.can_move(x * ts + ts / 2, y * ts + ts / 2, 4), not solid)

    def test_no_decorative_doors_or_arches(self):
        for d in self.maps:
            self.assertFalse(hasattr(d, "wall_deco"))
        src = read("graphics", "textures.py")
        self.assertNotIn('kind == "door"', src)
        self.assertNotIn('kind == "arch"', src)
        rsrc = read("graphics", "renderer.py")
        self.assertNotIn("wall_deco", rsrc)

    def test_floor_decorations_kept(self):
        kinds = set()
        for d in self.maps[:60]:
            kinds.update(d.deco.values())
        self.assertTrue({"web_l", "web_r", "barrel", "crate", "bones"} <= kinds, kinds)

    def test_wall_shell_has_no_unrevealed_gaps(self):
        """Causa del bug de bloques transparentes: paredes junto a suelo explorado sin revelar."""
        from world.dungeon import DungeonMap, TILE_SECRET, TILE_WALL
        for k in range(12):
            d = DungeonMap(1 + k % 4)
            ts = d.tile_size
            for pos in list(d._reachable(d.spawn_pos))[::13]:
                d._last_ptile = None
                d.compute_fov(pos[0] * ts + 24, pos[1] * ts + 24, 9)
                d.complete_wall_shell()
            gaps = 0
            for x in range(1, d.width - 1):
                for y in range(1, d.height - 1):
                    if d.revealed[x][y] and d.tiles[x][y] not in (TILE_WALL, TILE_SECRET):
                        for xx in range(x - 1, x + 2):
                            for yy in range(y - 1, y + 2):
                                if d.tiles[xx][yy] in (TILE_WALL, TILE_SECRET) and not d.revealed[xx][yy] \
                                        and d.look[xx][yy][0] != "void":
                                    gaps += 1
            self.assertEqual(gaps, 0)

    def test_regeneration_is_bounded(self):
        from world.dungeon import MAX_GEN_ATTEMPTS
        self.assertTrue(all(1 <= d.attempts <= MAX_GEN_ATTEMPTS for d in self.maps))


class TestPalette(unittest.TestCase):
    def test_color_cycle(self):
        from world.dungeon import BIOME_THEMES, DungeonMap
        accents = {"azul": "#3aa8ff", "verde": "#4dff88", "rojo": "#ff6a1f", "violeta": "#c04dff"}
        order = ["azul", "verde", "rojo", "violeta"]
        for floor in range(1, 14):
            d = DungeonMap(floor)
            self.assertEqual(d.biome["accent"], accents[order[(floor - 1) % 4]], floor)
            self.assertIs(d.biome, BIOME_THEMES[d.palette_id])
        self.assertEqual(DungeonMap(5).palette_id, DungeonMap(1).palette_id)

    def test_music_biome_unchanged(self):
        from world.dungeon import DungeonMap
        for f in range(1, 11):
            self.assertEqual(DungeonMap(f).biome_id, min(4, (f - 1) // 3 + 1))


class TestTextures(unittest.TestCase):
    def test_every_texture_builds(self):
        from graphics.textures import TextureAtlas
        counts = {"floor": 4, "floor_sh": 2, "wall_face": 8, "wall_cap": 8, "void": 1}
        for bid in (1, 2, 3, 4):
            a = TextureAtlas(bid)
            for kind, n in counts.items():
                for v in range(n):
                    g = a._make(kind, v)
                    self.assertEqual((len(g), len(g[0])), (24, 24))
                    self.assertTrue(all(c for row in g for c in row))      # terreno 100% opaco
            for kind in ("chest", "shrine", "pillar", "torch", "stairs", "bones", "moss", "crack", "barrel",
                         "crate", "web_l", "web_r", "chains", "crack_ov"):
                self.assertEqual(len(a._make(kind, 0)), 24)


class TestUnchangedSystems(unittest.TestCase):
    """Compara contra docs/juego_v3_original.py: lo que no se pidio cambiar sigue igual."""

    @classmethod
    def setUpClass(cls):
        cls.orig = classes(parse(ORIGINAL))

    def test_classes_unchanged(self):
        for cls_name, path in (("Item", "inventory/items.py"),
                               ("Projectile", "combat/entities.py"), ("Particle", "combat/entities.py"),
                               ("Effect", "combat/entities.py"), ("SpatialHashGrid", "combat/spatial.py")):
            new = classes(parse(os.path.join(ROOT, path)))[cls_name]
            if cls_name != "Item":
                self.assertEqual(ast.dump(self.orig[cls_name]), ast.dump(new), cls_name)

    def test_attacks_and_ai_identical(self):
        om = methods(self.orig["GameEngine"])
        new = {}
        for path in ("combat/skills.py", "game/engine.py"):
            for c in classes(parse(os.path.join(ROOT, path))).values():
                new.update(methods(c))
        for name in ("roll", "cone_targets", "_shoot", "attack_strong", "attack_ult",
                     "explode", "hit_secret_walls", "execute_dash", "aim", "move_vector"):
            self.assertEqual(ast.dump(om[name]), ast.dump(new[name]), name)

    def test_fov_and_light_levels_unchanged(self):
        tex = classes(parse(os.path.join(ROOT, "graphics", "textures.py")))["TextureAtlas"]
        lv = lambda c: ast.dump([n for n in c.body if isinstance(n, ast.Assign) and n.targets[0].id == "LEVELS"][0])
        self.assertEqual(lv(self.orig["TextureAtlas"]), lv(tex))


class TestShopMenusAudioSprites(unittest.TestCase):
    def test_no_equipment_drops(self):
        # La tienda vende solo pergaminos (habilidades/pasivas); ningun codigo genera equipo aleatorio.
        for path in ("combat/skills.py", "game/engine.py"):
            self.assertEqual(read(*path.split("/")).count("Item.generate_random"), 0, path)
        self.assertIn("Item.generate_scroll(i)", read("game", "engine.py"))

    def test_v3_pixel_art_sprites(self):
        """Personajes y enemigos mantienen el diseño original con una rejilla detallada 24x24."""
        from graphics import sprites
        for name, sp in sprites.SPRITE_SPECS.items():
            g = sprites.outline_grid(sprites.build_humanoid(sp, 0))
            self.assertEqual(len(g), sp.get("grid", 16))
            self.assertTrue(any(c for row in g for c in row), name)
            for f in (1, 3):
                self.assertTrue(any(c for row in sprites.build_humanoid(sp, f) for c in row))
        for name in ("Guerrero", "Mago", "Bandido", "Esqueleto", "Zombi Pútrido", "Arquero Espectral",
                     "Mago de Fuego", "Minotauro Brutal"):
            self.assertEqual(sprites.SPRITE_SPECS[name].get("grid"), 24)
        self.assertTrue(sprites.SPRITE_SPECS["Señor del Abismo (JEFE)"]["boss"])

    def test_external_mp3_is_picked_up(self):
        from game import assets
        d = os.path.join(assets.ASSETS_DIR, "music")
        files = [os.path.join(d, "mi_cancion.mp3"), os.path.join(d, "bioma_2.mp3")]
        try:
            self.assertIsNone(assets.find_music(1))
            with open(files[0], "wb") as fh:
                fh.write(b"ID3" + b"\x00" * 600)
            for bid in (1, 2, 3, 4):                       # una sola pista suena en todos los pisos
                self.assertEqual(assets.find_music(bid), files[0])
            with open(files[1], "wb") as fh:
                fh.write(b"ID3" + b"\x00" * 600)
            self.assertEqual(assets.find_music(2), files[1])   # bioma_N tiene prioridad
            self.assertEqual(assets.find_music(1), files[0])
        finally:
            for f in files:
                if os.path.exists(f):
                    os.remove(f)
        self.assertIsNone(assets.find_music(1))

    def test_mci_module_safe_without_windows(self):
        from audio.mci import MciPlayer
        m = MciPlayer()
        self.assertFalse(m.play(os.path.join(ROOT, "no_existe.mp3")))
        m.stop()

    def test_menu_states_pause_the_game(self):
        from ui.help_text import MENU_STATES, PLAY_STATES
        self.assertEqual(set(MENU_STATES), {"INVENTORY", "TALENTS", "GUIDE", "SHOP", "HERO"})
        self.assertTrue(set(MENU_STATES) <= set(PLAY_STATES))
        self.assertIn("PAUSED", PLAY_STATES)
        self.assertNotIn("PAUSED", MENU_STATES)


class TestPerformance(unittest.TestCase):
    def test_map_generation_speed(self):
        from world.dungeon import DungeonMap
        t = time.perf_counter()
        for i in range(40):
            DungeonMap(1 + i % 10)
        self.assertLess((time.perf_counter() - t) / 40, 0.25)

    def test_texture_generation_speed(self):
        from graphics.textures import TextureAtlas
        a = TextureAtlas(1)
        t = time.perf_counter()
        for kind, n in (("floor", 4), ("floor_sh", 2), ("wall_face", 8), ("wall_cap", 8), ("void", 1)):
            for v in range(n):
                a._make(kind, v)
        self.assertLess(time.perf_counter() - t, 1.0)


@unittest.skipUnless(have_tk(), "Requiere Tkinter y pantalla: la prueba grafica real se hace jugando")
class TestGraphicalSmoke(unittest.TestCase):
    def test_engine_boots(self):
        import tkinter as tk
        from game.engine import GameEngine
        root = tk.Tk()
        try:
            eng = GameEngine(root)
            eng.start_game("Guerrero")
            for _ in range(30):
                eng.game_loop()
        finally:
            root.destroy()


if __name__ == "__main__":
    unittest.main()
