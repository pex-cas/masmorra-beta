# -*- coding: utf-8 -*-
"""Motor principal: estado, entrada, simulacion y bucle de juego."""

from tkinter import font as tkfont
import math
import random
import time
import tkinter as tk
from audio.music import MUSIC
from audio.sfx import AUDIO
from combat.enemies import Enemy, HARD_BOSS_FLOOR
from combat.entities import GoldPile, Particle
from combat.skills import CombatMixin
from combat.spatial import SpatialHashGrid
from graphics.icons import IconBank
from graphics.renderer import RenderMixin
from graphics.sprites import SpriteBank
from graphics.textures import TextureAtlas
from inventory.items import Item, RARITY_COLORS
from player.player import GUARD_SPEED, Player
from ui.help_text import MENU_STATES, PLAY_STATES
from ui.hud import HudMixin
from ui.panels import PanelsMixin
from world.dungeon import DungeonMap, TILE_CHEST, TILE_FLOOR, TILE_SHRINE, TILE_STAIRS_DOWN, TILE_WALL


class GameEngine(PanelsMixin, CombatMixin, RenderMixin, HudMixin):
    """Motor del juego. Los sistemas grandes viven en mixins (UI, combate, render, HUD)."""

    def __init__(self, root):
        self.root = root
        root.title("Chronicles of Aethelgaard: The Abyssal Citadel")
        root.geometry("1100x720")
        root.configure(bg="#0a0a0f")
        root.resizable(True, True)          # ventana redimensionable y F11 = pantalla completa
        root.minsize(900, 600)

        self.view_w, self.view_h = 820, 720
        self.canvas = tk.Canvas(root, width=self.view_w, height=self.view_h, bg="#05050a",
                                highlightthickness=0, cursor="crosshair")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self.on_canvas_resize)
        self.side_panel = tk.Frame(root, width=280, bg="#12131a", highlightthickness=1,
                                   highlightbackground="#2a2c3d")
        self.side_panel.pack(side=tk.RIGHT, fill=tk.Y)
        self.side_panel.pack_propagate(False)

        self.font_huge = tkfont.Font(family="Consolas", size=32, weight="bold")
        self.font_title = tkfont.Font(family="Consolas", size=18, weight="bold")
        self.font_big = tkfont.Font(family="Consolas", size=13, weight="bold")
        self.font_bold = tkfont.Font(family="Consolas", size=11, weight="bold")
        self.font_norm = tkfont.Font(family="Consolas", size=10)
        self.font_small = tkfont.Font(family="Consolas", size=8)

        self.sprites = SpriteBank()
        self.icons = IconBank()
        self.atlas = None
        self.atlases = {}
        self.state = "CLASS_SELECT"
        self.floor = 1
        self.player = None
        self.dungeon = None
        self.enemies, self.projectiles, self.particles = [], [], []
        self.floating_texts, self.dropped_items, self.effects = [], [], []
        self.spatial_grid = SpatialHashGrid(80)
        self.keys = {}
        self.mouse_x, self.mouse_y = self.view_w / 2, self.view_h / 2
        self.mouse_down = False
        self.camera_x = self.camera_y = 0.0
        self.cx = self.cy = 0.0
        self.cam_init = True
        self.shake = 0.0
        self.now = time.time()
        self._end_drawn = False
        self._lock_msg = 0.0
        self.mini = None
        self.autoaim, self.auto_target = True, None
        self.scroll, self._view_state, self._stone_img = None, None, None
        self.side_scroll, self.menu, self.menu_scroll, self._menu_state, self._ws = None, None, None, None, 1.0
        self.shop_stock = []
        self.fullscreen = False

        root.bind("<KeyPress>", self.on_key_down)
        root.bind("<KeyRelease>", self.on_key_up)
        root.bind("<FocusOut>", lambda e: self.keys.clear())
        root.bind("<MouseWheel>", self.on_wheel)
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<B1-Motion>", self.on_mouse_move)
        self.canvas.bind("<ButtonPress-1>", self.on_left_down)
        self.canvas.bind("<ButtonRelease-1>", self.on_left_up)
        self.canvas.bind("<ButtonPress-3>", self.on_right_click)

        self.build_class_selection_screen()
        MUSIC.play_theme(1)
        self.last_frame_time = time.time()
        self.game_loop()

    def start_game(self, char_class):
        self.player = Player(char_class)
        self.floor = 1
        self.keys.clear()
        self.mouse_down = False
        self._end_drawn = False
        self.state = "PLAYING"
        self.load_floor(1)
        self.build_ui_panels()

    # ------------------------------------------------------------------ pisos
    def load_floor(self, n):
        self.floor = n
        self.dungeon = d = DungeonMap(n, 60, 60, 48)
        ts = d.tile_size
        atl = self.atlases.get(d.palette_id)       # una sola vez por paleta (se reutiliza al repetir el ciclo)
        if atl is None:
            atl = self.atlases[d.palette_id] = TextureAtlas(d.palette_id)
            atl.prewarm()
        self.atlas = atl
        MUSIC.play_theme(d.biome_id)
        self.mini = tk.PhotoImage(width=d.width * 2, height=d.height * 2)
        self.mini.put("#05050a", to=(0, 0, d.width * 2, d.height * 2))

        p = self.player
        p.x = d.spawn_pos[0] * ts + ts / 2
        p.y = d.spawn_pos[1] * ts + ts / 2
        p.invuln = 1.0
        for _x, _y, obj in self.dropped_items:               # el oro sin recoger no se pierde al cambiar de piso
            if isinstance(obj, GoldPile):
                p.gold += obj.amount
        for lst in (self.enemies, self.projectiles, self.particles, self.floating_texts,
                    self.dropped_items, self.effects):
            lst.clear()

        pool = [("Esqueleto", 5), ("Zombi Pútrido", 3)]
        if n >= 2: pool.append(("Arquero Espectral", 3))
        if n >= 3: pool.append(("Mago de Fuego", 2))
        if n >= 4: pool.append(("Minotauro Brutal", 2))
        names, weights = [a for a, _ in pool], [w for _, w in pool]
        boss_floor = (n % 5 == 0)
        for r in d.rooms[1:]:
            cells = [c for c in r.cells if d.tiles[c[0]][c[1]] == TILE_FLOOR]
            if not cells:
                continue
            if boss_floor and r is d.rooms[-1]:
                # Sala del jefe: arena aparte con las escaleras al piso siguiente. Nadie mas vive aqui
                # (en el piso 5 el jefe dificil invoca esbirros durante la pelea).
                self.enemies.append(Enemy(r.cx * ts + ts / 2, r.cy * ts + ts / 2, "Señor del Abismo (JEFE)", n))
                if n != HARD_BOSS_FLOOR:
                    for _ in range(3):
                        cx, cy = random.choice(cells)
                        self.enemies.append(Enemy(cx * ts + ts / 2, cy * ts + ts / 2, "Esqueleto", n))
                continue
            for _ in range(random.randint(2, 3 + n // 2)):
                cx, cy = random.choice(cells)
                self.enemies.append(Enemy(cx * ts + ts / 2, cy * ts + ts / 2, random.choices(names, weights)[0], n))

        self.shop_stock = [Item.generate_random(n) for _ in range(6)]      # mercancia nueva en cada piso
        self.cam_init = True
        d.compute_fov(p.x, p.y, 9)
        d.complete_wall_shell()
        self.add_floating_text(p.x, p.y - 40, f"PISO {n}: {d.biome['name'].upper()}", "#ffd166")

    def apply_skins(self):
        """Reconstruye los sprites con las skins elegidas (un PNG danado se ignora y queda el original)."""
        self.sprites = SpriteBank()
        self.update_content_view()

    def update_boss_gate(self):
        """Sala del jefe: al entrar se sella la unica entrada; al morir el jefe se vuelve a abrir."""
        d, p = self.dungeon, self.player
        r = d.boss_room
        if r is None or not d.boss_door:
            return
        boss_alive = any(e.ai == "boss" and not e.dead for e in self.enemies)
        if not d.boss_sealed:
            ptx, pty = int(p.x // d.tile_size), int(p.y // d.tile_size)
            inside = r.x + 1 <= ptx < r.x + r.w - 1 and r.y + 1 <= pty < r.y + r.h - 1   # ya bien adentro
            if inside and boss_alive:
                self._set_boss_door(TILE_WALL)
                d.boss_sealed = True
                self.add_floating_text(p.x, p.y - 50, "¡La entrada se selló!", "#ff5400")
                AUDIO.play_sfx("boss_roar")
                self.shake = max(self.shake, 0.4)
        elif not boss_alive:
            self._set_boss_door(TILE_FLOOR)
            d.boss_sealed = False
            self.add_floating_text(p.x, p.y - 50, "La entrada se abrió", "#06d6a0")

    def _set_boss_door(self, tile):
        d = self.dungeon
        for (x, y) in d.boss_door:
            d.tiles[x][y] = tile
            d.revealed[x][y] = True
            d.new_revealed.append((x, y))          # repinta el minimapa
        for (x, y) in d.boss_door:
            d.rebake_around(x, y)
        d._last_ptile = None                       # fuerza recalcular el campo de vision (cierra/abre la vista)

    def summon_minions(self, boss):
        """El jefe dificil invoca esbirros a su alrededor (maximo 6 vivos a la vez)."""
        d = self.dungeon
        ts = d.tile_size
        n, boss.pending_summons = boss.pending_summons, 0
        alive = sum(1 for e in self.enemies if not e.dead and e.name == "Esqueleto"
                    and math.hypot(e.x - boss.x, e.y - boss.y) < 450)
        for _ in range(max(0, min(n, 6 - alive))):
            for _try in range(12):
                a, r = random.uniform(0, 6.283), random.uniform(60, 130)
                x, y = boss.x + math.cos(a) * r, boss.y + math.sin(a) * r
                if d.can_move(x, y, 9):
                    self.enemies.append(Enemy(x, y, "Esqueleto", self.floor))
                    break
        self.add_floating_text(boss.x, boss.y - 60, "¡El jefe invoca esbirros!", "#e0aaff")
        AUDIO.play_sfx("boss_roar")
        self.shake = max(self.shake, 0.2)

    def on_canvas_resize(self, event):
        self.view_w, self.view_h = max(400, event.width), max(300, event.height)

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def toggle_autoaim(self):
        self.autoaim = not self.autoaim
        p = self.player
        self.add_floating_text(p.x, p.y - 44, "Autoapuntado: " + ("ACTIVADO" if self.autoaim else "DESACTIVADO"), "#ffd166")

    # ------------------------------------------------------------------ autoapuntado
    def _find_target(self):
        p, d = self.player, self.dungeon
        ts = d.tile_size
        best, bd = None, 480.0 ** 2
        for e in self.enemies:
            if e.dead:
                continue
            dd = (e.x - p.x) ** 2 + (e.y - p.y) ** 2
            if dd < bd:
                tx, ty = int(e.x // ts), int(e.y // ts)
                if 0 <= tx < d.width and 0 <= ty < d.height and d.visible[tx][ty]:
                    best, bd = e, dd
        return best

    # ------------------------------------------------------------------ entrada
    def on_key_down(self, event):
        key = event.keysym.lower()
        self.keys[key] = True
        if key == 'm':
            MUSIC.toggle()
        elif key == 'f11':
            self.toggle_fullscreen()
        if self.state not in PLAY_STATES or self.player is None:
            return
        if self.state == "PAUSED":                # en pausa solo O / Esc reanudan (M y F11 ya se atendieron arriba)
            if key in ('o', 'escape'):
                self.toggle_pause()
            return
        if key == 'escape':
            if self.state in MENU_STATES:
                self.close_menu()
            elif self.fullscreen:
                self.toggle_fullscreen()
        elif key == 'p': self.toggle_autoaim()
        elif key in ('g', 'h'): self.toggle_guide()
        elif key in ('i', 'tab'): self.toggle_inventory()
        elif key in ('t', 'k'): self.toggle_talents()
        elif key == 'b': self.toggle_shop()
        elif key == 'o': self.toggle_pause()
        elif self.state in MENU_STATES:
            return                                # en pausa: sin pociones ni dash
        elif key == 'q':
            h = self.player.use_hp_potion()
            if h > 0:
                self.add_floating_text(self.player.x, self.player.y - 20, f"+{h} HP", "#06d6a0")
                self.update_content_view()
        elif key == 'space':
            self.execute_dash()

    def on_key_up(self, event):
        self.keys[event.keysym.lower()] = False

    def on_mouse_move(self, event):
        self.mouse_x, self.mouse_y = event.x, event.y

    def on_left_down(self, event):
        if self.state in ("GAMEOVER", "VICTORY"):
            self.restart_game()
        elif self.state in PLAY_STATES and self.state != "PAUSED":
            self.mouse_down = True

    def on_left_up(self, event):
        self.mouse_down = False

    def on_right_click(self, event):
        if self.state == "PLAYING" and self.player.cd[1] <= 0 and self.player.ult_time <= 0 and not self.player.guarding:
            self.attack_strong()

    def move_vector(self):
        k = self.keys
        mx = (1 if (k.get('d') or k.get('right')) else 0) - (1 if (k.get('a') or k.get('left')) else 0)
        my = (1 if (k.get('s') or k.get('down')) else 0) - (1 if (k.get('w') or k.get('up')) else 0)
        return mx, my

    def aim(self):
        p = self.player
        tg = self.auto_target
        if self.autoaim and tg is not None and not tg.dead:
            return math.atan2(tg.y - p.y, tg.x - p.x)
        return math.atan2(self.mouse_y + self.camera_y - p.y, self.mouse_x + self.camera_x - p.x)

    # ------------------------------------------------------------------ dash
    def execute_dash(self):
        p = self.player
        if p.dash_cd > 0 or p.ult_time > 0:
            return
        mx, my = self.move_vector()
        if mx == 0 and my == 0:
            a = self.aim()
            mx, my = math.cos(a), math.sin(a)
        else:
            ln = math.hypot(mx, my)
            mx, my = mx / ln, my / ln
        p.dash_dx, p.dash_dy = mx, my
        p.dash_cd = 1.6 * (1.0 - p.cdr)
        p.dash_time = 0.18
        p.invuln = max(p.invuln, 0.22)
        AUDIO.play_sfx("dash")
        for _ in range(8):
            self.particles.append(Particle(p.x, p.y + 10, random.uniform(-60, 60), random.uniform(-60, 60), 0.25, "#8ecae6"))

    # ==========================================================================
    # PARTE B: bucle, simulacion, render, HUD
    # ==========================================================================
    def game_loop(self):
        now = time.time()
        dt = min(0.05, now - self.last_frame_time)
        self.last_frame_time = now
        self.now = now
        MUSIC.tick(now)
        if self.state == "PLAYING":
            self.update_simulation(dt)
            if self.state == "PLAYING":
                self.render()
        elif self.state in MENU_STATES or self.state == "PAUSED":
            pass                                  # menu abierto o pausa (O): el juego esta congelado
        elif self.state == "CLASS_SELECT":
            self.render_title()
        elif not self._end_drawn:
            self._end_drawn = True
            self.render_game_over() if self.state == "GAMEOVER" else self.render_victory()
        self.root.after(16, self.game_loop)

    def _set(self, lbl, txt):
        if lbl.cget("text") != txt:
            lbl.config(text=txt)

    def update_simulation(self, dt):
        p, d = self.player, self.dungeon
        ts = d.tile_size
        keys = self.keys

        self.spatial_grid.clear()
        for e in self.enemies:
            if not e.dead:
                self.spatial_grid.insert(e)

        self.auto_target = self._find_target() if self.autoaim else None

        # --- timers y regeneracion
        for i in range(3):
            if p.cd[i] > 0: p.cd[i] -= dt
        if p.dash_cd > 0: p.dash_cd -= dt
        if p.invuln > 0: p.invuln -= dt
        if p.hurt > 0: p.hurt -= dt
        p.heal(p.hp_regen * dt)
        p.update_guard(keys.get('l') and p.ult_time <= 0 and p.dash_time <= 0, dt)

        # --- movimiento: caminar / SPRINT / dash
        mx, my = self.move_vector()
        p.moving = bool(mx or my)
        sprint = keys.get('shift_l') or keys.get('shift_r')
        p.sprinting = False
        vx = vy = 0.0
        spd = p.speed * (1.2 if p.ult_time > 0 else (GUARD_SPEED if p.guarding else 1.0))
        if p.dash_time > 0:
            p.dash_time -= dt
            vx, vy = p.dash_dx * p.speed * 3.2 * dt, p.dash_dy * p.speed * 3.2 * dt
        elif p.moving:
            ln = math.hypot(mx, my)
            if sprint and not p.exhausted and p.stamina > 0 and not p.guarding:
                p.sprinting = True
                spd *= 1.55
                p.stamina -= 32 * dt
                p.stam_delay = 0.6
                if p.stamina <= 0:
                    p.stamina, p.exhausted = 0.0, True
            vx, vy = mx / ln * spd * dt, my / ln * spd * dt
        if not p.sprinting:
            if p.stam_delay > 0:
                p.stam_delay -= dt
            else:
                p.stamina = min(p.max_stamina, p.stamina + 24 * dt)
            if p.exhausted and p.stamina >= 25:
                p.exhausted = False
        rp = p.radius * 0.6
        if vx or vy:
            if d.can_move(p.x + vx, p.y, rp): p.x += vx
            if d.can_move(p.x, p.y + vy, rp): p.y += vy
        if p.sprinting and random.random() < 0.5:
            self.particles.append(Particle(p.x, p.y + 20, random.uniform(-20, 20), random.uniform(-25, -5), 0.3, "#8d8d99", 3))
        p.facing = "R" if math.cos(self.aim()) >= 0 else "L"
        p.anim += dt * (1.7 if p.sprinting else 1.0)

        # --- ataques X / C / Z (mantener para repetir)
        if p.guarding:
            pass                                  # cubriendote no atacas
        elif p.ult_time <= 0:
            if (keys.get('x') or self.mouse_down) and p.cd[0] <= 0: self.attack_base()
            if keys.get('c') and p.cd[1] <= 0: self.attack_strong()
            if keys.get('z') and p.cd[2] <= 0: self.attack_ult()
        else:
            p.ult_time -= dt
            p.ult_tick -= dt
            p.invuln = max(p.invuln, 0.1)
            if p.ult_tick <= 0:
                p.ult_tick = 0.11
                AUDIO.play_sfx("slash")
                self.hit_secret_walls(p.x, p.y, 0, 125, 4.0, 1)
                for e in self.spatial_grid.query_radius(p.x, p.y, 150):
                    if not e.dead and math.hypot(e.x - p.x, e.y - p.y) - e.radius <= 120:
                        dmg, cr = self.roll(p.phys_dmg * 0.9)
                        self.damage_enemy(e, dmg, cr, kb=170, src=(p.x, p.y))

        self.update_boss_gate()

        # --- interacciones con el mapa
        ptx, pty = int(p.x // ts), int(p.y // ts)
        t = d.tiles[ptx][pty]
        if t == TILE_STAIRS_DOWN:
            if any(e.ai == "boss" and not e.dead for e in self.enemies):
                if self.now - self._lock_msg > 2:
                    self._lock_msg = self.now
                    self.add_floating_text(p.x, p.y - 40, "¡Derrota al jefe para descender!", "#ff5400")
            elif self.floor >= 10:
                self.state = "VICTORY"
                MUSIC.stop()
                AUDIO.play_sfx("level_up")
                return
            else:
                self.load_floor(self.floor + 1)
                AUDIO.play_sfx("dash")
                return
        elif t == TILE_CHEST:
            d.tiles[ptx][pty] = TILE_FLOOR
            AUDIO.play_sfx("gold")
            g = random.randint(25, 60 + self.floor * 15)
            self.drop_gold(p.x, p.y, g)
            self.add_floating_text(p.x, p.y - 30, "¡Cofre abierto!", "#ffd166")
        elif t == TILE_SHRINE:
            d.tiles[ptx][pty] = TILE_FLOOR
            p.heal(p.max_hp)
            p.defense, p.guard_broken = float(p.max_def), False
            p.hp_potions += 1
            AUDIO.play_sfx("level_up")
            self.add_floating_text(p.x, p.y - 30, "¡SANTUARIO BENDITO!", "#4cc9f0")
            self.update_content_view()

        kept = []
        for ix, iy, obj in self.dropped_items:
            dist = math.hypot(p.x - ix, p.y - iy)
            if isinstance(obj, GoldPile):
                if dist < 150 and dist > 0.1:         # iman: el oro vuela hacia vos
                    k = min(1.0, (240 + (150 - dist) * 4) * dt / dist)
                    ix += (p.x - ix) * k
                    iy += (p.y - iy) * k
                    dist = math.hypot(p.x - ix, p.y - iy)
                if dist < 26:
                    p.gold += obj.amount
                    AUDIO.play_sfx("gold")
                    self.add_floating_text(p.x, p.y - 35, f"+{obj.amount}", "#ffd166")
                    continue
                kept.append((ix, iy, obj))
                continue
            if dist < 32:
                if isinstance(obj, str):
                    p.hp_potions += 1
                    AUDIO.play_sfx("potion")
                    self.add_floating_text(p.x, p.y - 35, "+Poción", "#ff4d6d")
                    self.update_content_view()
                    continue
                if len(p.inventory) < p.max_inv:
                    p.inventory.append(obj)
                    AUDIO.play_sfx("slash")
                    self.add_floating_text(p.x, p.y - 35, f"+{obj.name}", RARITY_COLORS[obj.rarity])
                    self.update_content_view()
                    continue
            kept.append((ix, iy, obj))
        self.dropped_items = kept

        d.compute_fov(p.x, p.y, 9)
        d.complete_wall_shell()

        # --- enemigos
        near = []
        for e in self.enemies:
            if abs(e.x - p.x) < 700 and abs(e.y - p.y) < 700:
                e.update(dt, p, d, self.projectiles)
                near.append(e)
                if e.pending_summons:
                    self.summon_minions(e)
                if e.burn_time > 0 and random.random() < 0.25:
                    self.particles.append(Particle(e.x, e.y - 6, random.uniform(-15, 15), -50, 0.35, "#ff8c1a", 3))
        for e in near:
            if e.dead or e.ai == "boss":
                continue
            for o in self.spatial_grid.query_radius(e.x, e.y, e.radius * 1.5):
                if o is e or o.dead:
                    continue
                dx, dy = e.x - o.x, e.y - o.y
                dd = math.hypot(dx, dy)
                if dd < 0.01:
                    dx, dy, dd = random.uniform(-1, 1), random.uniform(-1, 1), 1.0
                push = (e.radius + o.radius) * 0.8 - dd
                if push > 0:
                    e._move(dx / dd * push * 0.15, dy / dd * push * 0.15, d)
        for e in self.enemies:
            if e.hp <= 0 and not e.dead:
                self.kill_enemy(e)
        self.enemies = [e for e in self.enemies if not e.dead]

        # --- proyectiles
        for pr in self.projectiles:
            pr.update(dt, d)
            if pr.ptype == "fireball" and random.random() < 0.6:
                self.particles.append(Particle(pr.x, pr.y, random.uniform(-30, 30), random.uniform(-30, 30), 0.3,
                                               random.choice(("#ff8c1a", "#ffd23f")), 4))
            if pr.dead:
                if pr.wall_hit and pr.is_player and pr.aoe <= 0:
                    wsx, wsy = int(pr.x // ts), int(pr.y // ts)
                    if (wsx, wsy) in d.secrets:
                        self.hit_secret(wsx, wsy, 1)
                if pr.aoe > 0 and pr.is_player:
                    self.explode(pr.x, pr.y, pr.aoe, pr.dmg, pr.burn)
                continue
            if pr.is_player:
                for e in self.spatial_grid.query_radius(pr.x, pr.y, pr.radius + 40):
                    if e.dead or id(e) in pr.hit:
                        continue
                    if math.hypot(e.x - pr.x, e.y - pr.y) > pr.radius + e.radius:
                        continue
                    if pr.aoe > 0:
                        self.explode(pr.x, pr.y, pr.aoe, pr.dmg, pr.burn)
                        pr.dead = True
                        break
                    self.damage_enemy(e, pr.dmg, pr.crit, kb=90, src=(pr.x - pr.vx * 0.05, pr.y - pr.vy * 0.05))
                    pr.hit.add(id(e))
                    pr.pierce -= 1
                    if pr.pierce <= 0:
                        pr.dead = True
                        break
            elif math.hypot(p.x - pr.x, p.y - pr.y) < p.radius * 0.8 + pr.radius:
                p.take_damage(pr.dmg)
                pr.dead = True
                for _ in range(4):
                    self.particles.append(Particle(pr.x, pr.y, random.uniform(-60, 60), random.uniform(-60, 60), 0.25, pr.color, 3))
        self.projectiles = [pr for pr in self.projectiles if not pr.dead]

        # --- efectos (meteoros, cuchillas)
        for ef in list(self.effects):
            ef.life -= dt
            if ef.kind == "spin":
                ef.x, ef.y = p.x, p.y
            elif ef.kind == "meteor" and ef.life <= 0:
                self.explode(ef.x, ef.y, ef.r, ef.dmg, 2.5)
        self.effects = [ef for ef in self.effects if ef.life > 0]

        for pt in self.particles:
            pt.x += pt.vx * dt
            pt.y += pt.vy * dt
            pt.life -= dt
        self.particles = [pt for pt in self.particles if pt.life > 0]
        for ft in self.floating_texts:
            ft.y -= 28 * dt
            ft.life -= dt
        self.floating_texts = [ft for ft in self.floating_texts if ft.life > 0]
        for txt, col in p.texts:
            self.add_floating_text(p.x + random.randint(-10, 10), p.y - 34, txt, col)
        p.texts.clear()
        self.shake = max(0.0, self.shake - dt)

        if p.hp <= 0:
            self.state = "GAMEOVER"
            MUSIC.stop()
            AUDIO.play_sfx("game_over")

        self._set(self.lbl_hero, f"{p.char_class} Lv.{p.level}")
        self._set(self.hud_hp, f"Salud: {int(p.hp)}/{p.max_hp}")
        self._set(self.hud_mp, f"Defensa: {int(p.defense)}/{p.max_def}")
        self._set(self.hud_xp, f"XP:    {p.xp}/{p.xp_to_next}")
        self._set(self.hud_gold, f"Oro: {p.gold}g | Piso {self.floor}")

        tx, ty = p.x - self.view_w / 2, p.y - self.view_h / 2
        if self.cam_init:
            self.camera_x, self.camera_y, self.cam_init = tx, ty, False
        else:
            k = min(1.0, 10 * dt)
            self.camera_x += (tx - self.camera_x) * k
            self.camera_y += (ty - self.camera_y) * k

    def restart_game(self):
        self.keys.clear()
        self.mouse_down = False
        self._end_drawn = False
        self.state = "CLASS_SELECT"
        self.build_class_selection_screen()
        MUSIC.play_theme(1)
