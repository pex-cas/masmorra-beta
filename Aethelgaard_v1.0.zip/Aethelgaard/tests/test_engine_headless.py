# -*- coding: utf-8 -*-
"""Humo del motor SIN ventana: simula frames con un Canvas falso (solo si no hay Tkinter real).

Comprueba que simulacion, combate, render y HUD se ejecutan sin errores tras la modularizacion.
No valida el aspecto grafico real.
"""
import random
from inventory.items import SCROLLS
import unittest

from tests._helpers import have_tk, install_fake_tk


class FakeCanvas:
    def __getattr__(self, name):
        return lambda *a, **k: 1


class FakeLabel:
    def __init__(self):
        self.t = ""

    def cget(self, k):
        return self.t

    def config(self, text=""):
        self.t = text


@unittest.skipIf(have_tk(), "Con Tkinter real se usa TestGraphicalSmoke")
class TestEngineHeadless(unittest.TestCase):
    def build(self, cls):
        install_fake_tk()
        from combat.spatial import SpatialHashGrid
        from game.engine import GameEngine
        from graphics.textures import TextureAtlas
        TextureAtlas.get = lambda self, kind, var, lvl: None          # sin PhotoImage reales
        e = object.__new__(GameEngine)
        from ui.help_text import PLAY_STATES  # noqa: F401
        e.root = type("R", (), {"after": lambda *a, **k: None})()
        e.view_w, e.view_h = 820, 720
        e.canvas = FakeCanvas()
        e.font_huge = e.font_title = e.font_big = e.font_bold = e.font_norm = e.font_small = "f"
        from player.player import CLASS_CONFIGS
        e.sprites = type("S", (), {"get": lambda *a: None, "big": {n: None for n in CLASS_CONFIGS},
                                                         "stage": type("D", (dict,), {"__missing__": lambda s, k: None})()})()
        e.atlas, e.atlases = None, {}
        e.icons = type("I", (), {"potion": None, "potion_s": None, "coin_s": None,
                                 "coins": [None] * 4, "piles": [None] * 3})()
        e.state, e.floor = "PLAYING", 1
        e.enemies, e.projectiles, e.particles = [], [], []
        e.floating_texts, e.dropped_items, e.effects = [], [], []
        e.spatial_grid = SpatialHashGrid(80)
        e.keys, e.mouse_x, e.mouse_y, e.mouse_down = {}, 400, 300, False
        e.camera_x = e.camera_y = e.cx = e.cy = 0.0
        e.cam_init, e.shake, e.now, e._end_drawn, e._lock_msg = True, 0.0, 1.0, False, 0.0
        e.show_cursor, e.mini, e.autoaim, e.auto_target, e.scroll, e._view_state = False, None, True, None, None, None
        e.lbl_hero, e.hud_hp, e.hud_mp, e.hud_xp, e.hud_gold = (FakeLabel() for _ in range(5))
        e.update_content_view = lambda: None
        from player.player import Player
        e.player = Player(cls)
        e.load_floor(1)
        return e

    def test_facing_keeps_last_side_when_stopped(self):
        e = self.build("Mago")
        e.mouse_x, e.mouse_y = e.view_w, e.view_h / 2          # el mouse queda a la derecha
        e.autoaim = False
        e.keys["a"] = True
        e.update_simulation(0.016)
        self.assertEqual(e.player.facing, "L")
        e.keys.clear()                                         # frena: sigue mirando a la izquierda
        e.update_simulation(0.016)
        self.assertEqual(e.player.facing, "L")
        e.keys["x"] = True                                     # al atacar si apunta hacia el mouse
        e.update_simulation(0.016)
        self.assertEqual(e.player.facing, "R")

    def test_map_image_is_complete(self):
        import re
        from world.mapimage import PX, build_map_image
        import tkinter
        got = {}
        tkinter.PhotoImage = type("PI", (), {"__init__": lambda s, *a, **k: got.update(k),
                                             "put": lambda s, data, **k: got.update(data=data)})
        e = self.build("Mago")
        build_map_image(e.dungeon)
        rows = re.findall(r"\{([^}]*)\}", got["data"])
        self.assertEqual(len(rows), e.dungeon.height * PX)
        self.assertTrue(all(len(r.split()) == e.dungeon.width * PX for r in rows))

    def test_map_pass_gated_by_first_boss(self):
        e = self.build("Mago")
        p = e.player
        self.assertFalse(any(i.stats.get("passive") == "map" for i in e.shop_stock))
        e.open_map()
        self.assertFalse(e.map_open)                         # sin la pasiva no se abre
        e.bosses_defeated = 0
        e._unlock_map_scroll()
        self.assertFalse(any(i.stats.get("passive") == "map" for i in e.shop_stock))
        e.bosses_defeated = 1                                  # tras el primer jefe ya se vende
        e._unlock_map_scroll()
        self.assertTrue(any(i.stats.get("passive") == "map" for i in e.shop_stock))
        p.learned_passives.add("map")
        e._build_map = lambda: None
        e.open_map()
        self.assertTrue(e.map_open)

    def test_vitamins(self):
        e = self.build("Guerrero")
        p = e.player
        e.update_content_view = lambda: None
        base = (p.phys_dmg, p.speed, p.max_hp, p.armor)
        p.gold = 10000
        for k in ("ataque", "velocidad", "vida", "resistencia"):
            g = p.gold
            e._buy_vitamin(k)
            self.assertLess(p.gold, g)
        self.assertEqual((p.phys_dmg, p.speed, p.max_hp, p.armor), (base[0] + 3, base[1] + 8, base[2] + 20, base[3] + 3))
        g = p.gold
        e._buy_vitamin("ataque")
        self.assertGreater(g - p.gold, 260 * 1.5)              # el segundo sale mas caro que el primero

    def test_basic_attack_cooldown(self):
        from player.player import CLASS_CONFIGS
        self.assertTrue(all(c["kit"][0][1] == 0.4 for c in CLASS_CONFIGS.values()))

    def test_frames_all_classes(self):
        random.seed(7)
        for cls in ("Guerrero", "Mago", "Bandido"):
            e = self.build(cls)
            e.keys.update({"d": True, "x": True, "c": True, "z": True, "shift_l": True})
            for i in range(240):
                e.now += 0.016
                e.update_simulation(0.016)
                e.render()
                if i == 100:
                    e.keys["c"] = e.keys["z"] = False
            self.assertEqual(e.dungeon.palette_id, 1)

    def test_floor_changes_and_secret_wall_break(self):
        random.seed(3)
        e = self.build("Guerrero")
        for n in range(1, 6):
            e.load_floor(n)
            e.update_simulation(0.016)
            e.render()
        d = e.dungeon
        for (sx, sy) in list(d.secrets):
            e.hit_secret(sx, sy, 99)
        self.assertEqual(d.secrets, {})
        e.update_simulation(0.016)
        e.render()
        e.render_title(); e.render_game_over(); e.render_victory()

    def test_shop_purchase_and_pause(self):
        random.seed(5)
        e = self.build("Mago")
        self.assertEqual(len(e.shop_stock), len(SCROLLS) - 1)
        p = e.player
        e.update_content_view = lambda: None
        p.gold = 0
        n = len(p.inventory)
        e._buy_item(0)                                   # sin oro: no compra
        self.assertEqual((len(p.inventory), len(e.shop_stock)), (n, len(SCROLLS) - 1))
        itm = e.shop_stock[0]
        p.gold = e.item_price(itm)
        e._buy_item(0)
        self.assertEqual((p.gold, len(p.inventory), len(e.shop_stock)), (0, n + 1, len(SCROLLS) - 2))
        p.gold, hp = 100, p.hp_potions
        e._buy_potion("hp")
        self.assertEqual((p.hp_potions, p.gold), (hp + 1, 60))
        # en pausa (menu abierto) el bucle no simula
        e.state, e.last_frame_time = "SHOP", 0.0
        before = (p.x, p.y, e.enemies[0].x if e.enemies else 0)
        e.keys["d"] = True
        e.game_loop() if False else None
        self.assertEqual(before, (p.x, p.y, e.enemies[0].x if e.enemies else 0))

    def test_no_equipment_drops_when_enemies_die(self):
        random.seed(11)
        e = self.build("Guerrero")
        for _ in range(300):
            from combat.enemies import Enemy
            en = Enemy(e.player.x, e.player.y, "Esqueleto", 1)
            e.enemies.append(en)
            e.kill_enemy(en)
        from inventory.items import Item
        self.assertFalse(any(isinstance(o[2], Item) for o in e.dropped_items))


if __name__ == "__main__":
    unittest.main()
