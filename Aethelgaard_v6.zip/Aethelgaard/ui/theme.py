# -*- coding: utf-8 -*-
"""Paleta de la interfaz, textura de piedra y marco con scroll."""
import math
import random
import tkinter as tk
from graphics.utils import shade


# ==============================================================================
UI = {"bg": "#0c080b", "panel": "#160e12", "card": "#1b1217", "row": "#241820",
      "moss": "#8c1d3a", "moss_d": "#4a1022", "edge": "#43202c",
      "gold": "#d9b45a", "text": "#dcd0c4", "dim": "#9a8a8e",
      "btn": "#2b1820", "btn_a": "#4a2230", "green": "#7fbf6a"}   # carmesi sobre carbon (antes verde musgo)


def make_stone_image(w, h, seed=1):
    """Textura de bloques de piedra oscura con musgo colgando (PhotoImage w x h)."""
    rnd = random.Random(seed)
    base, moss = "#2a2428", "#6a1428"
    rows = []
    for y in range(h):
        off = 11 if (y // 11) % 2 else 0
        row = []
        for x in range(w):
            bx = (x + off) % 22
            f = 1 + (rnd.random() - 0.5) * 0.16
            if y % 11 == 10 or bx == 21:
                col = shade(base, 0.5 * f)
            else:
                col = shade(base, f * (1.18 if (bx == 0 or y % 11 == 0) else 1.0))
            row.append(col)
        rows.append(row)
    for x in range(w):
        top = int(2 + 3 * math.sin(x * 0.21) + 3 * math.sin(x * 0.07 + 1) + rnd.random() * 2.5)
        bot = int(1 + 2 * math.sin(x * 0.33 + 2) + rnd.random() * 2.5)
        for y in range(max(0, min(h, top))):
            rows[y][x] = shade(moss, 0.55 + rnd.random() * 0.6)
        for y in range(h - max(0, bot), h):
            rows[y][x] = shade(moss, 0.4 + rnd.random() * 0.5)
    img = tk.PhotoImage(width=w, height=h)
    img.put(" ".join("{" + " ".join(r) + "}" for r in rows))
    return img


class ScrollFrame(tk.Frame):
    def __init__(self, parent, bg):
        super().__init__(parent, bg=bg)
        self.cv = tk.Canvas(self, bg=bg, highlightthickness=0)
        self.sb = tk.Scrollbar(self, orient="vertical", command=self.cv.yview, width=10)
        self.inner = tk.Frame(self.cv, bg=bg)
        self.win = self.cv.create_window((0, 0), window=self.inner, anchor="nw")
        self.cv.configure(yscrollcommand=self.sb.set)
        self.inner.bind("<Configure>", lambda e: self.cv.configure(scrollregion=self.cv.bbox("all")))
        self.cv.bind("<Configure>", lambda e: self.cv.itemconfigure(self.win, width=e.width))
        self.sb.pack(side=tk.RIGHT, fill=tk.Y)
        self.cv.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
