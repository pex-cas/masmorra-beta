# -*- coding: utf-8 -*-
"""Clases de personaje y jugador."""
import random
from audio.sfx import AUDIO
from inventory.items import ITEM_SLOTS, Item


# ==============================================================================
CLASS_CONFIGS = {
    "Guerrero": {
        "desc": "Maestro del cuerpo a cuerpo: tajos, terremotos y un torbellino de acero.",
        "hp": 150, "df": 130, "speed": 160, "armor": 12, "color": "#e63946",
        "kit": [("Tajo", 0.4), ("Golpe Sísmico", 4.0), ("Torbellino Furia", 22.0)],
    },
    "Mago": {
        "desc": "Canalizador arcano: rayos, bolas de fuego y lluvia de meteoros.",
        "hp": 90, "df": 80, "speed": 150, "armor": 4, "color": "#457b9d",
        "kit": [("Rayo Arcano", 0.4), ("Bola de Fuego", 4.5), ("Lluvia de Meteoros", 24.0)],
    },
    "Bandido": {
        "desc": "Asesino veloz: dagas, abanico de filos y danza mortal de sombras.",
        "hp": 110, "df": 100, "speed": 185, "armor": 7, "color": "#2a9d8f",
        "kit": [("Daga", 0.4), ("Abanico de Dagas", 3.5), ("Danza de Cuchillas", 20.0)],
    },
}


# Vitaminicos de la tienda: mejoras permanentes y caras (el precio sube con cada compra).
VITAMIN_MAX = 8
VITAMINS = {
    "ataque": {"name": "Proteína de Titán", "price": 260, "color": "#ff6b6b",
               "desc": "ATAQUE permanente: +3 de daño físico y mágico por unidad."},
    "velocidad": {"name": "Cafeína de Lince", "price": 220, "color": "#4cc9f0",
                  "desc": "VELOCIDAD permanente: +8 de velocidad de movimiento por unidad."},
    "vida": {"name": "Calcio Vital", "price": 240, "color": "#ff4d6d",
             "desc": "VIDA permanente: +20 de vida máxima por unidad (y te cura esa cantidad)."},
    "resistencia": {"name": "Magnesio de Bastión", "price": 280, "color": "#80ed99",
                    "desc": "RESISTENCIA permanente: +3 de armadura por unidad."},
    "reduccion": {"name": "Zinc Antimpacto", "price": 300, "color": "#c77dff",
                  "desc": "REDUCCIÓN DE DAÑO permanente: reduce un 1.5% el daño recibido por unidad."},
}


def vitamin_price(key, owned):
    return int(VITAMINS[key]["price"] * (1 + 0.6 * owned))


# Defensa (tecla L): la barra se gasta mientras te cubris y se recupera lento al soltar.
GUARD_DRAIN = 22.0        # puntos por segundo mientras mantenes L
GUARD_REDUCTION = 0.80    # parte del dano que absorbe la guardia
GUARD_HIT_COST = 0.55     # puntos de barra que cuesta cada punto de dano absorbido
GUARD_DELAY = 1.5         # segundos sin cubrirte antes de empezar a recuperar
GUARD_RESTORE = 0.30      # tras romperse la guardia, hace falta recuperar este % para volver a usarla
GUARD_SPEED = 0.55        # velocidad de movimiento mientras te cubris


class Player:
    def __init__(self, char_class="Guerrero"):
        cfg = CLASS_CONFIGS[char_class]
        self.char_class = char_class
        self.x = self.y = 0.0
        self.radius = 16
        self.color = cfg["color"]
        self.max_hp = cfg["hp"]; self.hp = self.max_hp
        self.max_def = cfg["df"]; self.defense = float(self.max_def)
        self.guarding = self.guard_broken = False
        self.guard_delay = 0.0
        self.base_speed, self.base_armor = cfg["speed"], cfg["armor"]
        self.level, self.xp, self.xp_to_next = 1, 0, 60
        self.gold, self.skill_points = 50, 0

        # Stamina / sprint
        self.max_stamina = 100.0
        self.stamina = 100.0
        self.stam_delay = 0.0
        self.exhausted = False
        self.sprinting = False

        # Habilidades X / C / Z
        self.cd = [0.0, 0.0, 0.0]
        self.cd_max = [1.0, 1.0, 1.0]
        self.swing_dir = 1
        self.ult_time = 0.0
        self.ult_tick = 0.0

        # Dash / estados
        self.dash_cd = self.dash_time = 0.0
        self.dash_dx = self.dash_dy = 0.0
        self.invuln = 0.0
        self.hurt = 0.0
        self.anim = 0.0
        self.facing = "R"
        self.moving = False
        self.texts = []

        self.hp_potions = 3
        self.equipment = {slot: None for slot in ITEM_SLOTS}
        self.inventory, self.max_inv = [], 16
        self.talents = {"vitalidad": 0, "ferocidad": 0, "celeridad": 0, "resistencia": 0, "precision": 0}
        self.equipment["Báculo"] = Item("Báculo de Iniciado", "Báculo", "Común", {"phys_dmg": 5, "mag_dmg": 4})
        self.equipment["Chaleco"] = Item("Chaleco Básico", "Chaleco", "Común", {"armor": 3, "max_hp": 15})
        self.vitamins = {k: 0 for k in VITAMINS}
        self.learned_passives = set()
        self.retaliation_damage = 0
        self.second_chance_cd = 0.0
        self.recalculate_stats()

    def recalculate_stats(self):
        cfg, t = CLASS_CONFIGS[self.char_class], self.talents
        self.max_hp = cfg["hp"] + t["vitalidad"] * 25
        self.max_def = cfg["df"]
        self.armor = cfg["armor"] + t["resistencia"] * 2
        self.phys_dmg = 10 + t["ferocidad"] * 4
        self.mag_dmg = 10 + t["ferocidad"] * 4
        self.crit_chance = 0.08 + t["ferocidad"] * 0.02
        self.crit_mult = 1.5 + t["ferocidad"] * 0.1
        self.crit_chance += t["precision"] * 0.015
        self.speed = (self.base_speed + t["celeridad"] * 10) * 1.32
        self.cdr = min(0.40, t["celeridad"] * 0.05)
        self.hp_regen = 0.0  # V9: sin curacion pasiva
        self.def_regen = 6.0
        self.dodge = 0.05
        self.max_stamina = 100.0 + t["celeridad"] * 10
        self.burn_dmg, self.freeze_chance, self.gold_bonus = 0, 0.0, 0.0
        if "damage_boost" in self.learned_passives:
            self.phys_dmg *= 1.15
            self.mag_dmg *= 1.15
        if "quick_cooldowns" in self.learned_passives:
            self.cdr = min(0.60, self.cdr + 0.12)
        if "gold_bonus_passive" in self.learned_passives:
            self.gold_bonus += 0.20
        v = self.vitamins
        self.phys_dmg += 3 * v["ataque"]
        self.mag_dmg += 3 * v["ataque"]
        self.speed += 8 * v["velocidad"]
        self.max_hp += 20 * v["vida"]
        self.armor += 3 * v["resistencia"]
        self.damage_reduction_bonus = min(0.15, 0.015 * v.get("reduccion", 0))
        for itm in self.equipment.values():
            if itm:
                st = itm.stats
                self.max_hp += st.get("max_hp", 0)
                self.max_def += st.get("max_def", 0)
                self.armor += st.get("armor", 0)
                self.phys_dmg += st.get("phys_dmg", 0)
                self.mag_dmg += st.get("mag_dmg", 0)
                self.crit_chance += st.get("crit_chance", 0.0)
                self.crit_mult += st.get("crit_mult", 0.0)
                self.speed += st.get("move_speed", 0)
                self.hp_regen += 0.0  # V9: la curacion pasiva esta desactivada
                self.def_regen += st.get("def_regen", 0.0)
                self.dodge += st.get("dodge", 0.0)
                self.burn_dmg += st.get("burn_dmg", 0)
                self.freeze_chance += st.get("freeze_chance", 0.0)
                self.gold_bonus += st.get("gold_bonus", 0.0)
                self.cdr = min(0.50, self.cdr + st.get("cdr", 0.0))
        self.hp = min(self.hp, self.max_hp)
        self.defense = min(self.defense, self.max_def)

    def gain_xp(self, amount):
        self.xp += amount
        leveled = False
        while self.xp >= self.xp_to_next:
            self.xp -= self.xp_to_next
            self.level += 1
            self.skill_points += 1
            self.xp_to_next = int(self.xp_to_next * 1.45)
            leveled = True
            AUDIO.play_sfx("level_up")
        if leveled:
            self.recalculate_stats()
            self.defense, self.guard_broken = float(self.max_def), False
        return leveled

    def take_damage(self, raw_dmg):
        if self.invuln > 0:
            return 0, True
        if random.random() < self.dodge:
            self.texts.append(("Esquivado", "#a8dadc"))
            return 0, True
        reduction = self.armor / (self.armor + 50)
        raw_dmg = raw_dmg * (1.0 - getattr(self, "damage_reduction_bonus", 0.0)) * (0.88 if "damage_reduction" in self.learned_passives else 1.0)
        if "second_chance" in self.learned_passives and self.second_chance_cd <= 0:
            raw_dmg *= 0.5
            self.second_chance_cd = 8.0
            self.texts.append(("Segunda oportunidad", "#8ecae6"))
        dmg = max(1, int(raw_dmg * (1.0 - reduction)))
        if self.guarding:                                   # defensa [L]: absorbe casi todo y gasta la barra
            self.defense = max(0.0, self.defense - dmg * GUARD_HIT_COST)
            self.guard_delay = GUARD_DELAY
            dmg = int(dmg * (1.0 - GUARD_REDUCTION))
            self.texts.append((f"Bloqueo -{dmg}" if dmg else "Bloqueo", "#8ecae6"))
            if self.defense <= 0:
                self.guard_broken, self.guarding = True, False
                self.texts.append(("¡Guardia rota!", "#ff9f1c"))
            self.hp -= dmg
            self._trigger_passives(dmg)
            AUDIO.play_sfx("hit")
            return dmg, False
        self.hp -= dmg
        self._trigger_passives(dmg)
        self.hurt = 0.25
        self.texts.append((f"-{dmg}", "#ff4d6d"))
        AUDIO.play_sfx("hit")
        return dmg, False

    def _trigger_passives(self, damage):
        if "retaliation" in self.learned_passives:
            self.retaliation_damage += max(4, int(damage * 0.8))
        if "lifesteal_taken" in self.learned_passives:
            self.heal(max(1, int(damage * 0.08)))

    def heal(self, amount):
        self.hp = min(self.max_hp, self.hp + amount)

    def use_hp_potion(self):
        if self.hp_potions > 0 and self.hp < self.max_hp:
            self.hp_potions -= 1
            v = int(self.max_hp * 0.45)
            self.heal(v)
            AUDIO.play_sfx("potion")
            return v
        return 0

    def update_guard(self, want, dt):
        self.second_chance_cd = max(0.0, self.second_chance_cd - dt)
        """Defensa: `want` = L apretada. Gasta la barra al cubrirte y la recupera lento al soltar."""
        if self.guard_broken and self.defense >= self.max_def * GUARD_RESTORE:
            self.guard_broken = False
        self.guarding = bool(want) and not self.guard_broken and self.defense > 0
        if self.guarding:
            self.defense = max(0.0, self.defense - GUARD_DRAIN * dt)
            self.guard_delay = GUARD_DELAY
            if self.defense <= 0:
                self.guarding, self.guard_broken = False, True
                self.texts.append(("¡Guardia rota!", "#ff9f1c"))
        elif self.guard_delay > 0:
            self.guard_delay -= dt
        else:
            self.defense = min(self.max_def, self.defense + self.def_regen * dt)

    def equip_item(self, idx):
        if 0 <= idx < len(self.inventory):
            item = self.inventory[idx]
            if item.slot == "Pergamino":
                effect = item.stats.get("passive")
                if effect:
                    self.inventory.pop(idx)
                    if effect not in self.learned_passives:
                        self.learned_passives.add(effect)
                        self.recalculate_stats()
                        self.texts.append(("Pasiva aprendida", "#ffd166"))
                        AUDIO.play_sfx("level_up")
                    else:
                        self.texts.append(("Ese pergamino ya fue aprendido", "#9aa0aa"))
                return
            item = self.inventory.pop(idx)
            old = self.equipment.get(item.slot)
            self.equipment[item.slot] = item
            if old:
                self.inventory.append(old)
            self.recalculate_stats()
            AUDIO.play_sfx("slash")

    def unequip_item(self, slot):
        item = self.equipment.get(slot)
        if item and len(self.inventory) < self.max_inv:
            self.equipment[slot] = None
            self.inventory.append(item)
            self.recalculate_stats()
