# V16 — minimapa lateral y selector de héroe

- Se reemplazó el bloque de texto de habilidades/estadísticas que ocupaba el panel lateral durante la partida por un minimapa interactivo. Al hacer clic en el mapa lateral se abre el mapa ampliado.
- El minimapa dibuja los tiles descubiertos una sola vez y actualiza únicamente las celdas nuevas y la posición del jugador para reducir el coste de renderizado.
- Se conserva la imagen interna del mapa para que el mapa ampliado siga mostrando las zonas exploradas.
- Se rediseñaron las tarjetas de selección de héroe: encabezado dedicado, retrato enmarcado, estadísticas compactas, habilidades destacadas y botón de selección con color de clase.

## Validación

- `compileall` completado correctamente.
- Suite: 59 pruebas; 47 aprobadas, 10 omitidas, 2 fallidas y 2 errores. Los errores necesitan una pantalla/Tk real. Las dos fallas corresponden a expectativas de pruebas antiguas sobre `Item.generate_random` y el método `attack_base`; requieren revisión aparte. La interfaz gráfica no pudo probarse visualmente en este entorno.

---

# V16.2 — corrección de congelamientos y errores

- **Congelamiento (rendimiento):** el minimapa lateral llamaba a `update_idletasks()` y consultaba tamaños a Tk 40 veces por segundo. Ahora la escala se calcula una vez y solo se recalcula cuando el panel cambia de tamaño (evento `<Configure>`).
- **Tirones al recoger ítems / subir de nivel:** `update_content_view()` destruía y reconstruía el minimapa entero (hasta 3600 rectángulos) en cada recogida. Ahora solo se reconstruye si no existe.
- **Minimapa en pisos de jefe:** la arena repite el número de piso y el minimapa conservaba el dibujo del piso anterior. Ahora se identifica por el mapa, no por el número de piso.
- **Bucle del juego a prueba de errores:** una excepción en un fotograma detenía el juego para siempre (pantalla "congelada"). Ahora se registra en `logs/game.log` y el juego sigue.
- **Jefes:** `boss_armor_claimed` podía no existir al derrotar a un jefe (AttributeError). Corregido.
- **Tienda:** `_buy_potion` usaba `POTION_SHOP`, que no existía (AttributeError). Definida.
- **Selector de héroe:** `_stone_btn` recibía `bg` duplicado (TypeError al iniciar). Corregido.
- **Pruebas:** actualizadas las expectativas obsoletas (tienda de pergaminos, ataque básico con pasivas). 59 pruebas: todas aprobadas (3 omitidas por no haber pantalla Tk).

---

# V16.3 — rendimiento y orientación del héroe (limitado a 30 fps)

- **Render a 60 fps:** los tiles del mapa ya no se borran y recrean en cada fotograma. Existen como items persistentes del canvas: al moverse la cámara se desplazan todos con un único `move()`, y solo se recrea un tile cuando cambia su imagen (iluminación, antorcha). Solo lo dinámico (entidades, proyectiles, HUD) se borra y redibuja (etiqueta `dyn`). Se eliminó el límite de 40 fps.
- **Bucle de tiempo:** el siguiente fotograma se programa descontando lo que tardó el actual (objetivo 16,7 ms) y en Windows se pide temporizador de 1 ms (`timeBeginPeriod`), que de lo contrario limita Tk a ~64 Hz con saltos.
- **Orientación:** al caminar a un lado y frenar, el héroe conserva ese lado. Solo gira hacia el objetivo/mouse mientras atacás.
- **Límite a 30 fps (V16.3b):** el juego corre a 30 fps fijos (`FPS` en `game/engine.py`), dejando tiempo libre al bucle de Tk para atender teclado y mouse.
- **Portada superpuesta:** al empezar la partida seguían dibujados los personajes de la portada detrás del mapa. Ahora se limpia el canvas al cargar cada piso.
- **Minimapa lateral:** el tamaño del panel se vuelve a comprobar solo cada 10 fotogramas, sin depender del evento de redimensión.

---

# V16.4

- **Minimapa lateral eliminado:** redibujaba el mapa mientras caminabas. El panel muestra ahora una guía de controles estática y hay un botón **Mapa [N]** (el mapa ampliado sigue igual).
- **Tiles sin cargar/descargar en el borde:** se crean 2 tiles de margen fuera de pantalla y solo se liberan los que quedan a más de 5.
- **Portada estática:** sin animaciones; se dibuja una sola vez (y al redimensionar la ventana). Solo el juego se anima.
- **Selector de héroe rediseñado:** tarjetas compactas (retrato, descripción, estadísticas, X · C · Z y botón) que entran completas en el panel.

---

# V16.5

- **Menús sobre el juego:** al abrir un menú se ocultaba mal el canvas y se veía el juego (o el mapa) encima durante unos segundos. Ahora el canvas se oculta mientras hay un menú abierto y el mapa se cierra.
- **Mapa completo y detallado:** `world/mapimage.py` genera al cargar el piso una imagen de TODO el nivel (muros con borde, suelo, escaleras, cofres, pilares, antorchas). Las cámaras secretas sin descubrir siguen ocultas. Ya no se pinta nada por fotograma.
- **Mapa bloqueado por pasiva:** el *Pergamino del Mapa Abisal* aparece en la Tienda (90 g) al derrotar al segundo jefe. Al aprenderlo aparece el botón **Mapa [N]** y la tecla N abre el mapa; antes avisa que hace falta el pergamino.
- **Ataque básico en 0,8 s** para las tres clases (`kit[0]` en `player/player.py`).

# V16.5.1
- Daño de todos los jefes −20 % (`BOSS_DMG_NERF` en `combat/enemies.py`).
- Ataque básico cada 0,4 s en las tres clases.

# V16.6
- **Panel lateral:** muestra tus estadísticas (daño, armadura, defensa, vida, velocidad, crítico, evasión, CD, oro extra, pociones, vitamínicos) en lugar de los controles; se actualiza solo cuando cambian.
- **Tienda:** ahora vende pociones, vitamínicos y pergaminos, y cada objeto explica para qué sirve.
  - Vitamínicos (permanentes, máx. 8 de cada uno, el precio sube 60 % por compra): Fuerza (+3 daño físico y mágico, 260 g), Celeridad (+8 velocidad, 220 g), Vitalidad (+20 vida máx., 240 g), Resistencia (+3 armadura y +10 defensa máx., 280 g).
- **Mapa:** el Pergamino del Mapa Abisal aparece en la tienda tras derrotar al **primer** jefe.
- **Selector de héroe:** el retrato usa el arte nuevo de la portada (antes mostraba el sprite procedural viejo).
