# -*- coding: utf-8 -*-
"""Objetos, rarezas y afijos."""
import random


# ==============================================================================
RARITY_COLORS = {"Común": "#d0d0d0", "Mágico": "#3a86ff", "Raro": "#ffd166",
                 "Épico": "#8338ec", "Legendario": "#ff5400"}

PREFIXES = [
    ("Feroz", {"phys_dmg": 4}), ("Arcano", {"mag_dmg": 5}), ("Bastión", {"max_def": 20}),
    ("Titánico", {"max_hp": 35}), ("Glacial", {"freeze_chance": 0.15}), ("Ígneo", {"burn_dmg": 6}),
    ("Ágil", {"move_speed": 18}), ("Letal", {"crit_chance": 0.08}), ("Impenetrable", {"armor": 8}),
]
SUFFIXES = [
    ("de la Muerte", {"crit_mult": 0.35}), ("del Fénix", {"hp_regen": 3.0}),
    ("de la Tormenta", {"cdr": 0.12}), ("del Berserker", {"phys_dmg": 6, "armor": -2}),
    ("de las Sombras", {"dodge": 0.08}), ("del Escudo Eterno", {"max_def": 30, "def_regen": 2.0}),
    ("de Voracidad", {"gold_bonus": 0.25}),
]
ITEM_SLOTS = ["Pantalones", "Botas", "Chaleco", "Casco", "Báculo"]
SCROLLS = [
    ("Pergamino de Energía Reactiva", "Al recibir daño, libera una onda que hiere a los enemigos cercanos.", "retaliation"),
    ("Pergamino de Sangre Vital", "Recuperás un 8% del daño recibido como vida.", "lifesteal_taken"),
    ("Pergamino de Piel de Piedra", "Reduce un 12% adicional el daño recibido.", "damage_reduction"),
    ("Pergamino de Segunda Oportunidad", "Cada 8 segundos, el siguiente golpe recibido se reduce a la mitad.", "second_chance"),
    ("Pergamino de Doble Disparo", "Cada ataque básico dispara un segundo proyectil o golpe adicional.", "double_basic"),
    ("Pergamino de Filos Perforantes", "Tus proyectiles básicos atraviesan un enemigo adicional.", "piercing_shots"),
    ("Pergamino de Sobrecarga", "Tus ataques infligen un 15% más de daño.", "damage_boost"),
    ("Pergamino de Enfoque", "Las habilidades fuertes recargan un 12% más rápido.", "quick_cooldowns"),
    ("Pergamino de Cosecha", "Obtenés un 20% más de experiencia al derrotar enemigos.", "xp_bonus"),
    ("Pergamino del Mapa Abisal", "Revela el mapa completo y detallado de cada piso. Se abre con [N] o el botón Mapa.", "map"),
]
STAT_NAMES = {"phys_dmg": "Daño físico", "mag_dmg": "Poder mágico", "armor": "Armadura", "max_hp": "Vida máx",
              "max_def": "Defensa máx", "crit_chance": "Prob. crítico", "crit_mult": "Mult. crítico",
              "move_speed": "Velocidad", "hp_regen": "Regen. vida",
              "def_regen": "Regen. defensa", "dodge": "Esquiva", "cdr": "Reduc. cooldown",
              "burn_dmg": "Fuego", "freeze_chance": "Hielo", "gold_bonus": "Oro extra"}


class Item:
    def __init__(self, name, slot, rarity, stats, desc=""):
        self.name, self.slot, self.rarity, self.stats, self.desc = name, slot, rarity, stats, desc
        self.value = 10

    def stat_text(self):
        parts = []
        for k, v in self.stats.items():
            parts.append(f"{STAT_NAMES.get(k, k)} {int(round(v * 100))}%" if isinstance(v, float) and abs(v) < 1.5
                         else f"{STAT_NAMES.get(k, k)} {round(v, 1) if isinstance(v, float) else v}")
        return ", ".join(parts)

    @classmethod
    def generate_scroll(cls, index=None):
        name, desc, effect = random.choice(SCROLLS) if index is None else SCROLLS[index % len(SCROLLS)]
        item = cls(name, "Pergamino", "Épico", {"passive": effect}, desc)
        item.value = 90 if effect == "map" else 55 if effect in ("double_basic", "damage_boost", "piercing_shots") else (48 if effect in ("retaliation", "second_chance") else 42)
        return item

    @classmethod
    def generate_random(cls, floor=1):
        slot = random.choice(ITEM_SLOTS)
        r = random.random()
        if r < 0.40: rarity, n_aff = "Común", 0
        elif r < 0.72: rarity, n_aff = "Mágico", 1
        elif r < 0.90: rarity, n_aff = "Raro", 2
        elif r < 0.98: rarity, n_aff = "Épico", 3
        else: rarity, n_aff = "Legendario", 4

        stats, prefix_str, suffix_str = {}, "", ""
        mult = 1.0 + floor * 0.18
        base_name = slot
        if slot == "Báculo":
            v = round(random.randint(6, 12) * mult)
            stats["phys_dmg"], stats["mag_dmg"] = v, round(v * 0.8)
            base_name = random.choice(["Báculo", "Bastón Rúnico", "Vara Umbría"])
        elif slot in ("Pantalones", "Botas", "Chaleco", "Casco"):
            stats["armor"] = round(random.randint(3, 8) * mult)
            stats["max_hp"] = round(random.randint(15, 30) * mult)
        else:
            stats["max_def"] = round(random.randint(10, 25) * mult)
            stats["crit_chance"] = round(0.03 + floor * 0.005, 3)

        chosen = random.sample(PREFIXES, min(n_aff, len(PREFIXES)))
        if chosen:
            p_name, p_stat = chosen[0]
            prefix_str = p_name + " "
            for k, v in p_stat.items():
                stats[k] = stats.get(k, 0) + (round(v * mult) if isinstance(v, int) else v)
        if n_aff >= 2:
            s_name, s_stat = random.choice(SUFFIXES)
            suffix_str = " " + s_name
            for k, v in s_stat.items():
                stats[k] = stats.get(k, 0) + (round(v * mult) if isinstance(v, int) else v)

        item = cls(f"{prefix_str}{base_name}{suffix_str}".strip(), slot, rarity, stats)
        item.value = int((len(stats) * 15 + floor * 10) * (1.5 if rarity != "Común" else 1.0))
        return item
