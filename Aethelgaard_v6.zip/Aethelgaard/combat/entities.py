# -*- coding: utf-8 -*-
"""Entidades basicas: particulas, proyectiles, textos flotantes y efectos."""


# ==============================================================================
class Particle:
    __slots__ = ('x', 'y', 'vx', 'vy', 'life', 'max_life', 'color', 'size')
    def __init__(self, x, y, vx, vy, life, color, size=3):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.life = self.max_life = life
        self.color, self.size = color, size


class Projectile:
    def __init__(self, x, y, vx, vy, dmg, is_player=True, color="#ffff00", ptype="bolt",
                 radius=5, pierce=1, duration=2.2, crit=False, aoe=0, burn=0.0):
        self.x, self.y, self.vx, self.vy = x, y, vx, vy
        self.dmg, self.is_player, self.color, self.ptype = dmg, is_player, color, ptype
        self.radius, self.pierce, self.life = radius, pierce, duration
        self.crit, self.aoe, self.burn = crit, aoe, burn
        self.dead = False
        self.wall_hit = False
        self.hit = set()

    def update(self, dt, dungeon):
        self.x += self.vx * dt
        self.y += self.vy * dt
        self.life -= dt
        if self.life <= 0:
            self.dead = True
        if not dungeon.is_walkable(int(self.x // dungeon.tile_size), int(self.y // dungeon.tile_size)):
            self.dead = True
            self.wall_hit = True


class GoldPile:
    """Oro en el suelo: se junta caminando cerca (el iman lo atrae)."""
    __slots__ = ('amount',)
    def __init__(self, amount):
        self.amount = int(amount)


class FloatingText:
    __slots__ = ('x', 'y', 'text', 'color', 'life', 'max_life')
    def __init__(self, x, y, text, color="#ffffff", life=0.9):
        self.x, self.y, self.text, self.color = x, y, text, color
        self.life = self.max_life = life


class Effect:
    """Efectos visuales (tajos, anillos, meteoros, cuchillas giratorias, lineas)."""
    def __init__(self, kind, x, y, life, **kw):
        self.kind, self.x, self.y = kind, x, y
        self.life = self.max = life
        self.__dict__.update(kw)
