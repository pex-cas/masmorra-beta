# -*- coding: utf-8 -*-
"""Musica de fondo sintetizada por codigo (loop WAV por bioma)."""
import array
import math
import os
import random
import tempfile
import threading
import wave

from audio import HAS_WINSOUND, winsound
from audio.mci import MciPlayer
from game.assets import find_music, mark_bad


# ------------------------------------------------------------------------------
# MUSICA DE FONDO: ambiente oscuro generado por codigo (sin archivos externos).
# Se sintetiza un WAV en loop (drone + acordes que respiran + campanitas +
# latido grave) y se reproduce con winsound.PlaySound en segundo plano.
# Cada bioma tiene su propia tonalidad y progresion de acordes.
# ------------------------------------------------------------------------------
class MusicEngine:
    SR, LOOP = 11025, 16.0
    # bioma: (raiz en Hz, progresion [(semitonos, 'm' menor | 'M' mayor | 'd' disminuido)]).
    # Raices muy graves y progresiones frigias/locrias (segunda menor y tritono): tension permanente.
    THEMES = {
        1: (41.20, [(0, "m"), (1, "M"), (0, "d"), (6, "m")]),
        2: (36.71, [(0, "m"), (6, "d"), (1, "M"), (0, "m")]),
        3: (38.89, [(0, "d"), (1, "m"), (5, "m"), (6, "M")]),
        4: (32.70, [(0, "m"), (1, "M"), (6, "d"), (11, "m")]),
    }

    def __init__(self):
        self.enabled = HAS_WINSOUND
        self.muted = False
        self.current = None
        self.want = None
        self.building = set()
        self.lock = threading.Lock()
        self.mci = MciPlayer()              # MP3/WMA externos (assets/music)
        self.cur_path = None
        self._last_tick = 0.0

    @staticmethod
    def _stop_winsound():
        """Frena el loop WAV de winsound. SND_PURGE NO funciona en Windows moderno (por eso la musica
        original seguia sonando debajo de la elegida); PlaySound(None, ...) si corta el sonido actual."""
        if not HAS_WINSOUND:
            return
        for flags in (winsound.SND_ASYNC, winsound.SND_PURGE):
            try:
                winsound.PlaySound(None, flags)
            except Exception:
                pass

    def _path(self, bid):
        return os.path.join(tempfile.gettempdir(), "aethelgaard_bgm_v2_%d.wav" % bid)

    def synth(self, bid):
        """Devuelve la lista de muestras (int16) de un loop perfecto de LOOP segundos.

        Version tenebrosa: drone sub-grave desafinado con segunda menor y tritono, acordes menores/disminuidos
        con cluster disonante, viento susurrante, coro fantasmal, campanas inarmonicas lejanas, latido
        irregular y gemidos graves descendentes."""
        SR, L = self.SR, self.LOOP
        N = int(SR * L)
        root, prog = self.THEMES[bid]
        rnd = random.Random(bid * 101 + 7)
        tau, sin, exp = 2 * math.pi, math.sin, math.exp
        buf = [0.0] * N
        third_of = {"m": 3, "M": 4, "d": 3}
        fifth_of = {"m": 7, "M": 7, "d": 6}

        def fr(f):          # frecuencia con ciclos enteros -> el loop no hace "click"
            return max(1, round(f * L)) / L

        # drone sub-grave: raiz + raiz desafinada (batido lento) + segunda menor + tritono, con respiracion
        f0, f0b, f1, f2 = fr(root), fr(root * 1.007), fr(root * 16 / 15 * 2), fr(root * 1.4142 * 2)
        for i in range(N):
            t = i / SR
            lfo = 0.72 + 0.28 * sin(tau * 2 * t / L + 1.0)
            buf[i] = (0.17 * sin(tau * f0 * t) + 0.12 * sin(tau * f0b * t)
                      + 0.035 * lfo * sin(tau * f1 * t) + 0.02 * sin(tau * f2 * t + 0.5 * sin(tau * 0.25 * t))) * lfo

        # acordes oscuros (pad) con cluster disonante (+1 semitono) y temblor lento
        seg = N // 4
        for k, (off, kind) in enumerate(prog):
            semis = (0, third_of[kind], fifth_of[kind], 1)
            freqs = [root * 2 ** ((off + s_) / 12.0) * 2 for s_ in semis]
            amps = (1.0, 0.8, 0.7, 0.45)
            a = k * seg
            for j in range(seg):
                t = (a + j) / SR
                w = sin(math.pi * j / seg) ** 2
                trem = 0.85 + 0.15 * sin(tau * 3.1 * t)
                v = 0.0
                for f, am in zip(freqs, amps):
                    v += am * (sin(tau * f * t) + 0.6 * sin(tau * f * 1.006 * t + 1.3))
                buf[a + j] += 0.040 * w * trem * v

        # viento / susurros: ruido filtrado que respira (la envolvente vale 0 en las juntas del loop)
        lp = lp2 = 0.0
        for i in range(N):
            lp += 0.035 * (rnd.uniform(-1, 1) - lp)
            lp2 += 0.25 * (lp - lp2)
            env = sin(math.pi * 3 * i / N) ** 2 * (0.6 + 0.4 * sin(tau * 5.3 * i / N))
            buf[i] += 2.2 * lp2 * env * 0.22

        # coro fantasmal: dos voces a distancia de semitono con vibrato, entran y salen despacio
        for st, semi in ((1, 12), (9, 13)):
            f = root * 2 ** (semi / 12.0) * 4
            start, dur = int(st * 1.0 * SR), int(5.0 * SR)
            for j in range(dur):
                t = j / SR
                w = sin(math.pi * j / dur) ** 2
                vib = 4.0 * sin(tau * 5.0 * t)
                v = sin(tau * (f + vib) * t) + 0.9 * sin(tau * (f * 16 / 15 + vib) * t + 0.7)
                buf[(start + j) % N] += 0.016 * w * v

        # campanas inarmonicas y lejanas (la cola se enrosca al inicio del loop)
        for step in range(32):
            if rnd.random() < 0.30:
                off, kind = prog[step // 8]
                semis = off + rnd.choice((0, 1, 6, third_of[kind], 11))
                f = root * 2 ** (semis / 12.0) * rnd.choice((4, 8))
                start, dur = int(step * 0.5 * SR), int(3.2 * SR)
                for j in range(dur):
                    tt = j / SR
                    buf[(start + j) % N] += 0.06 * exp(-1.7 * tt) * (
                        sin(tau * f * tt) + 0.45 * sin(tau * f * 2.76 * tt) + 0.25 * sin(tau * f * 5.40 * tt))

        # latido grave irregular (doble golpe, larga pausa)
        for beat in range(4):
            for off_t, amp in ((0.0, 0.34), (0.38, 0.22)):
                start = int((beat * 4.0 + off_t) * SR)
                for j in range(int(0.7 * SR)):
                    tt = j / SR
                    buf[(start + j) % N] += amp * exp(-7 * tt) * sin(tau * 42 * tt * (1 - 0.25 * tt))

        # gemidos graves descendentes
        for st in (6.5, 13.5):
            start, dur = int(st * SR), int(3.0 * SR)
            ph = 0.0
            for j in range(dur):
                tt = j / SR
                ph += tau * (root * 2.0 - root * 0.9 * tt / 3.0) / SR
                buf[(start + j) % N] += 0.12 * sin(math.pi * j / dur) ** 2 * (sin(ph) + 0.5 * sin(2.02 * ph))

        peak = max(1e-6, max(abs(v) for v in buf))
        k = 0.72 * 32767 / peak
        return [int(v * k) for v in buf]

    def _write(self, bid, path):
        samples = self.synth(bid)
        tmp = path + ".tmp"
        with wave.open(tmp, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(self.SR)
            w.writeframes(array.array("h", samples).tobytes())
        os.replace(tmp, path)

    def _start(self, bid, path):
        """Reproduce `path` en bucle. Devuelve False si no se pudo (el llamador usa la sintetizada)."""
        if not path.lower().endswith(".wav"):          # mp3 / wma -> MCI
            self._stop_winsound()                      # corta la musica sintetizada antes de abrir la propia
            if self.mci.play(path):
                self.current, self.cur_path = bid, path
                return True
            mark_bad(path, "no se pudo reproducir con MCI")
            return False
        try:
            self.mci.stop()
            self._stop_winsound()
            winsound.PlaySound(path, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_LOOP)
            self.current, self.cur_path = bid, path
            return True
        except Exception:
            return False

    def tick(self, now):
        """Cada ~1 s: si una pista MCI termino (sin repeat) la reinicia."""
        if now - self._last_tick < 1.0:
            return
        self._last_tick = now
        if self.mci.playing and not self.muted and self.mci.is_stopped():
            self.mci.restart()

    def _build_and_play(self, bid):
        path = self._path(bid)
        try:
            self._write(bid, path)
        except Exception:
            path = None
        finally:
            with self.lock:
                self.building.discard(bid)
        if path and self.want == bid and not self.muted and self.current != bid:
            if find_music(bid):                 # mientras se sintetizaba, el jugador eligio musica propia
                return
            self._start(bid, path)

    def play_theme(self, bid):
        bid = bid if bid in self.THEMES else 1
        self.want = bid
        if not self.enabled or self.muted or self.current == bid:
            return
        ext = find_music(bid)               # musica externa opcional (assets/music): mp3 / wav / wma
        if ext:
            if ext == self.cur_path and (self.mci.playing or ext.lower().endswith(".wav")) and self.current:
                self.current = bid          # misma pista en otro bioma: sigue sonando sin reiniciar
                return
            if self._start(bid, ext):
                return
        path = self._path(bid)
        if os.path.exists(path):
            self._start(bid, path)
            return
        with self.lock:
            if bid in self.building:
                return
            self.building.add(bid)
        threading.Thread(target=self._build_and_play, args=(bid,), daemon=True).start()

    def _purge(self):
        if self.enabled:
            self._stop_winsound()
        self.mci.stop()
        self.current = self.cur_path = None

    def reload(self):
        """Aplica de inmediato un cambio de cancion/carpeta elegido por el jugador."""
        want = self.want or 1
        self._purge()
        self.play_theme(want)

    def stop(self):
        self.want = None
        self._purge()

    def toggle(self):
        self.muted = not self.muted
        if self.muted:
            self._purge()
        else:
            self.play_theme(self.want or 1)
        return not self.muted

MUSIC = MusicEngine()
