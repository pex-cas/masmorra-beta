# -*- coding: utf-8 -*-
"""Efectos de sonido (Beep en un hilo con cola)."""
import queue
import threading
import time

from audio import HAS_WINSOUND, winsound


class SoundEngine:
    PATTERNS = {
        "slash": [(450, 25)], "hit": [(220, 35)], "crit": [(850, 45)],
        "fireball": [(320, 60)], "freeze": [(1200, 40)], "dash": [(600, 30)],
        "gold": [(1400, 20), (1800, 30)], "potion": [(700, 40), (900, 50)],
        "level_up": [(523, 60), (659, 60), (784, 60), (1046, 60)],
        "boss_roar": [(150, 80), (110, 80), (80, 80)],
        "game_over": [(350, 100), (280, 100), (200, 100), (130, 100)],
        "heavy": [(180, 60), (120, 80)],
        "ult": [(300, 50), (450, 50), (700, 50), (1000, 80)],
        "meteor": [(90, 90)],
        "secret": [(300, 60), (400, 60), (600, 90)],
    }

    def __init__(self):
        self.enabled = HAS_WINSOUND
        self.q = queue.Queue()
        self.last = 0.0
        if self.enabled:
            threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        while True:
            pattern = self.q.get()
            for f, d in pattern:
                try:
                    winsound.Beep(int(max(37, min(32767, f))), int(d))
                except Exception:
                    pass

    def play_sfx(self, name):
        if not self.enabled:
            return
        now = time.time()
        if now - self.last < 0.04 or self.q.qsize() > 3:
            return
        self.last = now
        pat = self.PATTERNS.get(name)
        if pat:
            self.q.put(pat)

AUDIO = SoundEngine()
