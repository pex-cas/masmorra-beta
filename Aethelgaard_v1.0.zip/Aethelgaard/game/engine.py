# -*- coding: utf-8 -*-
"""Motor principal: estado, entrada, simulacion y bucle de juego."""

from tkinter import font as tkfont
import math
import random
import time
import tkinter as tk
from audio.music import MUSIC
from audio.sfx import AUDIO
from combat.enemies import BOSS_BY_FLOOR, Enemy, HARD_BOSS_FLOORS
from combat.entities import GoldPile, Particle
from combat.skills import CombatMixin
from combat.spatial import SpatialHashGrid
from graphics.icons import IconBank
from graphics.renderer import RenderMixin
from graphics.sprites import SpriteBank
from graphics.textures import TextureAtlas
from inventory.items import Item, RARITY_COLORS, SCROLLS
from player.player import GUARD_SPEED, Player
from ui.help_text import MENU_STATES, PLAY_STATES
from ui.hud import HudMixin
from ui.panels import PanelsMixin
from world.mapimage import build_map_image
from world.dungeon import DungeonMap, TILE_CHEST, TILE_FLOOR, TILE_STAIRS_DOWN, TILE_WALL


FPS = 30                      # fotogramas por segundo del juego (simulacion + dibujo)
FRAME_TIME = 1.0 / FPS


class _Tgt:
    """Objetivo de autoapuntado no enemigo (pared secreta, cofre, santuario)."""
    dead, radius = False, 18

    def __init__(self, x, y):
        self.x, self.y = x, y


class GameEngine(PanelsMixin, CombatMixin, RenderMixin, HudMixin):
    """Motor del juego. Los sistemas grandes viven en mixins (UI, combate, render, HUD)."""

    def __init__(self, root):
        self.root = root
        root.title("Chronicles of Aethelgaard: The Abyssal Citadel")
        root.geometry("1100x720")
        root.configure(bg="#0a0a0f")
        root.resizable(True, True)          # ventana redimensionable y F11 = pantalla completa
        root.minsize(900, 600)

        self.view_w, self.view_h = 820, 720
        self.canvas = tk.Canvas(root, width=self.view_w, height=self.view_h, bg="#05050a",
                                highlightthickness=0, cursor="none")
        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.canvas.bind("<Configure>", self.on_canvas_resize)
        self.side_panel = tk.Frame(root, width=280, bg="#12131a", highlightthickness=1,
                                   highlightbackground="#2a2c3d")
        self.side_panel.pack(side=tk.RIGHT, fill=tk.Y)
        self.side_panel.pack_propagate(False)

        self.font_huge = tkfont.Font(family="Consolas", size=32, weight="bold")
        self.font_title = tkfont.Font(family="Consolas", size=18, weight="bold")
        self.font_big = tkfont.Font(family="Consolas", size=13, weight="bold")
        self.font_bold = tkfont.Font(family="Consolas", size=11, weight="bold")
        self.font_norm = tkfont.Font(family="Consolas", size=10)
        self.font_small = tkfont.Font(family="Consolas", size=8)

        self.sprites = SpriteBank()
        self.icons = IconBank()
        self.atlas = None
        self.atlases = {}
        self.state = "CLASS_SELECT"
        self.floor = 1
        self.player = None
        self.dungeon = None
        self.enemies, self.projectiles, self.particles = [], [], []
        self.floating_texts, self.dropped_items, self.effects = [], [], []
        self.spatial_grid = SpatialHashGrid(80)
        self.keys = {}
        self.mouse_x, self.mouse_y = self.view_w / 2, self.view_h / 2
        self.mouse_down = False
        self.camera_x = self.camera_y = 0.0
        self.cx = self.cy = 0.0
        self.cam_init = True
        self.shake = 0.0
        self.now = time.time()
        self._end_drawn = False
        self._lock_msg = 0.0
        self.mini = None
        self.boss_stage, self.map_open, self._mini_rect, self._map_dirty = False, False, None, False
        self.autoaim, self.auto_target, self.show_cursor = True, None, False
        self.scroll, self._view_state, self._stone_img = None, None, None
        self.side_scroll, self.menu, self.menu_scroll, self._menu_state, self._ws = None, None, None, None, 1.0
        self.shop_stock = []
        self.boss_armor_claimed = set()
        self.secondary_attack_cd = 0.0
        self.fullscreen = False

        root.bind("<KeyPress>", self.on_key_down)
        root.bind("<KeyRelease>", self.on_key_up)
        root.bind("<FocusOut>", lambda e: self.keys.clear())
        root.bind("<MouseWheel>", self.on_wheel)
        self.canvas.bind("<Motion>", self.on_mouse_move)
        self.canvas.bind("<B1-Motion>", self.on_mouse_move)
        self.canvas.bind("<ButtonPress-1>", self.on_left_down)
        self.canvas.bind("<ButtonRelease-1>", self.on_left_up)
        self.canvas.bind("<ButtonPress-3>", self.on_right_click)

        self.build_class_selection_screen()
        MUSIC.play_theme(1)
        self.last_frame_time = time.time()
        self.last_render_time = 0.0
        self._tl = self._dyn = None
        self._title_dirty = True
        self.game_loop()

    def start_game(self, char_class):
        self.player = Player(char_class)
        self.boss_armor_claimed = set()
        self.bosses_defeated = 0
        self.secondary_attack_cd = 0.0
        self.floor = 1
        self.keys.clear()
        self.mouse_down = False
        self._end_drawn = False
        self.state = "PLAYING"
        self.load_floor(1)
        self.build_ui_panels()

    # ------------------------------------------------------------------ pisos
    def load_floor(self, n, boss=False):
        self.floor, self.boss_stage, self.map_open = n, boss, False
        self.canvas.delete("all")                      # borra la portada / mapa y reinicia la capa de tiles
        self._tl = None
        self.dungeon = d = DungeonMap(n, 60, 60, 48, arena=boss)
        ts = d.tile_size
        atl = self.atlases.get(d.palette_id)       # una sola vez por paleta (se reutiliza al repetir el ciclo)
        if atl is None:
            atl = self.atlases[d.palette_id] = TextureAtlas(d.palette_id)
            atl.prewarm()
        self.atlas = atl
        MUSIC.play_theme(d.biome_id)
        self._build_map()                              # mapa completo y detallado, listo antes de empezar

        p = self.player
        p.x = d.spawn_pos[0] * ts + ts / 2
        p.y = d.spawn_pos[1] * ts + ts / 2
        p.invuln = 1.0
        for _x, _y, obj in self.dropped_items:               # el oro sin recoger no se pierde al cambiar de piso
            if isinstance(obj, GoldPile):
                p.gold += obj.amount
        for lst in (self.enemies, self.projectiles, self.particles, self.floating_texts,
                    self.dropped_items, self.effects):
            lst.clear()

        pool = [("Esqueleto", 5), ("Zombi Pútrido", 3)]
        if n >= 2: pool.append(("Arquero Espectral", 3))
        if n >= 3: pool.append(("Mago de Fuego", 2))
        if n >= 4: pool.append(("Minotauro Brutal", 2))
        names, weights = [a for a, _ in pool], [w for _, w in pool]
        boss_floor = (n % 5 == 0)
        if boss:
            r = d.rooms[0]
            self.enemies.append(Enemy((r.x + r.w - 5) * ts + ts / 2, r.cy * ts + ts / 2, BOSS_BY_FLOOR[n], n))
            if n == 8:  # combate doble: dos jefes y dos piezas de equipo
                self.enemies.append(Enemy((r.x + r.w - 5) * ts + ts / 2, (r.cy + 3) * ts + ts / 2, "Rey Espectral", n))
        for r in ([] if boss else d.rooms[1:]):
            cells = [c for c in r.cells if d.tiles[c[0]][c[1]] == TILE_FLOOR]
            if not cells:
                continue
            if boss_floor and r is d.rooms[-1]:
                # Sala del jefe: arena aparte con las escaleras al piso siguiente. Nadie mas vive aqui
                # (en el piso 5 el jefe dificil invoca esbirros durante la pelea).
                self.enemies.append(Enemy(r.cx * ts + ts / 2, r.cy * ts + ts / 2, "Señor del Abismo (JEFE)", n))
                if n not in HARD_BOSS_FLOORS:
                    for _ in range(3):
                        cx, cy = random.choice(cells)
                        self.enemies.append(Enemy(cx * ts + ts / 2, cy * ts + ts / 2, "Esqueleto", n))
                continue
            for _ in range(random.randint(2, 3 + n // 2)):
                cx, cy = random.choice(cells)
                self.enemies.append(Enemy(cx * ts + ts / 2, cy * ts + ts / 2, random.choices(names, weights)[0], n))

        # La tienda vende habilidades y pasivas, nunca equipo.
        self.shop_stock = self._build_shop_stock()
        self.cam_init = True
        d.compute_fov(p.x, p.y, 9)
        d.complete_wall_shell()
        self.add_floating_text(p.x, p.y - 40, f"PISO {n}: {'JEFE · ' if boss else ''}{d.biome['name'].upper()}", "#ffd166")

    def _build_map(self):
        self.mini = build_map_image(self.dungeon)
        self._map_sig = len(self.dungeon.found_secrets)

    def _map_scroll_index(self):
        return next(i for i, sc in enumerate(SCROLLS) if sc[2] == "map")

    def _map_unlocked(self):
        """El pergamino del mapa aparece en la tienda tras derrotar al tercer jefe (y hasta que se compra/aprende)."""
        p = self.player
        if getattr(self, "bosses_defeated", 0) < 3 or "map" in p.learned_passives:
            return False
        return not any(getattr(i, "stats", {}).get("passive") == "map" for i in p.inventory)

    def _build_shop_stock(self):
        stock = [Item.generate_scroll(i) for i, sc in enumerate(SCROLLS) if sc[2] != "map"]
        if self._map_unlocked():
            stock.append(Item.generate_scroll(self._map_scroll_index()))
        return stock

    def _unlock_map_scroll(self):
        if self._map_unlocked() and not any(i.stats.get("passive") == "map" for i in self.shop_stock):
            self.shop_stock.append(Item.generate_scroll(self._map_scroll_index()))
            p = self.player
            self.add_floating_text(p.x, p.y - 70, "¡Nuevo en la tienda: Pergamino del Mapa Abisal!", "#4cc9f0")

    def apply_skins(self):
        """Reconstruye los sprites con las skins elegidas (un PNG danado se ignora y queda el original)."""
        self.sprites = SpriteBank()
        self.update_content_view()

    def update_boss_gate(self):
        """Sala del jefe: al entrar se sella la unica entrada; al morir el jefe se vuelve a abrir."""
        d, p = self.dungeon, self.player
        r = d.boss_room
        if r is None or not d.boss_door:
            return
        boss_alive = any(e.ai == "boss" and not e.dead for e in self.enemies)
        if not d.boss_sealed:
            ptx, pty = int(p.x // d.tile_size), int(p.y // d.tile_size)
            inside = r.x + 1 <= ptx < r.x + r.w - 1 and r.y + 1 <= pty < r.y + r.h - 1   # ya bien adentro
            if inside and boss_alive:
                self._set_boss_door(TILE_WALL)
                d.boss_sealed = True
                self.add_floating_text(p.x, p.y - 50, "¡La entrada se selló!", "#ff5400")
                AUDIO.play_sfx("boss_roar")
                self.shake = max(self.shake, 0.4)
        elif not boss_alive:
            self._set_boss_door(TILE_FLOOR)
            d.boss_sealed = False
            self.add_floating_text(p.x, p.y - 50, "La entrada se abrió", "#06d6a0")

    def _set_boss_door(self, tile):
        d = self.dungeon
        for (x, y) in d.boss_door:
            d.tiles[x][y] = tile
            d.revealed[x][y] = True
            d.new_revealed.append((x, y))          # repinta el minimapa
        for (x, y) in d.boss_door:
            d.rebake_around(x, y)
        d._last_ptile = None                       # fuerza recalcular el campo de vision (cierra/abre la vista)

    def summon_minions(self, boss):
        """El jefe dificil invoca esbirros a su alrededor (maximo 6 vivos a la vez)."""
        d = self.dungeon
        ts = d.tile_size
        n, boss.pending_summons = boss.pending_summons, 0
        alive = sum(1 for e in self.enemies if not e.dead and e.name == "Esqueleto"
                    and math.hypot(e.x - boss.x, e.y - boss.y) < 450)
        for _ in range(max(0, min(n, 6 - alive))):
            for _try in range(12):
                a, r = random.uniform(0, 6.283), random.uniform(60, 130)
                x, y = boss.x + math.cos(a) * r, boss.y + math.sin(a) * r
                if d.can_move(x, y, 9):
                    self.enemies.append(Enemy(x, y, "Esqueleto", self.floor))
                    break
        self.add_floating_text(boss.x, boss.y - 60, "¡El jefe invoca esbirros!", "#e0aaff")
        AUDIO.play_sfx("boss_roar")
        self.shake = max(self.shake, 0.2)

    def on_canvas_resize(self, event):
        self.view_w, self.view_h = max(400, event.width), max(300, event.height)
        self._map_dirty = True
        self._title_dirty = True

    def toggle_fullscreen(self):
        self.fullscreen = not self.fullscreen
        self.root.attributes("-fullscreen", self.fullscreen)

    def toggle_cursor(self):
        self.show_cursor = not self.show_cursor
        self.canvas.config(cursor="crosshair" if self.show_cursor else "none")

    # ------------------------------------------------------------------ autoapuntado
    def _find_target(self):
        p, d = self.player, self.dungeon
        ts = d.tile_size
        best, bd = None, 480.0 ** 2
        for e in self.enemies:
            if e.dead:
                continue
            dd = (e.x - p.x) ** 2 + (e.y - p.y) ** 2
            if dd < bd:
                tx, ty = int(e.x // ts), int(e.y // ts)
                if 0 <= tx < d.width and 0 <= ty < d.height and d.visible[tx][ty]:
                    best, bd = e, dd
        if best is None:
            best = self._find_secret_target()
        return best

    def _los(self, x0, y0, x1, y1, end_tile=None):
        d = self.dungeon
        ts = d.tile_size
        n = max(1, int(math.hypot(x1 - x0, y1 - y0) // (ts / 2)))
        for i in range(1, n):
            tx, ty = int((x0 + (x1 - x0) * i / n) // ts), int((y0 + (y1 - y0) * i / n) // ts)
            if (tx, ty) == end_tile:
                break
            if not (0 <= tx < d.width and 0 <= ty < d.height) or d.tiles[tx][ty] in (TILE_WALL, 0, 7, 8):
                return False
        return True

    def _find_secret_target(self):
        """Sin enemigos: paredes secretas visibles y cofres alcanzables."""
        p, d = self.player, self.dungeon
        ts = d.tile_size
        best, bd = None, 420.0 ** 2
        cand = [(sx, sy) for (sx, sy) in d.secrets]
        r = int(420 // ts) + 1
        px, py = int(p.x // ts), int(p.y // ts)
        for x in range(max(0, px - r), min(d.width, px + r + 1)):
            for y in range(max(0, py - r), min(d.height, py + r + 1)):
                if d.tiles[x][y] == TILE_CHEST:
                    cand.append((x, y))
        for (tx, ty) in cand:
            if not (0 <= tx < d.width and 0 <= ty < d.height) or not d.visible[tx][ty]:
                continue
            cx, cy = tx * ts + ts / 2, ty * ts + ts / 2
            dd = (cx - p.x) ** 2 + (cy - p.y) ** 2
            if dd < bd and self._los(p.x, p.y, cx, cy, (tx, ty)):
                best, bd = _Tgt(cx, cy), dd
        return best

    # ------------------------------------------------------------------ entrada
    def on_key_down(self, event):
        key = event.keysym.lower()
        self.keys[key] = True
        if key == 'm':
            AUDIO.set_muted(not MUSIC.toggle())
        elif key == 'f11':
            self.toggle_fullscreen()
        if self.map_open:
            if key in ('escape', 'n'):
                self.close_map()
            return
        if key == 'n' and self.state == "PLAYING":
            self.open_map()
            return
        if self.state not in PLAY_STATES or self.player is None:
            return
        if self.state == "PAUSED":                # en pausa solo O / Esc reanudan (M y F11 ya se atendieron arriba)
            if key in ('o', 'escape'):
                self.toggle_pause()
            return
        if key == 'escape':
            if self.state in MENU_STATES:
                self.close_menu()
            elif self.fullscreen:
                self.toggle_fullscreen()
        elif key == 'p': self.toggle_cursor()
        elif key in ('g', 'h'): self.toggle_guide()
        elif key in ('i', 'tab'): self.toggle_inventory()
        elif key in ('t', 'k'): self.toggle_talents()
        elif key == 'b': self.toggle_shop()
        elif key == 'o': self.toggle_pause()
        elif self.state in MENU_STATES:
            return                                # en pausa: sin pociones ni acciones
        elif key == 'v' and self.state == 'PLAYING': self.attack_secondary()
        elif key == 'q':
            h = self.player.use_hp_potion()
            if h > 0:
                self.add_floating_text(self.player.x, self.player.y - 20, f"+{h} HP", "#06d6a0")
                self.update_content_view()

    def on_key_up(self, event):
        self.keys[event.keysym.lower()] = False

    def on_mouse_move(self, event):
        self.mouse_x, self.mouse_y = event.x, event.y

    def open_map(self):
        p = self.player
        if p is None or "map" not in p.learned_passives:
            if p is not None:
                self.add_floating_text(p.x, p.y - 40, "Necesitás el Pergamino del Mapa Abisal (Tienda, tras el 3.er jefe)", "#9aa0aa")
            return
        if getattr(self, "_map_sig", None) != len(self.dungeon.found_secrets):
            self._build_map()                          # se descubrio una camara secreta: se actualiza la imagen
        self.map_open, self._map_dirty = True, True
        self.mouse_down = False
        self.keys.clear()
        self.canvas.config(cursor="arrow")

    def close_map(self):
        self.map_open = False
        self.canvas.config(cursor="crosshair" if self.show_cursor else "none")

    def render_map(self):
        """Mapa ampliado del piso completo (imagen ya generada; se dibuja una vez, el juego esta en pausa)."""
        from world.mapimage import PX
        c, d, p = self.canvas, self.dungeon, self.player
        W, H = self.view_w, self.view_h
        c.delete("all"); self._tl = None
        c.create_rectangle(0, 0, W, H, fill="#05050a", outline="")
        z = max(1, int(min(W - 60, H - 110) / (d.height * PX)))
        img = self._map_img = self.mini.zoom(z)
        k = PX * z
        ox, oy = (W - d.width * k) / 2, (H - d.height * k) / 2 + 12
        c.create_image(ox, oy, image=img, anchor="nw")
        c.create_rectangle(ox - 2, oy - 2, ox + d.width * k + 2, oy + d.height * k + 2, outline="#2a2c3d")
        seen = 0
        for i, r in enumerate(d.rooms):
            explored = d.revealed[r.cx][r.cy] or any(d.revealed[x][y] for (x, y) in r.cells[::7])
            seen += 1 if explored else 0
            c.create_rectangle(ox + r.x * k, oy + r.y * k, ox + (r.x + r.w) * k, oy + (r.y + r.h) * k,
                               outline="#4cc9f0" if explored else "#27506a")
        px, py = ox + p.x / d.tile_size * k, oy + p.y / d.tile_size * k
        c.create_oval(px - 6, py - 6, px + 6, py + 6, fill="#ffd166", outline="#ffffff", width=2)
        c.create_text(W / 2, 22, text=f"MAPA · PISO {self.floor}", fill="#e8c2d0", font=self.font_title)
        c.create_text(W / 2, H - 22, fill="#8d99ae", font=self.font_small,
                      text=f"Salas exploradas: {seen}/{len(d.rooms)}   ·   ● Vos   ·   Escaleras en azul   ·   Clic / Esc / N para cerrar")

    def on_left_down(self, event):
        if self.map_open:
            self.close_map()
            return
        mr = self._mini_rect
        if self.state == "PLAYING" and mr and mr[0] <= event.x <= mr[2] and mr[1] <= event.y <= mr[3]:
            self.open_map()
            return
        if self.state in ("GAMEOVER", "VICTORY"):
            self.restart_game()
        elif self.state in PLAY_STATES and self.state != "PAUSED":
            self.mouse_down = True

    def on_left_up(self, event):
        self.mouse_down = False

    def on_right_click(self, event):
        if self.state == "PLAYING" and self.player.cd[1] <= 0 and self.player.ult_time <= 0 and not self.player.guarding:
            self.attack_strong()

    def move_vector(self):
        k = self.keys
        mx = (1 if (k.get('d') or k.get('right')) else 0) - (1 if (k.get('a') or k.get('left')) else 0)
        my = (1 if (k.get('s') or k.get('down')) else 0) - (1 if (k.get('w') or k.get('up')) else 0)
        return mx, my

    def aim(self):
        p = self.player
        tg = self.auto_target
        if self.autoaim and tg is not None and not tg.dead:
            return math.atan2(tg.y - p.y, tg.x - p.x)
        return math.atan2(self.mouse_y + self.camera_y - p.y, self.mouse_x + self.camera_x - p.x)

    # ------------------------------------------------------------------ dash
    def execute_dash(self):
        p = self.player
        if p.dash_cd > 0 or p.ult_time > 0:
            return
        mx, my = self.move_vector()
        if mx == 0 and my == 0:
            a = self.aim()
            mx, my = math.cos(a), math.sin(a)
        else:
            ln = math.hypot(mx, my)
            mx, my = mx / ln, my / ln
        p.dash_dx, p.dash_dy = mx, my
        p.dash_cd = 1.6 * (1.0 - p.cdr)
        p.dash_time = 0.18
        p.invuln = max(p.invuln, 0.22)
        AUDIO.play_sfx("dash")
        for _ in range(8):
            self.particles.append(Particle(p.x, p.y + 10, random.uniform(-60, 60), random.uniform(-60, 60), 0.25, "#8ecae6"))

    # ==========================================================================
    # PARTE B: bucle, simulacion, render, HUD
    # ==========================================================================
    def game_loop(self):
        t0 = time.perf_counter()
        try:
            self._tick()
        except Exception:                             # un error en un fotograma no debe detener el juego para siempre
            import traceback
            from game.assets import log
            log.error("Error en el bucle del juego", exc_info=True)
            traceback.print_exc()
            self.keys.clear()
            self.mouse_down = False
        finally:                                      # 30 fps fijos: se descuenta lo que tardo el fotograma y siempre queda tiempo libre para la entrada
            self.root.after(max(2, int((FRAME_TIME - (time.perf_counter() - t0)) * 1000)), self.game_loop)

    def _tick(self):
        now = time.time()
        dt = min(0.05, now - self.last_frame_time)
        self.last_frame_time = now
        self.now = now
        MUSIC.tick(now)
        if self.map_open and self.state == "PLAYING":
            if self._map_dirty:
                self._map_dirty = False
                self.render_map()
        elif self.state == "PLAYING":
            self.update_simulation(dt)
            if self.state == "PLAYING" and now - self.last_render_time >= FRAME_TIME * 0.7:
                self.render()
                self.last_render_time = now
        elif self.state in MENU_STATES or self.state == "PAUSED":
            pass                                  # menu abierto o pausa (O): el juego esta congelado
        elif self.state == "CLASS_SELECT":
            if self._title_dirty:                 # la portada es estatica: se dibuja una vez (y al redimensionar)
                self._title_dirty = False
                self.render_title()
        elif not self._end_drawn:
            self._end_drawn = True
            self.render_game_over() if self.state == "GAMEOVER" else self.render_victory()

    def _set(self, lbl, txt):
        if lbl.cget("text") != txt:
            lbl.config(text=txt)

    def update_simulation(self, dt):
        p, d = self.player, self.dungeon
        ts = d.tile_size
        keys = self.keys

        self.spatial_grid.clear()
        for e in self.enemies:
            if not e.dead:
                self.spatial_grid.insert(e)

        self.auto_target = self._find_target() if self.autoaim else None

        # --- timers y regeneracion
        for i in range(3):
            if p.cd[i] > 0: p.cd[i] -= dt
        self.secondary_attack_cd = max(0.0, getattr(self, "secondary_attack_cd", 0.0) - dt)
        if p.dash_cd > 0: p.dash_cd -= dt
        if p.invuln > 0: p.invuln -= dt
        if p.hurt > 0: p.hurt -= dt
        p.update_guard(keys.get('l') and p.ult_time <= 0, dt)

        # --- movimiento: caminar / SPRINT
        mx, my = self.move_vector()
        p.moving = bool(mx or my)
        sprint = keys.get('shift_l') or keys.get('shift_r')
        p.sprinting = False
        vx = vy = 0.0
        spd = p.speed * (1.2 if p.ult_time > 0 else (GUARD_SPEED if p.guarding else 1.0))
        if p.moving:
            ln = math.hypot(mx, my)
            if sprint and not p.guarding:
                p.sprinting = True
                spd *= 1.55
            vx, vy = mx / ln * spd * dt, my / ln * spd * dt
        p.stamina = p.max_stamina
        p.exhausted = False
        rp = p.radius * 0.6
        if vx or vy:
            if d.can_move(p.x + vx, p.y, rp): p.x += vx
            if d.can_move(p.x, p.y + vy, rp): p.y += vy
        if p.sprinting and random.random() < 0.5:
            self.particles.append(Particle(p.x, p.y + 20, random.uniform(-20, 20), random.uniform(-25, -5), 0.3, "#8d8d99", 3))
        # Al desplazarse, la orientación sigue el movimiento horizontal.
        # Si frenás, conserva el último lado; solo gira hacia el objetivo mientras atacás.
        attacking = not p.guarding and (self.mouse_down or p.ult_time > 0 or any(keys.get(k) for k in "xvcz"))
        if mx:
            p.facing = "R" if mx > 0 else "L"
        elif attacking:
            p.facing = "R" if math.cos(self.aim()) >= 0 else "L"
        p.anim += dt * (1.7 if p.sprinting else 1.0)

        # --- ataques X / C / Z (mantener para repetir)
        if p.guarding:
            pass                                  # cubriendote no atacas
        elif p.ult_time <= 0:
            if (keys.get('x') or self.mouse_down) and p.cd[0] <= 0: self.attack_base()
            if keys.get('v') and self.secondary_attack_cd <= 0: self.attack_secondary()
            if keys.get('c') and p.cd[1] <= 0: self.attack_strong()
            if keys.get('z') and p.cd[2] <= 0: self.attack_ult()
        else:
            p.ult_time -= dt
            p.ult_tick -= dt
            p.invuln = max(p.invuln, 0.1)
            if p.ult_tick <= 0:
                p.ult_tick = 0.11
                AUDIO.play_sfx("slash")
                self.hit_secret_walls(p.x, p.y, 0, 125, 4.0, 1)
                for e in self.spatial_grid.query_radius(p.x, p.y, 150):
                    if not e.dead and math.hypot(e.x - p.x, e.y - p.y) - e.radius <= 120:
                        dmg, cr = self.roll(p.phys_dmg * 0.9)
                        self.damage_enemy(e, dmg, cr, kb=170, src=(p.x, p.y))

        self.update_boss_gate()

        # --- interacciones con el mapa
        ptx, pty = int(p.x // ts), int(p.y // ts)
        t = d.tiles[ptx][pty]
        if t == TILE_STAIRS_DOWN:
            if any(e.ai == "boss" and not e.dead for e in self.enemies):
                if self.now - self._lock_msg > 2:
                    self._lock_msg = self.now
                    self.add_floating_text(p.x, p.y - 40, "¡Derrota al jefe para descender!", "#ff5400")
            elif self.floor >= 10:
                self.state = "VICTORY"
                MUSIC.stop()
                AUDIO.play_sfx("level_up")
                return
            else:
                nb = not self.boss_stage and self.floor % 2 == 0 and self.floor < 10   # piso de jefe cada 2 niveles
                self.load_floor(self.floor if nb else self.floor + 1, boss=nb)
                AUDIO.play_sfx("dash")
                return
        elif t == TILE_CHEST:
            d.tiles[ptx][pty] = TILE_FLOOR
            AUDIO.play_sfx("gold")
            if (ptx, pty) in getattr(d, "secret_chests", set()):
                g = 300 if random.random() < 0.25 else 100
                self.drop_gold(p.x, p.y, g)
                self.dropped_items.append((p.x + 10, p.y, "hp"))
                self.add_floating_text(p.x, p.y - 30, f"¡Cofre secreto: {g} de oro y poción!", "#ffd166")
            else:
                self.add_floating_text(p.x, p.y - 30, "Este cofre no contiene botín secreto", "#9aa0aa")


        kept = []
        for ix, iy, obj in self.dropped_items:
            dist = math.hypot(p.x - ix, p.y - iy)
            if isinstance(obj, GoldPile):
                if dist < 150 and dist > 0.1:         # iman: el oro vuela hacia vos
                    k = min(1.0, (240 + (150 - dist) * 4) * dt / dist)
                    ix += (p.x - ix) * k
                    iy += (p.y - iy) * k
                    dist = math.hypot(p.x - ix, p.y - iy)
                if dist < 26:
                    p.gold += obj.amount
                    AUDIO.play_sfx("gold")
                    self.add_floating_text(p.x, p.y - 35, f"+{obj.amount}", "#ffd166")
                    continue
                kept.append((ix, iy, obj))
                continue
            if dist < 32:
                if isinstance(obj, str):
                    p.hp_potions += 1
                    AUDIO.play_sfx("potion")
                    self.add_floating_text(p.x, p.y - 35, "+Poción", "#ff4d6d")
                    self.update_content_view()
                    continue
                if len(p.inventory) < p.max_inv:
                    p.inventory.append(obj)
                    AUDIO.play_sfx("slash")
                    self.add_floating_text(p.x, p.y - 35, f"+{obj.name}", RARITY_COLORS[obj.rarity])
                    self.update_content_view()
                    continue
            kept.append((ix, iy, obj))
        self.dropped_items = kept

        d.compute_fov(p.x, p.y, 9)
        d.complete_wall_shell()

        # --- enemigos
        near = []
        for e in self.enemies:
            if abs(e.x - p.x) < 700 and abs(e.y - p.y) < 700:
                e.update(dt, p, d, self.projectiles)
                near.append(e)
                if e.pending_summons:
                    self.summon_minions(e)
        if p.retaliation_damage > 0:
            nearby = [e for e in self.enemies if not e.dead and math.hypot(e.x-p.x, e.y-p.y) <= 150]
            if nearby:
                amount = p.retaliation_damage
                p.retaliation_damage = 0
                for e in nearby:
                    e.hp -= amount
                    self.add_floating_text(e.x, e.y - 24, str(amount), "#8ecae6")
                    if e.hp <= 0:
                        self.kill_enemy(e)
            else:
                p.retaliation_damage = 0
        for e in near:
            if e.dead or e.ai == "boss":
                continue
            for o in self.spatial_grid.query_radius(e.x, e.y, e.radius * 1.5):
                if o is e or o.dead:
                    continue
                dx, dy = e.x - o.x, e.y - o.y
                dd = math.hypot(dx, dy)
                if dd < 0.01:
                    dx, dy, dd = random.uniform(-1, 1), random.uniform(-1, 1), 1.0
                push = (e.radius + o.radius) * 0.8 - dd
                if push > 0:
                    e._move(dx / dd * push * 0.15, dy / dd * push * 0.15, d)
        for e in self.enemies:
            if e.hp <= 0 and not e.dead:
                self.kill_enemy(e)
        self.enemies = [e for e in self.enemies if not e.dead]

        # --- proyectiles
        for pr in self.projectiles:
            pr.update(dt, d)
            if pr.ptype == "fireball" and random.random() < 0.6:
                self.particles.append(Particle(pr.x, pr.y, random.uniform(-30, 30), random.uniform(-30, 30), 0.3,
                                               random.choice(("#ff8c1a", "#ffd23f")), 4))
            if pr.dead:
                if pr.wall_hit and pr.is_player and pr.aoe <= 0:
                    wsx, wsy = int(pr.x // ts), int(pr.y // ts)
                    if (wsx, wsy) in d.secrets:
                        self.hit_secret(wsx, wsy, 1)
                if pr.aoe > 0 and pr.is_player:
                    self.explode(pr.x, pr.y, pr.aoe, pr.dmg, pr.burn)
                continue
            if pr.is_player:
                for e in self.spatial_grid.query_radius(pr.x, pr.y, pr.radius + 40):
                    if e.dead or id(e) in pr.hit:
                        continue
                    if math.hypot(e.x - pr.x, e.y - pr.y) > pr.radius + e.radius:
                        continue
                    if pr.aoe > 0:
                        self.explode(pr.x, pr.y, pr.aoe, pr.dmg, pr.burn)
                        pr.dead = True
                        break
                    self.damage_enemy(e, pr.dmg, pr.crit, kb=90, src=(pr.x - pr.vx * 0.05, pr.y - pr.vy * 0.05))
                    pr.hit.add(id(e))
                    pr.pierce -= 1
                    if pr.pierce <= 0:
                        pr.dead = True
                        break
            elif math.hypot(p.x - pr.x, p.y - pr.y) < p.radius * 0.8 + pr.radius:
                p.take_damage(pr.dmg)
                pr.dead = True
                for _ in range(4):
                    self.particles.append(Particle(pr.x, pr.y, random.uniform(-60, 60), random.uniform(-60, 60), 0.25, pr.color, 3))
        self.projectiles = [pr for pr in self.projectiles if not pr.dead]

        # --- efectos (meteoros, cuchillas)
        for ef in list(self.effects):
            ef.life -= dt
            if ef.kind == "spin":
                ef.x, ef.y = p.x, p.y
            elif ef.kind == "meteor" and ef.life <= 0:
                self.explode(ef.x, ef.y, ef.r, ef.dmg, 2.5)
        self.effects = [ef for ef in self.effects if ef.life > 0]

        for pt in self.particles:
            pt.x += pt.vx * dt
            pt.y += pt.vy * dt
            pt.life -= dt
        self.particles = [pt for pt in self.particles if pt.life > 0]
        for ft in self.floating_texts:
            ft.y -= 28 * dt
            ft.life -= dt
        self.floating_texts = [ft for ft in self.floating_texts if ft.life > 0]
        for txt, col in p.texts:
            self.add_floating_text(p.x + random.randint(-10, 10), p.y - 34, txt, col)
        p.texts.clear()
        self.shake = max(0.0, self.shake - dt)

        if p.hp <= 0:
            self.state = "GAMEOVER"
            MUSIC.stop()
            AUDIO.play_sfx("game_over")

        self._set(self.lbl_hero, f"{p.char_class} Lv.{p.level}")
        self._set(self.hud_hp, f"Salud: {int(p.hp)}/{p.max_hp}")
        self._set(self.hud_mp, f"Defensa: {int(p.defense)}/{p.max_def}")
        self._set(self.hud_xp, f"XP:    {p.xp}/{p.xp_to_next}")
        self._set(self.hud_gold, f"Oro: {p.gold}g | Piso {self.floor}")

        tx, ty = p.x - self.view_w / 2, p.y - self.view_h / 2
        if self.cam_init:
            self.camera_x, self.camera_y, self.cam_init = tx, ty, False
        else:
            k = min(1.0, 10 * dt)
            self.camera_x += (tx - self.camera_x) * k
            self.camera_y += (ty - self.camera_y) * k

    def restart_game(self):
        self.keys.clear()
        self.mouse_down = False
        self._end_drawn = False
        self.state = "CLASS_SELECT"
        self.map_open = False
        self._title_dirty = True
        self.build_class_selection_screen()
        MUSIC.play_theme(1)
