# -*- coding: utf-8 -*-
"""Pruebas de: musica/skins elegidas por el jugador, jefe dificil del piso 5 y sala del jefe."""
import json
import os
import random
import tempfile
import unittest

from tests._helpers import have_tk, install_fake_tk

from combat.enemies import Enemy, HARD_BOSS_FLOOR   # noqa: E402
from game import assets, mods                          # noqa: E402


def make_wav(path, frames=2000):
    import wave
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(8000)
        w.writeframes(b"\x00\x00" * frames)


class TestUserMusic(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        mods.clear_skins.__globals__["_cfg"]["music"] = None

    def tearDown(self):
        mods._cfg["music"] = None

    def test_single_song_plays_in_every_biome(self):
        a = os.path.join(self.tmp, "a.wav"); make_wav(a)
        mods._cfg["music"] = a
        self.assertEqual({assets.find_music(b) for b in (1, 2, 3, 4)}, {a})

    def test_folder_is_spread_by_biome_and_ignores_other_files(self):
        for n in ("a.wav", "b.wav"):
            make_wav(os.path.join(self.tmp, n))
        open(os.path.join(self.tmp, "notas.txt"), "w").write("x")
        mods._cfg["music"] = self.tmp
        got = [os.path.basename(assets.find_music(b)) for b in (1, 2, 3, 4)]
        self.assertEqual(got, ["a.wav", "b.wav", "a.wav", "b.wav"])

    def test_missing_or_corrupt_falls_back_to_game_music(self):
        mods._cfg["music"] = os.path.join(self.tmp, "no_existe.mp3")
        self.assertEqual(mods.music_files(), [])
        bad = os.path.join(self.tmp, "roto.wav"); open(bad, "wb").write(b"no soy un wav")
        mods._cfg["music"] = bad
        self.assertNotEqual(assets.find_music(1), bad)       # se descarta y queda la sintetizada / assets/music

    def test_config_roundtrip_and_broken_config(self):
        p = os.path.join(self.tmp, "mods.json")
        mods._cfg["music"] = "X"; mods.save(p)
        mods._cfg["music"] = None; mods.load(p)
        self.assertEqual(mods.get("music"), "X")
        open(p, "w").write("{ esto no es json")
        mods.load(p)
        self.assertIsNone(mods.get("music"))


class TestSkins(unittest.TestCase):
    def test_skin_lookup_priority_and_missing(self):
        tmp = tempfile.mkdtemp()
        folder_png = os.path.join(tmp, "guerrero.png"); open(folder_png, "wb").write(b"x")
        own = os.path.join(tmp, "otro.png"); open(own, "wb").write(b"x")
        old = dict(mods._cfg)
        try:
            mods._cfg.update(skin_dir=tmp, skin_files={})
            self.assertEqual(mods.skin_png("Guerrero"), folder_png)
            self.assertIsNone(mods.skin_png("Mago"))
            mods._cfg["skin_files"]["Guerrero"] = own            # el archivo puntual gana a la carpeta
            self.assertEqual(mods.skin_png("Guerrero"), own)
            mods._cfg["skin_files"]["Guerrero"] = os.path.join(tmp, "borrado.png")
            self.assertEqual(mods.skin_png("Guerrero"), folder_png)
        finally:
            mods._cfg.clear(); mods._cfg.update(old)


class TestHardBoss(unittest.TestCase):
    def test_floor5_and_final_boss_are_much_harder(self):
        b5 = Enemy(0, 0, "Señor del Abismo (JEFE)", HARD_BOSS_FLOOR)
        b4 = Enemy(0, 0, "Señor del Abismo (JEFE)", 4)
        base5 = int(550 * (1 + 4 * 0.22))
        self.assertTrue(b5.hard)
        self.assertGreaterEqual(b5.max_hp, base5 * 2.0)
        self.assertGreater(b5.dmg, int(28 * (1 + 4 * 0.22)) * 1.5)
        self.assertFalse(b4.hard)
        self.assertFalse(Enemy(0, 0, "Esqueleto", 5).hard)

    def test_other_bosses_and_common_enemies_unchanged(self):
        e = Enemy(0, 0, "Minotauro Brutal", 5)
        self.assertEqual(e.max_hp, int(130 * (1 + 4 * 0.22)))
        b10 = Enemy(0, 0, "Señor del Abismo (JEFE)", 10)
        self.assertTrue(b10.hard)
        self.assertGreater(b10.max_hp, int(550 * (1 + 9 * 0.22)) * 2)

    def test_summons_trigger_at_hp_thresholds_and_freeze_is_capped(self):
        class P:   # jugador minimo
            x, y, radius = 400.0, 0.0, 16
            def take_damage(self, *_): return 0, False
        class D:
            def can_move(self, *a): return True
        b = Enemy(0, 0, "Señor del Abismo (JEFE)", 5)
        proj = []
        b.hp = b.max_hp * 0.70
        b.update(0.05, P(), D(), proj)
        self.assertEqual(b.pending_summons, 2)
        b.hp = b.max_hp * 0.20
        b.update(0.05, P(), D(), proj)
        self.assertEqual(b.pending_summons, 2 + 4)               # cruzo 50% y 25%
        b.frozen_time = 5.0
        b.update(0.05, P(), D(), proj)
        self.assertLessEqual(b.frozen_time, 0.3)

    def test_three_attack_patterns_fire_projectiles(self):
        class P:
            x, y, radius = 300.0, 0.0, 16
            def take_damage(self, *_): return 0, False
        class D:
            def can_move(self, *a): return True
        b = Enemy(0, 0, "Señor del Abismo (JEFE)", 5)
        seen = set()
        for _ in range(3):
            proj = []
            b.attack_cd = 0.0
            b.update(0.01, P(), D(), proj)
            seen.add(b.pattern)
            self.assertGreater(len(proj), 4)
        self.assertEqual(seen, {0, 1, 2})


@unittest.skipIf(have_tk(), "El motor sin ventana solo se arma con el Tk simulado")
class TestBossRoomAndLock(unittest.TestCase):
    def _engine(self, seed):
        from tests.test_engine_headless import TestEngineHeadless
        random.seed(seed)
        eng = TestEngineHeadless("build").build("Guerrero")
        eng.load_floor(5)
        return eng

    def test_floor5_arena_has_boss_and_stairs_and_no_other_enemies(self):
        for seed in range(8):
            eng = self._engine(seed)
            d = eng.dungeon
            arena = d.rooms[-1]
            bosses = [e for e in eng.enemies if e.ai == "boss"]
            self.assertEqual(len(bosses), 1)
            self.assertTrue(bosses[0].hard)
            inside = [e for e in eng.enemies if (int(e.x // 48), int(e.y // 48)) in set(arena.cells)]
            self.assertEqual(inside, bosses, "seed %d: la arena es solo del jefe" % seed)
            self.assertIn(d.stairs_pos, arena.cells)               # la puerta al piso 6 esta en su sala

    def test_stairs_locked_until_boss_dies(self):
        eng = self._engine(6)
        d, p = eng.dungeon, eng.player
        sx, sy = d.stairs_pos
        p.x, p.y = sx * 48 + 24, sy * 48 + 24
        eng.update_simulation(0.016)
        self.assertEqual(eng.floor, 5)                            # no baja con el jefe vivo
        for e in eng.enemies:
            if e.ai == "boss":
                eng.kill_enemy(e)
        eng.update_simulation(0.016)
        self.assertEqual(eng.floor, 6)                            # muerto el jefe, las escaleras funcionan

    def test_summons_spawn_minions_near_boss_with_cap(self):
        eng = self._engine(3)
        boss = next(e for e in eng.enemies if e.ai == "boss")
        boss.pending_summons = 20
        before = len(eng.enemies)
        eng.summon_minions(boss)
        self.assertLessEqual(len(eng.enemies) - before, 6)
        self.assertGreater(len(eng.enemies) - before, 0)
        self.assertEqual(boss.pending_summons, 0)

    def test_o_key_pauses_and_resumes_instead_of_options_menu(self):
        eng = self._engine(1)
        self.assertFalse(hasattr(eng, "toggle_mods"))             # el menu de opciones [O] ya no existe
        self.assertNotIn("MODS", eng.MENU_TITLES)
        eng._draw_pause_overlay = lambda: None
        eng.canvas = type("C", (), {"delete": lambda *a, **k: None})()
        ev = type("E", (), {"keysym": "o"})()
        eng.on_key_down(ev)
        self.assertEqual(eng.state, "PAUSED")
        x, y = eng.player.x, eng.player.y
        eng.keys["d"] = True
        eng.on_key_down(type("E", (), {"keysym": "i"})())          # en pausa no se abren menus
        self.assertEqual(eng.state, "PAUSED")
        eng.on_key_down(ev)
        self.assertEqual(eng.state, "PLAYING")
        self.assertEqual((eng.player.x, eng.player.y), (x, y))


if __name__ == "__main__":
    unittest.main()
