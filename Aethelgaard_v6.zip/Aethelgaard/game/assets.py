# -*- coding: utf-8 -*-
"""Rutas del proyecto, registro de errores y carga opcional de recursos externos.

Regla general: si existe un recurso externo valido se usa; si no existe o esta danado
(se registra en logs/game.log) se usa el recurso integrado que genera el propio codigo.
Ningun recurso externo es obligatorio.
"""
import logging
import os
import re
import unicodedata
import wave
from logging.handlers import RotatingFileHandler

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSETS_DIR = os.path.join(BASE_DIR, "assets")
LOGS_DIR = os.path.join(BASE_DIR, "logs")

log = logging.getLogger("aethelgaard")


def _setup_logging():
    if log.handlers:
        return
    log.setLevel(logging.INFO)
    try:
        os.makedirs(LOGS_DIR, exist_ok=True)
        h = RotatingFileHandler(os.path.join(LOGS_DIR, "game.log"), maxBytes=512 * 1024,
                                backupCount=1, encoding="utf-8")
        h.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        log.addHandler(h)
    except OSError:                      # carpeta de solo lectura: se sigue sin archivo de log
        log.addHandler(logging.NullHandler())


_setup_logging()
_reported = set()                        # cada recurso danado se registra una sola vez


def _report(path, why):
    if path not in _reported:
        _reported.add(path)
        log.warning("Recurso externo ignorado (%s): %s", why, path)


def slug(name):
    """'Señor del Abismo (JEFE)' -> 'senor_del_abismo_jefe' (nombre de archivo seguro)."""
    s = unicodedata.normalize("NFKD", name).encode("ascii", "ignore").decode("ascii").lower()
    return re.sub(r"[^a-z0-9]+", "_", s).strip("_")


def find_asset(subdir, names, exts):
    """Primer archivo existente assets/<subdir>/<nombre><ext>, o None."""
    base = os.path.join(ASSETS_DIR, subdir)
    if not os.path.isdir(base):
        return None
    for n in names:
        for e in exts:
            p = os.path.join(base, n + e)
            if os.path.isfile(p):
                return p
    return None


def load_png_grid(path, size):
    """Lee un PNG como grilla size x size de colores '#rrggbb'/None.

    Acepta cualquier tamano: se muestrea proporcionalmente (lo ideal es size o un multiplo exacto).
    Devuelve None (y registra el motivo) si el archivo esta danado o no es una imagen valida.
    """
    import tkinter as tk
    try:
        img = tk.PhotoImage(file=path)
        w, h = img.width(), img.height()
        if w < 1 or h < 1:
            raise ValueError("imagen vacia")
        grid = []
        for y in range(size):
            row = []
            sy = min(h - 1, int((y + 0.5) * h / size))
            for x in range(size):
                sx = min(w - 1, int((x + 0.5) * w / size))
                if img.transparency_get(sx, sy):
                    row.append(None)
                else:
                    r, g, b = img.get(sx, sy)
                    row.append("#%02x%02x%02x" % (r, g, b))
            grid.append(row)
        return grid
    except Exception as exc:             # archivo corrupto, formato no soportado, etc.
        _report(path, str(exc))
        return None


MUSIC_EXTS = (".mp3", ".wav", ".wma")
_bad_music = set()


def mark_bad(path, why):
    """Una pista que el reproductor no pudo abrir se ignora desde ahora (se usa la sintetizada)."""
    _bad_music.add(path)
    _report(path, why)


def music_files():
    base = os.path.join(ASSETS_DIR, "music")
    if not os.path.isdir(base):
        return []
    out = []
    for n in sorted(os.listdir(base)):
        p = os.path.join(base, n)
        if os.path.isfile(p) and n.lower().endswith(MUSIC_EXTS) and p not in _bad_music:
            out.append(p)
    return out


def _music_ok(p):
    try:
        if p.lower().endswith(".wav"):
            with wave.open(p, "rb") as w:
                if w.getnframes() <= 0:
                    raise ValueError("WAV vacio")
        elif os.path.getsize(p) < 256:
            raise ValueError("archivo demasiado pequeno")
        return True
    except Exception as exc:
        mark_bad(p, str(exc))
        return False


def find_music(biome_id):
    """Pista externa para un bioma, o None (entonces suena la musica sintetizada).

    1) assets/music/bioma_<id>.mp3|wav|wma   2) si no, cualquier audio de la carpeta: con una sola pista
    suena en todos los pisos; con varias se reparten por bioma en orden alfabetico.
    """
    from game import mods                      # cancion/carpeta elegida por el jugador en el menu [O]
    chosen = [f for f in mods.music_files() if f not in _bad_music and _music_ok(f)]
    if chosen:
        return chosen[(biome_id - 1) % len(chosen)]
    p = find_asset("music", ["bioma_%d" % biome_id], list(MUSIC_EXTS))
    if p and p not in _bad_music and _music_ok(p):
        return p
    files = [f for f in music_files() if _music_ok(f)]
    free = [f for f in files if not os.path.basename(f).lower().startswith("bioma_")] or files
    return free[(biome_id - 1) % len(free)] if free else None
