# V15 — habilidades, orientación y menú

- El personaje mira hacia la dirección horizontal de movimiento y usa el objetivo solo cuando está quieto.
- Se quitaron las instrucciones de teclas de la parte inferior del HUD y el bloque de controles del panel lateral.
- La tienda ahora ofrece únicamente pergaminos/pasivas, sin equipamiento comprable.
- Se agregaron pasivas de doble ataque básico, perforación, daño, reducción de recarga y experiencia.
- Los precios de pergaminos aumentaron y la cantidad de oro obtenida bajó.
- No se modificaron las colisiones ni el mapa de movimiento.
