# Cambios V12

- Se estabilizaron las poses de caminata: cabeza y torso quedan anclados mientras alternan los apoyos de las piernas, reduciendo el efecto visual de cuerpo partido.
- Se suavizó el ritmo del ciclo de caminata e idle para héroes y enemigos.
- La velocidad base del jugador aumentó un 32%; SHIFT mantiene el sprint adicional.
- Se quitó ESPACIO como entrada de dash y se eliminó el indicador de dash del HUD.
- Se añadió una barra de experiencia justo debajo de la vida, con nivel y XP numérica. La lógica de `gain_xp` ya descuenta el coste al subir de nivel, por lo que la barra vuelve a empezar con el excedente correspondiente.
- Se actualizó la portada con siluetas arquitectónicas de la Ciudadela y un tratamiento más luminoso del título.

## Pruebas

- `compileall`: correcto.
- Suite: 59 pruebas; 47 aprobadas, 10 omitidas y 2 fallidas únicamente al intentar abrir Tk sin servidor gráfico (`TclError: couldn't connect to display ":0"` y falta de raíz Tk). La ventana interactiva no pudo verificarse visualmente en este entorno.
