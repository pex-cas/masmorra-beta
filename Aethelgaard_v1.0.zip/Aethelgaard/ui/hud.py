# -*- coding: utf-8 -*-
"""HUD y pantallas de titulo / game over / victoria."""

import math
from audio.music import MUSIC
from player.player import CLASS_CONFIGS
from world.dungeon import TILE_CHEST, TILE_FLOOR, TILE_PILLAR, TILE_SECRET, TILE_STAIRS_DOWN, TILE_WALL


class HudMixin:
    # --- HUD
    def _render_hud(self, c):
        p, d = self.player, self.dungeon
        W, H = self.view_w, self.view_h

        def bar(x, y, w, h, val, mx, col, label=""):
            c.create_rectangle(x, y, x + w, y + h, fill="#10121a", outline="#000000")
            if mx > 0:
                c.create_rectangle(x + 1, y + 1, x + 1 + (w - 2) * max(0.0, min(1.0, val / mx)), y + h - 1, fill=col, outline="")
            if label:
                c.create_text(x + w / 2, y + h / 2, text=label, fill="#ffffff", font=self.font_small)
        bar(12, 12, 210, 16, p.hp, p.max_hp, "#d62839", f"VIDA {int(p.hp)}/{p.max_hp}")
        c.create_text(12, 35, text=f"LV.{p.level}  XP {p.xp}/{p.xp_to_next}", fill="#b8f7e4", font=self.font_small, anchor="w")
        bar(12, 43, 210, 8, p.xp, p.xp_to_next, "#06d6a0")
        c.create_rectangle(12, 43, 222, 51, outline="#315b56", width=1)
        c.create_text(W / 2, 14, text=f"PISO {self.floor} · {'JEFE · ' if self.boss_stage else ''}{d.biome['name']}", fill="#adb5bd", font=self.font_small)

        # habilidades X / C / Z
        cfg = CLASS_CONFIGS[p.char_class]
        for i, key in enumerate("XCZ"):
            bx, by, w, h = 14 + i * 96, H - 74, 90, 60
            ready = p.cd[i] <= 0
            c.create_rectangle(bx, by, bx + w, by + h, fill="#10121a", outline=cfg["color"] if ready else "#3a3d4d", width=2)
            c.create_text(bx + 14, by + 14, text=key, fill="#ffd166" if ready else "#6c757d", font=self.font_big)
            c.create_text(bx + w - 8, by + 12, text=("BASE", "FUERTE", "ULTI")[i], fill="#8d99ae", font=self.font_small, anchor="e")
            c.create_text(bx + w / 2, by + 38, text=cfg["kit"][i][0], fill="#e0e0e0", font=self.font_small, width=w - 6)
            if not ready:
                frac = min(1.0, p.cd[i] / max(0.01, p.cd_max[i]))
                c.create_rectangle(bx, by, bx + w, by + h * frac, fill="#000000", stipple="gray50", outline="")
                c.create_text(bx + w / 2, by + h / 2, text=f"{p.cd[i]:.1f}", fill="#ffffff", font=self.font_bold)

        # pociones y oro (iconos propios)
        ic = self.icons
        c.create_image(14, 64, image=ic.potion_s, anchor="nw")
        c.create_text(34, 72, text=f"x{p.hp_potions} [Q]", fill="#ff8fa3", font=self.font_small, anchor="w")
        c.create_image(88, 64, image=ic.coin_s, anchor="nw")
        c.create_text(108, 72, text=f"{p.gold}", fill="#ffd166", font=self.font_bold, anchor="w")


        # jefe: barra ornamentada con cuernos, marcas de fase (75/50/25 %) y aviso de furia
        for e in self.enemies:
            if e.ai == "boss" and not e.dead and math.hypot(e.x - p.x, e.y - p.y) < 650:
                bw, bx, by = 420, (W - 420) / 2, 44
                enr = e.hp <= e.max_hp * 0.5
                c.create_text(W / 2 + 1, 31, text=e.title, fill="#000000", font=self.font_bold)
                c.create_text(W / 2, 30, text=e.title, fill="#ff4d6d" if enr else "#e8c2d0", font=self.font_bold)
                c.create_rectangle(bx - 5, by - 5, bx + bw + 5, by + 21, fill="#14060c", outline="#7a1030", width=2)
                frac = max(0.0, min(1.0, e.hp / e.max_hp))
                c.create_rectangle(bx, by, bx + bw, by + 16, fill="#0b0408", outline="")
                c.create_rectangle(bx, by, bx + bw * frac, by + 16, fill="#a3123f" if not enr else "#d90429", outline="")
                c.create_rectangle(bx, by, bx + bw * frac, by + 5, fill="#e5385f", outline="")
                for mk in (0.25, 0.5, 0.75):
                    c.create_line(bx + bw * mk, by - 3, bx + bw * mk, by + 19, fill="#2a0a14", width=2)
                for sg, ex in ((-1, bx - 5), (1, bx + bw + 5)):      # cuernos en los extremos
                    c.create_polygon(ex, by - 6, ex + sg * 20, by - 22, ex + sg * 10, by + 2, fill="#d8c8a8", outline="#3a2a2a")
                if enr:
                    c.create_text(W / 2, by + 34, text="¡ENFURECIDO!", fill="#ff1744" if int(self.now * 4) % 2 else "#7a1030",
                                  font=self.font_small)
                break

        d.new_revealed.clear()
        self._mini_rect = None

        if p.hurt > 0:
            c.create_rectangle(3, 3, W - 3, H - 3, outline="#ff0000", width=8, stipple="gray50")

    # ==========================================================================
    # PANTALLAS: TITULO, GAME OVER, VICTORIA
    # ==========================================================================
    def render_title(self):
        """Portada: el elenco de la Ciudadela Abisal (heroes al frente, enemigos y jefe detras)."""
        c, t = self.canvas, 0.0                     # portada estatica: sin animaciones (solo el juego se anima)
        W, H = self.view_w, self.view_h
        c.delete("all"); self._tl = None
        c.create_rectangle(0, 0, W, H, fill="#080711", outline="")
        # Nuevo fondo: muro de la ciudadela, portal abisal y runas visibles.
        brick_h = 24
        for row in range(0, int(H * .76), brick_h):
            offset = 34 if (row // brick_h) % 2 else 0
            c.create_line(0, row, W, row, fill="#211b2b", width=1)
            for bx in range(-offset, W + 70, 68):
                c.create_line(bx, row, bx, row + brick_h, fill="#1b1725", width=1)
        for side in (-1, 1):
            ax = W / 2 + side * W * 0.34
            c.create_rectangle(ax - 18, H * 0.20, ax + 18, H * 0.76, fill="#151321", outline="#33243d", width=2)
            c.create_polygon(ax - 62, H * 0.24, ax, H * 0.08, ax + 62, H * 0.24, fill="#171321", outline="#493044", width=3)
            for yy in (0.34, 0.48, 0.62): c.create_line(ax - 15, H * yy, ax + 15, H * yy, fill="#2a2034", width=2)
        cx = W / 2
        pulse = 0.5 + 0.5 * math.sin(t * 1.4)
        portal_y = H * .47
        for r, col in ((330, "#0b0711"), (270, "#12091b"), (210, "#1b0b27"), (150, "#240d31")):
            r2 = r + pulse * 6
            c.create_oval(cx - r2, portal_y - r2, cx + r2, portal_y + r2, fill=col, outline="")
        for r, col, width in ((238, "#3a174d", 3), (220, "#63204f", 2), (178, "#38215e", 2)):
            rr = r + math.sin(t * 1.8) * 3
            c.create_oval(cx-rr, portal_y-rr, cx+rr, portal_y+rr, outline=col, width=width)
        # Marcas rúnicas orbitan el portal para dar profundidad y movimiento.
        for i in range(12):
            a = t * .18 + i * math.tau / 12
            rx, ry = cx + math.cos(a) * 244, portal_y + math.sin(a) * 205
            c.create_polygon(rx, ry-5, rx+3, ry, rx, ry+5, rx-3, ry,
                             fill="#a32d78" if i % 2 else "#3da6a6", outline="")
        for i in range(6):                                    # niebla que deriva
            y = H * (0.34 + 0.11 * i) + math.sin(t * 0.4 + i) * 7
            x = ((t * 12 * (1 + i % 2) + i * 197) % (W + 500)) - 250
            c.create_oval(x - 240, y - 16, x + 240, y + 16, fill="#2d0d19", stipple="gray12", outline="")
        c.create_rectangle(0, H * 0.74, W, H, fill="#0b070b", outline="")           # suelo de piedra
        c.create_rectangle(0, H * 0.74, W, H * 0.74 + 2, fill="#2a0e18", outline="")

        sp = self.sprites.stage
        def stand(name, x, ground, h, bob=0.0, sh=0.5):
            c.create_oval(x - h * sh, ground - 6, x + h * sh, ground + 8, fill="#000000", stipple="gray50", outline="")
            c.create_image(x, ground - h / 2 + 4 + bob, image=sp[name])
        stand("Minotauro Brutal", W * 0.12, H * 0.76, 160, math.sin(t * 1.1) * 2)
        stand("Zombi Pútrido", W * 0.29, H * 0.745, 128, math.sin(t * 1.3 + 1) * 2)
        stand("Mago de Fuego", W * 0.71, H * 0.745, 128, math.sin(t * 1.2 + 2) * 2)
        stand("Esqueleto", W * 0.88, H * 0.76, 128, math.sin(t * 1.0 + 3) * 2)
        stand("Señor del Abismo (JEFE)", cx, H * 0.73, 336, math.sin(t * 1.0) * 6, 0.32)
        ground = H * 0.88
        for i, name in enumerate(CLASS_CONFIGS):
            x = W * (0.2 + 0.3 * i)
            stand(name, x, ground, 192, math.sin(t * 2 + i) * 3, 0.42)
            col = CLASS_CONFIGS[name]["color"]
            c.create_text(x + 1, ground + 23, text=name.upper(), fill="#000000", font=self.font_big)
            c.create_text(x, ground + 22, text=name.upper(), fill=col, font=self.font_big)
        for i in range(22):                                   # brasas que suben
            x = (i * 97 + math.sin(t * 0.7 + i) * 18) % W
            y = H - ((t * (18 + i % 7 * 9) + i * 53) % H)
            s = 1 + i % 3
            c.create_rectangle(x, y, x + s, y + s, fill=("#ff3b3b", "#ff7b3b", "#8a1c2c")[i % 3], outline="")
        c.create_rectangle(0, 0, W, 34, fill="#000000", stipple="gray25", outline="")
        c.create_rectangle(0, H - 34, W, H, fill="#000000", stipple="gray25", outline="")
        for dx, dy in ((-2, 0), (2, 0), (0, -2), (0, 2), (2, 2)):                 # titulo con resplandor carmesí
            c.create_text(cx + dx, 112 + dy, text="AETHELGAARD", fill="#4a0a18", font=self.font_huge)
        c.create_text(cx, 58, text="CHRONICLES OF", fill="#c8b4d4", font=self.font_big)
        c.create_text(cx + 3, 105, text="AETHELGAARD", fill="#52172f", font=self.font_huge)
        c.create_text(cx, 101, text="AETHELGAARD", fill="#ffe0b5", font=self.font_huge)
        c.create_line(cx-180, 126, cx+180, 126, fill="#7c3159", width=2)
        c.create_text(cx, 145, text="THE ABYSSAL CITADEL", fill="#ed3476", font=self.font_big)
        c.create_text(cx, H - 18, text="Elegí tu héroe", fill="#a8989c", font=self.font_norm)

    def render_game_over(self):
        c, W, H = self.canvas, self.view_w, self.view_h
        c.delete("all"); self._tl = None
        c.create_rectangle(0, 0, W, H, fill="#0b090a")
        c.create_text(W / 2, H / 2 - 60, text="HAS SUCUMBIDO AL ABISMO", fill="#e63946", font=self.font_title)
        c.create_text(W / 2, H / 2, text=f"Llegaste al Piso {self.floor} con nivel {self.player.level}", fill="#f1faee", font=self.font_big)
        c.create_text(W / 2, H / 2 + 35, text=f"Oro acumulado: {self.player.gold}g", fill="#ffd166", font=self.font_norm)
        c.create_text(W / 2, H / 2 + 80, text="Click para volver a intentarlo", fill="#a8dadc", font=self.font_norm)

    def render_victory(self):
        c, W, H = self.canvas, self.view_w, self.view_h
        c.delete("all"); self._tl = None
        c.create_rectangle(0, 0, W, H, fill="#0d1b2a")
        c.create_text(W / 2, H / 2 - 60, text="¡VICTORIA ABSOLUTA!", fill="#ffd166", font=self.font_title)
        c.create_text(W / 2, H / 2, text="Derrotaste al Señor del Abismo y purificaste la Ciudadela", fill="#f1faee", font=self.font_big)
        c.create_text(W / 2, H / 2 + 40, text=f"Oro final: {self.player.gold}g | Nivel final: {self.player.level}", fill="#06d6a0", font=self.font_norm)
        c.create_text(W / 2, H / 2 + 85, text="Click para jugar otra partida con otra clase", fill="#a8dadc", font=self.font_norm)
