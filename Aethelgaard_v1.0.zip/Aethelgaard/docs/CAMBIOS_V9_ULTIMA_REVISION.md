# Aethelgaard — revisión final V9

- Los enemigos comunes solo dejan oro, con tope de 80 monedas por enemigo; no dejan pociones ni equipo.
- Los jefes pueden soltar oro y cinco piezas de equipo únicas: pantalones, botas, chaleco, casco y báculo. Las piezas no se repiten.
- El encuentro del piso 8 es un combate doble que entrega dos piezas distintas.
- El jefe final del piso 10 tiene mucha más vida, daño y velocidad.
- Los cofres aparecen únicamente en las habitaciones secretas. Al abrirlos entregan 100 de oro (75 %) o 300 (25 %) y una poción garantizada.
- Las pociones no se compran en la tienda ni caen de enemigos comunes; los cofres secretos son su fuente durante la partida.
- La tienda ofrece pergaminos de pasivas permanentes y equipo. Pasivas disponibles: energía reactiva, sangre vital, piel de piedra y segunda oportunidad.
- Equipo equipable limitado a cinco espacios: Pantalones, Botas, Chaleco, Casco y Báculo.
- Sprint ilimitado al mantener Shift; se quitaron las barras visuales de defensa/escudo y estamina.
- El daño de los enemigos comunes aumentó un 28 % antes del escalado por piso.
