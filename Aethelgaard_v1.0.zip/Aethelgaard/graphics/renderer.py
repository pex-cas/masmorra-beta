# -*- coding: utf-8 -*-
"""Render del mundo, entidades y efectos."""

import math
import random
from combat.entities import GoldPile
from graphics.sprites import SPRITE_SPECS
from graphics.utils import shade
from inventory.items import RARITY_COLORS
from world.dungeon import TILE_CHEST, TILE_FLOOR, TILE_PILLAR, TILE_SECRET, TILE_STAIRS_DOWN, TILE_WALL


class _DynCanvas:
    """Envuelve el Canvas: todo item creado a traves de el recibe la etiqueta 'dyn' (se borra cada fotograma)."""

    def __init__(self, c):
        self.c = c

    def __getattr__(self, name):
        f = getattr(self.c, name)
        if name.startswith("create_"):
            def wrapped(*a, **k):
                t = k.get("tags")
                k["tags"] = "dyn" if not t else ((t, "dyn") if isinstance(t, str) else tuple(t) + ("dyn",))
                return f(*a, **k)
            self.__dict__[name] = wrapped              # cache: la proxima vez no pasa por __getattr__
            return wrapped
        return f


class RenderMixin:
    # ==========================================================================
    # RENDER
    # ==========================================================================
    def render(self):
        c = self.canvas
        d, p, atl, now = self.dungeon, self.player, self.atlas, self.now
        ts = d.tile_size
        c.delete("dyn")                                  # solo se redibuja lo dinamico; los tiles persisten
        amp = self.shake * 40
        cam_x = math.floor(self.camera_x + (random.uniform(-amp, amp) if amp > 0 else 0))
        cam_y = math.floor(self.camera_y + (random.uniform(-amp, amp) if amp > 0 else 0))
        self.cx, self.cy = cam_x, cam_y
        self._update_tiles(c, d, atl, cam_x, cam_y, p.x / ts, p.y / ts, now)
        if getattr(self, "_dyn", None) is None or self._dyn.c is not c:
            self._dyn = _DynCanvas(c)
        c = self._dyn                                    # todo lo que se crea desde aqui lleva la etiqueta "dyn"

        # --- entidades ordenadas por profundidad (y)
        draws = []
        for e in self.enemies:
            etx, ety = int(e.x // ts), int(e.y // ts)
            if 0 <= etx < d.width and 0 <= ety < d.height and d.visible[etx][ety]:
                draws.append((e.y, 0, e))
        draws.append((p.y, 1, p))
        for it in self.dropped_items:
            draws.append((it[1], 2, it))
        draws.sort(key=lambda t: (t[0], t[1]))
        for _, kind, obj in draws:
            if kind == 0: self._draw_enemy(c, obj)
            elif kind == 1: self._draw_player(c, obj)
            else: self._draw_drop(c, obj)

        for ef in self.effects: self._draw_effect(c, ef)
        for pr in self.projectiles: self._draw_proj(c, pr)
        for pt in self.particles:
            sx, sy = pt.x - cam_x, pt.y - cam_y
            if sx < -8 or sy < -8 or sx > self.view_w + 8 or sy > self.view_h + 8:
                continue
            s = max(1.0, pt.size * pt.life / pt.max_life)
            c.create_rectangle(sx - s, sy - s, sx + s, sy + s, fill=pt.color, outline="")
        for ft in self.floating_texts:
            sx, sy = ft.x - cam_x, ft.y - cam_y
            c.create_text(sx + 1, sy + 1, text=ft.text, fill="#000000", font=self.font_bold)
            c.create_text(sx, sy, text=ft.text, fill=ft.color, font=self.font_bold)
        self._render_hud(c)

    def _update_tiles(self, c, d, atl, cam_x, cam_y, ptx, pty, now):
        """Capa de tiles persistente: los items se crean una vez, se desplazan con un unico c.move()
        y solo se recrean cuando cambia su imagen (iluminacion, antorchas). Las antorchas
        no generan halos circulares superpuestos: su luz se calcula en la matriz d.light."""
        ts = d.tile_size
        st = getattr(self, "_tl", None)
        if st is None or st["d"] is not d or st["atl"] is not atl:
            c.delete("tile")
            st = self._tl = {"d": d, "atl": atl, "items": {}, "cam": (cam_x, cam_y), "rng": None}
        items = st["items"]
        ox, oy = st["cam"]
        if (ox, oy) != (cam_x, cam_y):
            c.move("tile", ox - cam_x, oy - cam_y)
            st["cam"] = (cam_x, cam_y)
        M, K = 2, 5                                       # margen que se crea / margen que se conserva (en tiles)
        min_tx, max_tx = max(0, cam_x // ts - M), min(d.width, (cam_x + self.view_w) // ts + 1 + M)
        min_ty, max_ty = max(0, cam_y // ts - M), min(d.height, (cam_y + self.view_h) // ts + 1 + M)
        kx0, kx1 = cam_x // ts - K, (cam_x + self.view_w) // ts + 1 + K
        ky0, ky1 = cam_y // ts - K, (cam_y + self.view_h) // ts + 1 + K
        rng = (kx0, kx1, ky0, ky1)
        if rng != st["rng"]:                              # libera solo lo que quedo bien lejos (sin cargar/descargar en el borde)
            st["rng"] = rng
            for key in [k for k in items if not (kx0 <= k[0] < kx1 and ky0 <= k[1] < ky1)]:
                for iid in items.pop(key)[1]:
                    c.delete(iid)
        img, get, deco = c.create_image, atl.get, d.deco
        torch_frame = int(now * 6)
        for tx in range(min_tx, max_tx):
            rev, vis, lk, tl, lg = d.revealed[tx], d.visible[tx], d.look[tx], d.tiles[tx], d.light[tx]
            sx = tx * ts - cam_x
            for ty in range(min_ty, max_ty):
                if not rev[ty]:
                    continue
                t = tl[ty]
                kind, var = lk[ty]
                if vis[ty]:
                    dx, dy = tx + 0.5 - ptx, ty + 0.5 - pty
                    dist = max(abs(dx), abs(dy)) + 0.375 * min(abs(dx), abs(dy))
                    L = max(1.0 - dist / 9.5, lg[ty] * 0.95)
                    lvl = 0 if L > 0.62 else (1 if L > 0.34 else 2)
                    if t == TILE_STAIRS_DOWN:
                        kind, var = "stairs", 0
                    over = None
                    if t == TILE_CHEST: over = get("chest", 0, lvl)
                    elif t == TILE_PILLAR: over = get("pillar", 0, lvl)
                    elif t == TILE_FLOOR:
                        dk = deco.get((tx, ty))
                        if dk: over = get(dk, 0, lvl)
                    elif t == TILE_WALL:
                        if (tx, ty) in d.torch_set:
                            over = get("torch", (torch_frame + tx) % 2, 0)
                    elif t == TILE_SECRET:
                        over = get("crack_ov", 0, lvl)
                    sig = (get(kind, var, lvl), over)
                else:
                    if t == TILE_STAIRS_DOWN:
                        kind, var = "stairs", 0
                    sig = (get(kind, var, 3), None)
                key = (tx, ty)
                cur = items.get(key)
                if cur is not None:
                    if cur[0] == sig:
                        continue
                    for iid in cur[1]:
                        c.delete(iid)
                sy = ty * ts - cam_y
                ids = [img(sx, sy, image=sig[0], anchor="nw", tags="tile")]
                if sig[1] is not None:
                    ids.append(img(sx, sy, image=sig[1], anchor="nw", tags="tile"))
                items[key] = (sig, ids)

    # --- sprites
    def _actor(self, c, name, facing, frame, x, y, z):
        sx, sy = x - self.cx, y - self.cy
        c.create_oval(sx - 5 * z, sy + 6 * z, sx + 5 * z, sy + 8 * z, fill="#000000", stipple="gray50", outline="")
        c.create_image(sx, sy - z, image=self.sprites.get(name, facing, frame))
        return sx, sy

    def _draw_player(self, c, p):
        if p.invuln > 0 and p.ult_time <= 0 and int(self.now * 20) % 2 == 0:
            return
        # Pasos alternados con un ritmo menos brusco.
        fr = (1, 0, 3, 0)[int(p.anim * 6.2) % 4] if p.moving else (0 if int(self.now * 1.5) % 2 == 0 else 2)
        sx, sy = self._actor(c, p.char_class, p.facing, fr, p.x, p.y, 3)
        if p.guarding:                                    # escudo de energia alrededor del heroe
            r = 30 + 2 * math.sin(self.now * 10)
            c.create_oval(sx - r, sy - r - 4, sx + r, sy + r - 4, fill="#4a90c2", stipple="gray25", outline="#8ecae6", width=3)
            c.create_oval(sx - r + 8, sy - r + 4, sx + r - 8, sy + r - 12, outline="#d8f1ff", width=1)
        # Se elimina la flecha amarilla sobre el protagonista; el apuntado sigue funcionando.

    def _draw_enemy(self, c, e):
        z = SPRITE_SPECS[e.sprite].get("zoom", 4)
        fr = (1, 0, 3, 0)[int(e.anim * 5.8) % 4] if e.moved else (0 if int(self.now * 1.4 + e.x * 0.01) % 2 == 0 else 2)
        boss = e.ai == "boss"
        if boss:
            self._draw_boss_aura(c, e)
        visual_name = e.name if boss and e.name in self.sprites.imgs else e.sprite
        sx, sy = self._actor(c, visual_name, e.facing, fr, e.x, e.y - (4 + 3 * math.sin(self.now * 2.5) if boss else 0), z)
        if e.frozen_time > 0:
            c.create_rectangle(sx - 4 * z, sy - 9 * z, sx + 4 * z, sy + 7 * z, fill="#a8dadc", stipple="gray50", outline="#a8dadc")
        if e.windup > 0:
            c.create_text(sx, sy - 11 * z, text="!", fill="#ff0000", font=self.font_huge)
        bw, top = max(26, z * 10), sy - 9 * z - 8
        c.create_rectangle(sx - bw / 2, top, sx + bw / 2, top + 4, fill="#2b2d42", outline="#000000")
        c.create_rectangle(sx - bw / 2, top, sx - bw / 2 + bw * max(0.0, e.hp / e.max_hp), top + 4,
                           fill="#e63946", outline="")

    def _draw_boss_aura(self, c, e):
        """Aura abisal del jefe: halo que late, anillo runico y brasas que orbitan (mas intensos al enfurecer)."""
        sx, sy = e.x - self.cx, e.y - self.cy - 10
        enr = e.hp <= e.max_hp * 0.5
        now = self.now
        final_boss = "Abismo" in e.name or "Final" in e.name
        # Cada jefe tiene aura viva; el jefe final conserva el violeta/magenta caracteristico.
        outer = "#5810a8" if final_boss else ("#7a0a1e" if enr else "#4a0a2a")
        inner = "#8b22ff" if final_boss else ("#a00c24" if enr else "#6a0f36")
        rune = "#d56bff" if final_boss else ("#ff1744" if enr else "#b5179e")
        ember = "#f2b5ff" if final_boss else "#ff4d6d"
        r = 78 + 7 * math.sin(now * 2.2)
        c.create_oval(sx - r, sy - r * 0.8 + 10, sx + r, sy + r * 0.8 + 10, fill=outer,
                      stipple="gray12", outline="")
        c.create_oval(sx - r * 0.7, sy - r * 0.56 + 10, sx + r * 0.7, sy + r * 0.56 + 10, fill=inner,
                      stipple="gray25", outline="")
        c.create_oval(sx - 96, sy + 24, sx + 96, sy + 70, outline=rune, width=2)
        for k in range(5):
            a = now * 0.6 + k * 1.2566
            c.create_rectangle(sx + math.cos(a) * 96 - 2, sy + 47 + math.sin(a) * 23 - 2,
                               sx + math.cos(a) * 96 + 2, sy + 47 + math.sin(a) * 23 + 2, fill=ember, outline="")
        for k in range(10 if enr or final_boss else 7):
            a = now * 1.3 + k * 6.2832 / (10 if enr or final_boss else 7)
            rr = 74 + 10 * math.sin(now * 3 + k)
            ex, ey = sx + math.cos(a) * rr, sy + math.sin(a) * rr * 0.6 - 6
            c.create_rectangle(ex - 2, ey - 2, ex + 2, ey + 2, fill=ember if k % 2 else rune, outline="")

    def _draw_drop(self, c, it):
        ix, iy, obj = it
        sx, sy = ix - self.cx, iy - self.cy + math.sin(self.now * 3 + ix) * 3
        if isinstance(obj, GoldPile):
            lvl = 0 if obj.amount < 15 else (1 if obj.amount < 50 else 2)
            c.create_oval(sx - 11, sy + 8, sx + 11, sy + 15, fill="#000000", stipple="gray50", outline="")
            img = self.icons.piles[lvl] if lvl or obj.amount >= 8 else self.icons.coins[int(self.now * 8 + ix) % 4]
            c.create_image(sx, sy - 4, image=img)
            return
        if isinstance(obj, str):                          # pocion de vida: botella con brillo
            c.create_oval(sx - 11, sy + 6, sx + 11, sy + 14, fill="#000000", stipple="gray50", outline="")
            c.create_oval(sx - 18, sy - 22, sx + 18, sy + 14, fill="#ff4d6d", stipple="gray12", outline="")
            c.create_image(sx, sy - 4, image=self.icons.potion)
            return
        else:
            col, name, rare = RARITY_COLORS[obj.rarity], obj.name, obj.rarity in ("Raro", "Épico", "Legendario")
        if rare:
            c.create_line(sx, sy - 10, sx, sy - 40, fill=col, width=2)
        c.create_polygon(sx, sy - 9, sx + 7, sy, sx, sy + 9, sx - 7, sy, fill=col, outline="#ffffff")
        if name and math.hypot(ix - self.player.x, iy - self.player.y) < 120:
            c.create_text(sx, sy - 18, text=name, fill=col, font=self.font_small)

    def _draw_proj(self, c, pr):
        sx, sy = pr.x - self.cx, pr.y - self.cy
        a = math.atan2(pr.vy, pr.vx)
        ca, sa = math.cos(a), math.sin(a)

        def T(pts):
            out = []
            for u, v in pts:
                out += [sx + u * ca - v * sa, sy + u * sa + v * ca]
            return out
        t = pr.ptype
        if t == "dagger":
            c.create_polygon(T([(-12, 0), (-4, -3), (11, 0), (-4, 3)]), fill="#d8f3dc", outline="#52b788")
        elif t == "bolt":
            c.create_polygon(T([(-14, 0), (-2, -5), (11, 0), (-2, 5)]), fill="#4cc9f0", outline="#caf0f8")
            c.create_polygon(T([(-6, 0), (0, -2), (6, 0), (0, 2)]), fill="#ffffff", outline="")
        elif t == "fireball":
            c.create_polygon(T([(-16, 0), (-7, -8), (-2, -3), (4, -9), (7, -2), (13, 0), (7, 2), (4, 9), (-2, 3), (-7, 8)]),
                             fill="#fb8500", outline="#ffb703")
            c.create_polygon(T([(-7, 0), (-1, -4), (6, 0), (-1, 4)]), fill="#ffd23f", outline="")
        elif t == "arrow":
            c.create_line(T([(-12, 0), (8, 0)]), fill="#9ae6ff", width=2)
            c.create_polygon(T([(8, -3), (14, 0), (8, 3)]), fill="#ffffff", outline="")
        elif t == "orb":
            c.create_polygon(T([(-9, 0), (-3, -6), (2, -3), (8, 0), (2, 3), (-3, 6)]), fill="#ff7b00", outline="#ffd23f")
        else:
            c.create_polygon(T([(-9, 0), (0, -5), (10, 0), (0, 5)]), fill=pr.color, outline="#ffffff")

    def _draw_effect(self, c, ef):
        sx, sy = ef.x - self.cx, ef.y - self.cy
        t = 1.0 - ef.life / ef.max
        k = ef.kind
        if k == "arc":
            sweep, n, pts = min(1.0, t * 2.2), 10, []
            for i in range(n + 1):
                a = ef.ang - ef.dir * ef.span / 2 + ef.dir * ef.span * sweep * i / n
                pts += [sx + math.cos(a) * ef.r, sy + math.sin(a) * ef.r]
            c.create_line(pts, fill=ef.color, width=max(2, int(ef.width * (1 - t * 0.6))), capstyle="round", joinstyle="round")
            pts2 = [pts[i] * 1.0 for i in range(len(pts))]
            for i in range(0, len(pts2), 2):
                pts2[i] = sx + (pts[i] - sx) * 0.82
                pts2[i + 1] = sy + (pts[i + 1] - sy) * 0.82
            c.create_line(pts2, fill="#ffffff", width=2)
        elif k == "ring":
            r, pts = ef.r * (0.2 + 0.8 * min(1.0, t * 1.5)), []
            for i in range(21):
                a = i / 20 * 6.2832
                pts += [sx + math.cos(a) * r, sy + math.sin(a) * r]
            c.create_line(pts, fill=ef.color, width=max(1, int(5 * (1 - t))))
        elif k == "spin":
            rot = self.now * 16
            for i in range(3):
                a = rot + i * 2.0944
                ux, uy = math.cos(a), math.sin(a)
                vx, vy = -uy, ux
                c.create_polygon(sx + ux * 30, sy + uy * 30, sx + ux * 70 + vx * 10, sy + uy * 70 + vy * 10,
                                 sx + ux * 122, sy + uy * 122, sx + ux * 70 - vx * 10, sy + uy * 70 - vy * 10,
                                 fill="#dfe6ee", outline="#ffb703", width=2)
            pts = []
            for i in range(25):
                a = i / 24 * 6.2832
                pts += [sx + math.cos(a) * 105, sy + math.sin(a) * 105]
            c.create_line(pts, fill="#ffb703", width=2, dash=(6, 6))
        elif k == "meteor":
            r, pts = ef.r * (0.35 + 0.65 * t), []
            for i in range(19):
                a = i / 18 * 6.2832
                pts += [sx + math.cos(a) * r, sy + math.sin(a) * r * 0.7]
            c.create_line(pts, fill="#ff4d00", width=2)
            c.create_line(sx - 8, sy, sx + 8, sy, fill="#ff4d00")
            fy = sy - ef.life * 520
            c.create_line(sx, fy - 10, sx, fy - 80, fill="#ff8c1a", width=8, capstyle="round")
            c.create_polygon(sx, fy - 20, sx + 7, fy - 8, sx + 18, fy - 10, sx + 10, fy, sx + 18, fy + 10, sx + 7, fy + 8,
                             sx, fy + 22, sx - 7, fy + 8, sx - 18, fy + 10, sx - 10, fy, sx - 18, fy - 10, sx - 7, fy - 8,
                             fill="#fb8500", outline="#ffd23f")
        elif k == "line":
            w = max(1, int(7 * ef.life / ef.max))
            c.create_line(sx, sy, ef.x2 - self.cx, ef.y2 - self.cy, fill=ef.color, width=w + 2)
            c.create_line(sx, sy, ef.x2 - self.cx, ef.y2 - self.cy, fill="#ffffff", width=1)
