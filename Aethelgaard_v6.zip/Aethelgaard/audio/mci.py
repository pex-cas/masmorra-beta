# -*- coding: utf-8 -*-
"""Reproduccion de MP3/WMA (y WAV) con MCI de Windows (winmm), sin dependencias externas.

winsound solo sabe reproducir WAV; MCI permite MP3. Todas las llamadas se hacen desde el hilo
principal de Tk. En sistemas que no son Windows `available` es False y no se hace nada.
"""
import os

from game.assets import log


def _default_send():
    if os.name != "nt":
        return None
    try:
        import ctypes
        winmm = ctypes.windll.winmm

        def send(cmd):
            buf = ctypes.create_unicode_buffer(256)
            code = winmm.mciSendStringW(cmd, buf, 255, 0)
            return code, buf.value
        return send
    except Exception as exc:               # entorno raro: se sigue sin MP3
        log.warning("MCI no disponible: %s", exc)
        return None


class MciPlayer:
    ALIAS = "aeth_bgm"

    def __init__(self, send=None):
        self._send = send if send is not None else _default_send()
        self.playing = False

    @property
    def available(self):
        return self._send is not None

    def _cmd(self, cmd):
        try:
            return self._send(cmd)
        except Exception as exc:
            return -1, str(exc)

    def play(self, path, loop=True):
        """Abre y reproduce `path`. Devuelve True si MCI lo acepto."""
        if not self.available:
            return False
        self.stop()
        kind = " type mpegvideo" if path.lower().endswith(".mp3") else ""
        code, _ = self._cmd('open "%s"%s alias %s' % (path, kind, self.ALIAS))
        if code:
            log.warning("MCI no pudo abrir %s (codigo %s)", path, code)
            return False
        code, _ = self._cmd("play %s%s" % (self.ALIAS, " repeat" if loop else ""))
        if code and loop:                  # algunos codecs no aceptan repeat: se reinicia desde tick()
            code, _ = self._cmd("play %s" % self.ALIAS)
        if code:
            log.warning("MCI no pudo reproducir %s (codigo %s)", path, code)
            self._cmd("close %s" % self.ALIAS)
            return False
        self.playing = True
        return True

    def stop(self):
        if self.playing and self.available:
            self._cmd("stop %s" % self.ALIAS)
            self._cmd("close %s" % self.ALIAS)
        self.playing = False

    def is_stopped(self):
        """True si la pista termino (para reiniciarla cuando no hubo repeat)."""
        if not (self.playing and self.available):
            return False
        code, text = self._cmd("status %s mode" % self.ALIAS)
        return code == 0 and text.strip().lower() == "stopped"

    def restart(self):
        if self.playing and self.available:
            self._cmd("seek %s to start" % self.ALIAS)
            self._cmd("play %s" % self.ALIAS)
