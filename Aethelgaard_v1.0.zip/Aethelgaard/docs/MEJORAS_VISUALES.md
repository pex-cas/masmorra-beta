# Mejoras visuales de Aethelgaard v8

- Se conservaron los diseños, las paletas y la identidad de los personajes originales; se aumentó la resolución de dibujo de los sprites de 16x16 a 24x24 para permitir detalles de píxel más finos sin cambiar sustancialmente su tamaño en pantalla.
- El Guerrero tiene costuras, reflejos y detalles adicionales en la armadura.
- El Mago tiene un sombrero más reconocible, ribetes de túnica, broche arcano y barba con mechones.
- La clase antes llamada Pícaro ahora se llama Bandido en el juego y en los textos de ayuda.
- El Zombi Pútrido tiene brazos desiguales, ropa rota, manchas de putrefacción, boca y ojos asimétricos.
- El Señor del Abismo tiene filigranas de armadura y runas adicionales, conservando la silueta y la paleta originales.
- Se quitó la flecha amarilla de orientación que aparecía junto al protagonista. El cálculo de apuntado y el autoapuntado siguen funcionando.

## Pruebas

La compilación de Python funciona. Las pruebas automatizadas pasan salvo dos pruebas que intentan abrir una ventana o crear imágenes Tkinter y no pueden ejecutarse en un entorno sin pantalla gráfica.
