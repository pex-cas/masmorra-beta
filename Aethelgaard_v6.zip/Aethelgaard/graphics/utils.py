# -*- coding: utf-8 -*-
"""Utilidades graficas: sombreado de colores, rectangulos en grilla, PhotoImage."""
from functools import lru_cache


@lru_cache(maxsize=20000)
def _shade(h, f):
    r, g, b = int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16)
    return "#%02x%02x%02x" % (max(0, min(255, int(r * f))),
                              max(0, min(255, int(g * f))),
                              max(0, min(255, int(b * f))))

def shade(h, f):
    return _shade(h, round(f, 2))


def _rect(g, x, y, w, h, c):
    """Rellena un rectangulo en una grilla cuadrada de colores."""
    if not c:
        return
    n = len(g)
    for j in range(max(0, y), min(n, y + h)):
        row = g[j]
        for i in range(max(0, x), min(n, x + w)):
            row[i] = c


def to_photo(grid, n, zoom):
    """Convierte una grilla n x n de colores (None = transparente) en PhotoImage."""
    import tkinter as tk                 # import tardio: el resto del modulo funciona sin Tk
    img = tk.PhotoImage(width=n, height=n)
    if all(c for row in grid for c in row):
        img.put(" ".join("{" + " ".join(row) + "}" for row in grid))
    else:
        for y, row in enumerate(grid):
            x = 0
            while x < n:
                c = row[x]
                if c:
                    x2 = x
                    while x2 + 1 < n and row[x2 + 1] == c:
                        x2 += 1
                    img.put(c, to=(x, y, x2 + 1, y + 1))
                    x = x2 + 1
                else:
                    x += 1
    return img.zoom(zoom, zoom) if zoom > 1 else img
