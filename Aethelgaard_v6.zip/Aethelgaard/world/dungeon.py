# -*- coding: utf-8 -*-
"""Generador procedural de mazmorras."""
import copy
import math
import random

BOSS_FLOOR_EVERY = 5           # cada 5 pisos hay sala de jefe
BOSS_ROOM_SIZE = 13            # la sala del jefe es un cuadrado de 13x13 casillas
SECRET_ROOMS_PER_FLOOR = 3     # habitaciones secretas por piso (si la geometria lo permite)
MAX_GEN_ATTEMPTS = 40          # intentos de regeneracion antes de aceptar el mejor mapa valido


# ==============================================================================
TILE_VOID, TILE_FLOOR, TILE_WALL = 0, 1, 2
TILE_STAIRS_DOWN, TILE_SHRINE, TILE_CHEST, TILE_PILLAR = 4, 5, 6, 7
TILE_SECRET = 8   # pared secreta: parece pared, se rompe al atacarla

# Paletas ambientales (suelo/muro apagados, estilo mazmorra oscura). "accent" y "rim"
# se conservan: alimentan los efectos luminosos, que no se tocan.
BIOME_THEMES = {
    1: {"name": "Criptas Azules", "floor": "#2a4a6e", "floor2": "#243f5e", "wall": "#33598a",
        "top": "#0b1428", "mortar": "#122a40", "accent": "#3aa8ff", "rim": "#5cbcff"},
    2: {"name": "Cavernas de Magma", "floor": "#523027", "floor2": "#472a22", "wall": "#8a4030",
        "top": "#190a08", "mortar": "#200e0c", "accent": "#ff6a1f", "rim": "#ff9150"},
    3: {"name": "Ruinas Toxicas", "floor": "#27492f", "floor2": "#213e29", "wall": "#3d7a4a",
        "top": "#06110a", "mortar": "#0e2315", "accent": "#4dff88", "rim": "#7dffa8"},
    4: {"name": "Santuario Abisal", "floor": "#3a2d62", "floor2": "#31265a", "wall": "#62449e",
        "top": "#0b0716", "mortar": "#160f2c", "accent": "#c04dff", "rim": "#dc9bff"},
}


# Ciclo de color por piso: 1 azul, 2 verde, 3 rojo, 4 violeta, 5 azul, ... (cada 4 pisos).
PALETTE_CYCLE = (1, 3, 2, 4)      # ids de BIOME_THEMES: azul, verde, rojo, violeta


def palette_for_floor(floor_level):
    return PALETTE_CYCLE[(floor_level - 1) % len(PALETTE_CYCLE)]


class Room:
    def __init__(self, x, y, w, h, shape):
        self.x, self.y, self.w, self.h, self.shape = x, y, w, h, shape
        self.cx, self.cy = x + w // 2, y + h // 2
        self.cells = [(i, j) for i in range(x, x + w) for j in range(y, y + h) if self._inside(i, j)]

    def _inside(self, i, j):
        dx = (i + 0.5 - (self.x + self.w / 2)) / (self.w / 2)
        dy = (j + 0.5 - (self.y + self.h / 2)) / (self.h / 2)
        if self.shape == "round":
            return dx * dx + dy * dy <= 1.0
        if self.shape == "cross":
            return abs(dx) < 0.4 or abs(dy) < 0.4
        if self.shape == "chamfer":
            return abs(dx) + abs(dy) <= 1.55
        return True


class DungeonMap:
    def __init__(self, floor_level=1, width=60, height=60, tile_size=48):
        self.floor_level = floor_level
        self.width, self.height, self.tile_size = width, height, tile_size
        self.tiles = [[TILE_WALL] * height for _ in range(width)]
        self.revealed = [[False] * height for _ in range(width)]
        self.visible = [[False] * height for _ in range(width)]
        self.var = [[random.randint(0, 3) for _ in range(height)] for _ in range(width)]
        self.light = [[0.0] * height for _ in range(width)]
        self.look = None
        self.vis_list, self.new_revealed = [], []
        self._last_ptile = None
        self.rooms, self.torches, self.deco = [], [], {}
        self.secrets, self.rune = {}, None
        self.torch_set = set()
        self.boss_floor = floor_level % BOSS_FLOOR_EVERY == 0
        self.boss_door = []            # casillas de la unica entrada de la sala del jefe
        self.boss_sealed = False       # True mientras la entrada esta cerrada (pelea en curso)
        self.spawn_pos = self.stairs_pos = (0, 0)
        self.biome_id = min(4, (floor_level - 1) // 3 + 1)      # sigue gobernando la musica
        self.palette_id = palette_for_floor(floor_level)        # paleta ambiental (ciclo de 4)
        self.biome = BIOME_THEMES[self.palette_id]
        self.attempts = 0
        self.problems = []
        self._generate_validated()
        self._bake()

    # ---------------------------------------------------------------- generacion
    _LAYOUT_ATTRS = ("tiles", "rooms", "torches", "torch_set", "deco", "secrets", "rune", "light",
                     "spawn_pos", "stairs_pos", "boss_door")

    def _reset_layout(self):
        W, H = self.width, self.height
        self.tiles = [[TILE_WALL] * H for _ in range(W)]
        self.light = [[0.0] * H for _ in range(W)]
        self.rooms, self.torches, self.deco = [], [], {}
        self.secrets, self.rune = {}, None
        self.torch_set = set()
        self.boss_door = []

    @property
    def boss_room(self):
        """Sala cuadrada del jefe (siempre la ultima de `rooms`), o None si el piso no tiene jefe."""
        return self.rooms[-1] if (self.boss_floor and self.rooms) else None

    def _generate_validated(self):
        """Genera el mapa logico completo y lo valida. Si falla, regenera (maximo MAX_GEN_ATTEMPTS)."""
        best = None
        for attempt in range(1, MAX_GEN_ATTEMPTS + 1):
            self.attempts = attempt
            self._reset_layout()
            self._generate()
            problems = self.validate()
            n_sec = len(self.secrets)
            if not problems and n_sec >= SECRET_ROOMS_PER_FLOOR:
                self.problems = []
                return
            if not problems and (best is None or n_sec > best[0]):
                best = (n_sec, {a: copy.deepcopy(getattr(self, a)) for a in self._LAYOUT_ATTRS})
        if best is not None:       # mejor mapa valido (menos habitaciones secretas de las pedidas)
            for a, v in best[1].items():
                setattr(self, a, v)
            self.problems = []
        else:                      # ultimo recurso: se conserva el ultimo intento y se informa
            self.problems = self.validate()

    def validate(self):
        """Devuelve la lista de problemas del mapa logico (vacia = mapa valido)."""
        W, H, T = self.width, self.height, self.tiles
        out = []
        if len(self.rooms) < 6:
            out.append("pocas habitaciones")
        # bordes: nunca transitables (evita accesos fuera del mapa)
        for x in range(W):
            if self.is_walkable(x, 0) or self.is_walkable(x, H - 1):
                out.append("borde abierto")
                break
        for y in range(H):
            if self.is_walkable(0, y) or self.is_walkable(W - 1, y):
                out.append("borde abierto")
                break
        sx, sy = self.spawn_pos
        if not self.is_walkable(sx, sy):
            out.append("spawn no transitable")
            return out
        if T[self.stairs_pos[0]][self.stairs_pos[1]] != TILE_STAIRS_DOWN:
            out.append("sin escaleras")
        reach = self._reachable(self.spawn_pos)
        if self.stairs_pos not in reach:
            out.append("escaleras inaccesibles")
        chamber = set()
        for info in self.secrets.values():
            chamber.update(info["cells"])
        walk = {(x, y) for x in range(W) for y in range(H) if self.is_walkable(x, y)}
        if walk - reach - chamber:
            out.append("zonas transitables aisladas")
        if reach & chamber:
            out.append("camara secreta abierta sin romper la pared")
        open_reach = self._reachable(self.spawn_pos, through_secrets=True)
        for (px, py), info in self.secrets.items():
            if T[px][py] != TILE_SECRET:
                out.append("pared secreta inconsistente")
                continue
            if not set(info["cells"]) <= open_reach:
                out.append("camara secreta inaccesible")
            if sum(1 for n in ((px + 1, py), (px - 1, py), (px, py + 1), (px, py - 1)) if (n in reach)) < 1:
                out.append("pared secreta sin acceso")
        br = self.boss_room
        if br is not None:
            if br.w != br.h:
                out.append("sala del jefe no cuadrada")
            ring = self._room_ring_floor(br)
            if not ring or len(ring) > 3 or ring != self.boss_door:
                out.append("sala del jefe sin una unica entrada")
            elif len({c[0] for c in ring}) > 1 and len({c[1] for c in ring}) > 1:
                out.append("entrada del jefe irregular")
        for r in self.rooms:
            if r.shape != "rect":
                out.append("sala no rectangular")
                break
        for x in range(W):
            for y in range(H):
                if T[x][y] not in (TILE_FLOOR, TILE_WALL, TILE_STAIRS_DOWN, TILE_SHRINE, TILE_CHEST,
                                   TILE_PILLAR, TILE_SECRET):
                    out.append("tile invalido")
                    return out
        return out

    def _room_ring_floor(self, r):
        """Casillas transitables pegadas por fuera al borde de la sala `r` (sus entradas)."""
        out = []
        for i in range(r.x, r.x + r.w):
            for j in (r.y - 1, r.y + r.h):
                if self.is_walkable(i, j):
                    out.append((i, j))
        for j in range(r.y, r.y + r.h):
            for i in (r.x - 1, r.x + r.w):
                if self.is_walkable(i, j):
                    out.append((i, j))
        return sorted(out)

    def _generate(self):
        W, H, T = self.width, self.height, self.tiles

        def free(x, y, w, h, rooms):
            return not any(x < r.x + r.w + 3 and x + w + 3 > r.x and y < r.y + r.h + 3 and y + h + 3 > r.y
                           for r in rooms)

        while True:
            rooms, boss = [], None
            target = random.randint(9, 13)
            # primera sala (spawn): rectangulo
            for _ in range(300):
                w, h = random.randint(7, 14), random.randint(7, 12)
                x, y = random.randint(2, W - w - 3), random.randint(2, H - h - 3)
                rooms.append(Room(x, y, w, h, "rect"))
                break
            if self.boss_floor:             # sala del jefe: cuadrado perfecto y lejos del spawn
                n = BOSS_ROOM_SIZE
                for _ in range(300):
                    x, y = random.randint(2, W - n - 3), random.randint(2, H - n - 3)
                    if free(x, y, n, n, rooms) and abs(x + n // 2 - rooms[0].cx) + abs(y + n // 2 - rooms[0].cy) >= 30:
                        boss = Room(x, y, n, n, "rect")
                        break
                if boss is None:
                    continue
                target -= 1
            allr = rooms + ([boss] if boss else [])
            for _ in range(300):
                if len(rooms) >= target:
                    break
                w, h = random.randint(7, 14), random.randint(7, 12)
                x, y = random.randint(2, W - w - 3), random.randint(2, H - h - 3)
                if not free(x, y, w, h, allr):
                    continue
                r = Room(x, y, w, h, "rect")       # solo rectangulos
                rooms.append(r)
                allr.append(r)
            if len(rooms) >= 6 - (1 if boss else 0):
                break

        for r in rooms + ([boss] if boss else []):
            for (i, j) in r.cells:
                T[i][j] = TILE_FLOOR

        # Conexion tipo Prim (siempre conectado) + algunos bucles extra. La sala del jefe NO participa:
        # se une al final con un solo pasillo, asi tiene una unica entrada.
        connected, rest = [rooms[0]], rooms[1:]
        while rest:
            best = None
            for a in connected:
                for b in rest:
                    d = (a.cx - b.cx) ** 2 + (a.cy - b.cy) ** 2
                    if best is None or d < best[0]:
                        best = (d, a, b)
            _, a, b = best
            self._corridor(a, b)
            connected.append(b)
            rest.remove(b)
        for _ in range(3):
            a, b = random.sample(rooms, 2)
            if (a.cx - b.cx) ** 2 + (a.cy - b.cy) ** 2 < 900:
                self._corridor(a, b)
        if boss:
            near = min(rooms, key=lambda r: (r.cx - boss.cx) ** 2 + (r.cy - boss.cy) ** 2)
            self._corridor(near, boss, last_room=boss)
            rooms.append(boss)

        # Sin erosion organica ni limpieza de paredes: salas y pasillos quedan como rectangulos perfectos.

        # Spawn en la primera sala, escaleras en la sala mas lejana
        first = rooms[0]
        far = boss or max(rooms[1:], key=lambda r: (r.cx - first.cx) ** 2 + (r.cy - first.cy) ** 2)
        if far is not boss:
            rooms.remove(far)
            rooms.append(far)
        self.rooms = rooms
        self.spawn_pos = (first.cx, first.cy)
        self.stairs_pos = (far.cx, far.cy)
        T[far.cx][far.cy] = TILE_STAIRS_DOWN

        # Pilares en salas grandes
        pillars = []
        for r in rooms[1:]:
            if r is boss:
                continue
            if r.shape == "rect" and r.w >= 10 and r.h >= 9:
                for (px, py) in ((r.x + 2, r.y + 2), (r.x + r.w - 3, r.y + 2),
                                 (r.x + 2, r.y + r.h - 3), (r.x + r.w - 3, r.y + r.h - 3)):
                    if T[px][py] == TILE_FLOOR:
                        T[px][py] = TILE_PILLAR
                        pillars.append((px, py))
        walkable = sum(1 for x in range(W) for y in range(H) if self.is_walkable(x, y))
        if len(self._reachable(self.spawn_pos)) < walkable:     # un pilar aislaria una zona: se quitan
            for (px, py) in pillars:
                T[px][py] = TILE_FLOOR

        # Cofres y santuarios
        for r in rooms[1:-1]:
            dice = random.random()
            free = [c for c in r.cells if T[c[0]][c[1]] == TILE_FLOOR]
            if not free:
                continue
            cx, cy = random.choice(free)
            if dice < 0.45:
                T[cx][cy] = TILE_CHEST
            elif dice < 0.70:
                T[cx][cy] = TILE_SHRINE
                if self.rune is None:
                    self.rune = (cx, cy)

        # Habitaciones secretas: tras una pared que se rompe atacandola (exactamente 3 si cabe)
        self._place_secret_chambers([r for r in rooms if r is not boss], SECRET_ROOMS_PER_FLOOR)
        if boss:
            self.boss_door = self._room_ring_floor(boss)

        # Antorchas en paredes frontales + mapa de luz
        for x in range(1, W - 1):
            for y in range(1, H - 2):
                if T[x][y] == TILE_WALL and T[x][y + 1] == TILE_FLOOR and random.random() < 0.10:
                    if all(abs(x - tx) + abs(y - ty) > 5 for tx, ty in self.torches):
                        self.torches.append((x, y))
        self.torch_set = set(self.torches)
        for (tx, ty) in self.torches:
            for x in range(tx - 6, tx + 7):
                for y in range(ty - 6, ty + 7):
                    if 0 <= x < W and 0 <= y < H:
                        v = max(0.0, 1.0 - math.hypot(x - tx, y - (ty + 1)) / 6.0)
                        if v > self.light[x][y]:
                            self.light[x][y] = v

        # Decoracion del suelo (barriles, cajas, telaranas...). Sin puertas ni arcos de pared.
        for r in rooms:
            for (i, j) in r.cells:
                if T[i][j] != TILE_FLOOR or (i, j) == self.spawn_pos:
                    continue
                wall_n = T[i][j - 1] == TILE_WALL
                roll = random.random()
                if wall_n and T[i - 1][j] == TILE_WALL and roll < 0.55:
                    self.deco[(i, j)] = "web_l"
                elif wall_n and T[i + 1][j] == TILE_WALL and roll < 0.55:
                    self.deco[(i, j)] = "web_r"
                elif wall_n and roll < 0.07:
                    self.deco[(i, j)] = random.choice(("barrel", "crate", "chains", "barrel"))
                elif roll < 0.05:
                    self.deco[(i, j)] = random.choice(("bones", "moss", "crack", "crack"))

    def _place_secret_chambers(self, rooms, target):
        T = self.tiles
        cells = [c for r in rooms for c in r.cells]
        random.shuffle(cells)
        dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)]
        made = 0
        for (i, j) in cells:
            if made >= target:
                break
            if T[i][j] != TILE_FLOOR or (i, j) == self.spawn_pos:
                continue
            random.shuffle(dirs)
            dv = next((d for d in dirs if self._can_chamber(i, j, d[0], d[1])), None)
            if dv:
                self._make_chamber(i, j, dv[0], dv[1])
                made += 1
        return made

    def _can_chamber(self, i, j, dx, dy):
        W, H, T = self.width, self.height, self.tiles
        px, py = dy, dx
        for k in range(1, 6):
            for l in range(-2, 3):
                x, y = i + dx * k + px * l, j + dy * k + py * l
                if not (2 <= x <= W - 3 and 2 <= y <= H - 3) or T[x][y] != TILE_WALL:
                    return False
        return True

    def _make_chamber(self, i, j, dx, dy):
        T = self.tiles
        px, py = dy, dx
        cells = []
        for k in range(2, 5):
            for l in range(-1, 2):
                T[i + dx * k + px * l][j + dy * k + py * l] = TILE_FLOOR
                cells.append((i + dx * k + px * l, j + dy * k + py * l))
        cx, cy = i + dx * 3, j + dy * 3
        T[cx][cy] = TILE_CHEST
        sx, sy = i + dx, j + dy
        T[sx][sy] = TILE_SECRET
        self.secrets[(sx, sy)] = {"hp": 4, "center": (cx, cy), "hit": False, "cells": cells}

    def _nfloor(self, x, y):
        T = self.tiles
        return sum(1 for nx, ny in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)) if T[nx][ny] != TILE_WALL)

    def _corridor(self, a, b, last_room=None):
        wd = random.choice((2, 2, 3))
        if last_room is not None:           # entra por un lado perpendicular a la pared de la sala
            horiz_last = abs(a.cx - b.cx) >= abs(a.cy - b.cy)
            if horiz_last:
                self._carve_v(a.cy, b.cy, a.cx, wd)
                self._carve_h(a.cx, b.cx, b.cy, wd)
            else:
                self._carve_h(a.cx, b.cx, a.cy, wd)
                self._carve_v(a.cy, b.cy, b.cx, wd)
            return
        if random.random() < 0.5:
            self._carve_h(a.cx, b.cx, a.cy, wd)
            self._carve_v(a.cy, b.cy, b.cx, wd)
        else:
            self._carve_v(a.cy, b.cy, a.cx, wd)
            self._carve_h(a.cx, b.cx, b.cy, wd)

    def _carve_h(self, x1, x2, y, wd):
        for x in range(min(x1, x2), max(x1, x2) + 1):
            for k in range(-(wd // 2), wd - (wd // 2)):
                yy = y + k
                if 1 <= x < self.width - 1 and 1 <= yy < self.height - 1:
                    self.tiles[x][yy] = TILE_FLOOR

    def _carve_v(self, y1, y2, x, wd):
        for y in range(min(y1, y2), max(y1, y2) + 1):
            for k in range(-(wd // 2), wd - (wd // 2)):
                xx = x + k
                if 1 <= xx < self.width - 1 and 1 <= y < self.height - 1:
                    self.tiles[xx][y] = TILE_FLOOR

    def _reachable(self, start, through_secrets=False):
        seen, stack = {start}, [start]
        while stack:
            x, y = stack.pop()
            for n in ((x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)):
                if n not in seen and (self.is_walkable(n[0], n[1])
                                      or (through_secrets and n in self.secrets)):
                    seen.add(n)
                    stack.append(n)
        return seen

    def _bake(self):
        self.look = [[None] * self.height for _ in range(self.width)]
        for x in range(self.width):
            for y in range(self.height):
                self._bake_tile(x, y)

    def _solid(self, x, y):
        if not (0 <= x < self.width and 0 <= y < self.height):
            return True
        return self.tiles[x][y] in (TILE_WALL, TILE_SECRET)

    def _bake_tile(self, x, y):
        """Elige el aspecto de cada tile: vacio, cara de pared, tope con borde o piso."""
        v = self.var[x][y]
        S = self._solid
        if self.tiles[x][y] in (TILE_WALL, TILE_SECRET):
            near = any(not S(x + dx, y + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1))
            if not near:
                self.look[x][y] = ("void", 0)
            elif not S(x, y + 1):
                m = (0 if S(x - 1, y) else 1) + (0 if S(x + 1, y) else 2)
                self.look[x][y] = ("wall_face", m + 4 * (v % 2))
            else:
                m = (0 if S(x, y - 1) else 1) + (0 if S(x + 1, y) else 2) + (0 if S(x - 1, y) else 4)
                self.look[x][y] = ("wall_cap", m)
        else:
            sh = y > 0 and S(x, y - 1)
            self.look[x][y] = ("floor_sh", v % 2) if sh else ("floor", v)

    def rebake_around(self, x, y):
        for xx in range(x - 2, x + 3):
            for yy in range(y - 2, y + 3):
                if 0 <= xx < self.width and 0 <= yy < self.height:
                    self._bake_tile(xx, yy)

    # ---------------------------------------------------------------- consultas
    def is_walkable(self, tx, ty):
        if 0 <= tx < self.width and 0 <= ty < self.height:
            t = self.tiles[tx][ty]
            return t not in (TILE_WALL, TILE_PILLAR, TILE_SECRET)
        return False

    def can_move(self, x, y, r):
        ts = self.tile_size
        for ox, oy in ((-r, -r), (r, -r), (-r, r), (r, r)):
            if not self.is_walkable(int((x + ox) // ts), int((y + oy) // ts)):
                return False
        return True

    def complete_wall_shell(self):
        """Marca como exploradas las paredes que rodean a los pisos ya explorados.

        Causa del bug "bloques transparentes que luego se vuelven solidos": compute_fov solo
        revela las paredes que un rayo toca, asi que quedaban huecos sin revelar (se veia el
        fondo) hasta acercarse. Esto completa el contorno sin alterar visible/luz/FOV.
        """
        nr = self.new_revealed
        if not nr:
            return
        W, H, rev, T = self.width, self.height, self.revealed, self.tiles
        for (x, y) in list(nr):
            if T[x][y] in (TILE_WALL, TILE_SECRET):
                continue
            for xx in range(x - 1, x + 2):
                for yy in range(y - 1, y + 2):
                    if 0 <= xx < W and 0 <= yy < H and not rev[xx][yy] and T[xx][yy] in (TILE_WALL, TILE_SECRET):
                        rev[xx][yy] = True
                        nr.append((xx, yy))

    def compute_fov(self, px, py, radius=9):
        ptx, pty = int(px // self.tile_size), int(py // self.tile_size)
        if (ptx, pty) == self._last_ptile:
            return
        self._last_ptile = (ptx, pty)
        for (x, y) in self.vis_list:
            self.visible[x][y] = False
        self.vis_list = []
        W, H = self.width, self.height
        rays = 120
        for i in range(rays):
            a = i / rays * 2 * math.pi
            dx, dy = math.cos(a) * 0.5, math.sin(a) * 0.5
            cx, cy = ptx + 0.5, pty + 0.5
            for _ in range(radius * 2):
                tx, ty = int(cx), int(cy)
                if not (0 <= tx < W and 0 <= ty < H):
                    break
                if not self.visible[tx][ty]:
                    self.visible[tx][ty] = True
                    self.vis_list.append((tx, ty))
                    if not self.revealed[tx][ty]:
                        self.revealed[tx][ty] = True
                        self.new_revealed.append((tx, ty))
                if self.tiles[tx][ty] in (TILE_WALL, TILE_SECRET):
                    break
                cx += dx
                cy += dy
