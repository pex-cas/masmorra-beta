# -*- coding: utf-8 -*-
"""Seleccion de clase y panel lateral (stats, mochila, talentos, guia)."""

import math
import tkinter as tk
from audio.sfx import AUDIO
from inventory.items import RARITY_COLORS
from player.player import CLASS_CONFIGS, VITAMINS, VITAMIN_MAX, vitamin_price
from ui.help_text import GUIDE_SECTIONS, MENU_STATES, SKILL_HELP, SLOT_HELP, TALENT_HELP
from ui.theme import ScrollFrame, UI, make_stone_image


class PanelsMixin:
    # (clave, nombre, precio en oro, para que sirve)
    POTION_SHOP = (("hp", "Poción de vida", 40, "Cura el 45% de tu vida máxima. Se usa con la tecla Q."),)
    PASSIVE_DESCRIPTIONS = {
        "retaliation": "Al recibir daño, acumulás una onda de represalia.",
        "lifesteal_taken": "Recuperás una pequeña parte de la vida al recibir daño.",
        "damage_reduction": "Reduce el daño recibido un 12% adicional.",
        "second_chance": "Cada 8 segundos, reduce a la mitad un golpe.",
        "double_basic": "Añade un segundo disparo/golpe al ataque básico.",
        "piercing_shots": "Los proyectiles básicos atraviesan más enemigos.",
        "damage_boost": "Aumenta el daño de tus ataques un 15%.",
        "quick_cooldowns": "Reduce un 12% las recargas de habilidades.",
        "xp_bonus": "Aumenta la experiencia obtenida un 20%.",
        "map": "Mapa completo y detallado de cada piso: se desbloquea al derrotar al tercer jefe.",
    }
    # ------------------------------------------------------------------ seleccion
    def make_banner(self, parent, title, sub=""):
        w, h = 264, 56
        if getattr(self, "_stone_img", None) is None:
            self._stone_img = make_stone_image(w, h, 3)
        cv = tk.Canvas(parent, width=w, height=h, highlightthickness=2,
                       highlightbackground=UI["moss_d"], bg=UI["bg"])
        cv.create_image(0, 0, image=self._stone_img, anchor="nw")
        cv.create_text(w / 2 + 1, h / 2 - 5, text=title, fill="#000000", font=self.font_big)
        cv.create_text(w / 2, h / 2 - 6, text=title, fill=UI["gold"], font=self.font_big)
        if sub:
            cv.create_text(w / 2, h / 2 + 14, text=sub, fill=UI["dim"], font=self.font_small)
        pts = []
        for i in range(0, w + 8, 8):
            pts += [i, 5 + 3 * math.sin(i * 0.2)]
        cv.create_line(pts, fill=UI["moss_d"], width=2, smooth=True)
        for i in range(10):
            x, y = 10 + i * 26, 6 + 4 * math.sin(i * 1.7)
            cv.create_oval(x - 4, y - 2, x + 4, y + 3, fill=UI["moss"], outline="")
        return cv

    def _stone_btn(self, parent, text, cmd, **kw):
        opts = dict(font=self.font_norm, bg=UI["btn"], fg=UI["text"], activebackground=UI["btn_a"],
                    activeforeground=UI["gold"], relief=tk.RIDGE, bd=3, takefocus=0)
        opts.update(kw)  # los kwargs del llamador sobrescriben los valores por defecto
        return tk.Button(parent, text=text, command=cmd, **opts)

    def build_class_selection_screen(self):
        """Selector de héroe: tres tarjetas compactas que entran enteras en el panel (sin scroll)."""
        sp = self.side_panel
        for w in sp.winfo_children():
            w.destroy()
        sp.configure(bg="#090911")
        self.scroll = None
        BG, BG2 = "#17121c", "#211a28"
        head = tk.Frame(sp, bg="#130d19", highlightthickness=2, highlightbackground="#65324f")
        head.pack(fill=tk.X, padx=8, pady=(8, 4))
        tk.Label(head, text="ELIGE TU HÉROE", font=self.font_big, fg="#ffd166", bg="#130d19").pack(pady=(5, 0))
        tk.Label(head, text="La Ciudadela Abisal te espera", font=self.font_small, fg="#c4a9c5", bg="#130d19").pack(pady=(0, 5))
        for cname, cd in CLASS_CONFIGS.items():
            accent = cd["color"]
            frame = tk.Frame(sp, bg=BG, padx=6, pady=4, highlightthickness=2, highlightbackground=accent, cursor="hand2")
            frame.pack(fill=tk.X, padx=8, pady=3)
            row = tk.Frame(frame, bg=BG)
            row.pack(fill=tk.X)
            portrait = tk.Frame(row, bg="#0b0b12", highlightthickness=1, highlightbackground="#484052", padx=2, pady=2)
            portrait.pack(side=tk.LEFT, anchor="n")
            tk.Label(portrait, image=self.sprites.preview[cname], bg="#0b0b12").pack()
            info = tk.Frame(row, bg=BG)
            info.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(7, 0))
            tk.Label(info, text=cname.upper(), font=self.font_bold, fg=accent, bg=BG).pack(anchor="w")
            tk.Label(info, text=cd["desc"], font=self.font_small, fg="#c5bdcb", bg=BG,
                     wraplength=150, justify="left").pack(anchor="w")
            stats = tk.Frame(frame, bg=BG2, padx=5, pady=2)
            stats.pack(fill=tk.X, pady=(4, 3))
            tk.Label(stats, text=f"♥ {cd['hp']}   ⛨ {cd['df']}   ➜ {cd['speed']}   ARM {cd['armor']}",
                     font=self.font_small, fg="#8fe3b0", bg=BG2).pack(anchor="w")
            kit = cd["kit"]
            tk.Label(frame, text=f"X {kit[0][0]}  ·  C {kit[1][0]}  ·  Z {kit[2][0]}", font=self.font_small,
                     fg="#f3d28b", bg=BG, wraplength=235, justify="left").pack(anchor="w", pady=(0, 3))
            self._stone_btn(frame, f"▶  JUGAR COMO {cname.upper()}", lambda cn=cname: self.start_game(cn),
                            font=self.font_small, bg="#30202d", activebackground="#543047", pady=1).pack(fill=tk.X)

    # ------------------------------------------------------------------ panel lateral
    def build_ui_panels(self):
        sp = self.side_panel
        for w in sp.winfo_children():
            w.destroy()
        sp.configure(bg=UI["bg"])
        self.make_banner(sp, "AETHELGAARD", "La Ciudadela Abisal").pack(padx=8, pady=(8, 4))

        pf = tk.Frame(sp, bg=UI["panel"], bd=2, relief=tk.GROOVE, padx=8, pady=4)
        pf.pack(fill=tk.X, padx=8, pady=2)
        self.lbl_hero = tk.Label(pf, text="", font=self.font_big, fg=UI["gold"], bg=UI["panel"])
        self.lbl_hero.pack(anchor="w")
        self.hud_hp = tk.Label(pf, text="", font=self.font_norm, fg="#ff6b81", bg=UI["panel"])
        self.hud_hp.pack(anchor="w")
        self.hud_mp = tk.Label(pf, text="", font=self.font_norm, fg="#8ecae6", bg=UI["panel"])
        self.hud_mp.pack(anchor="w")
        self.hud_xp = tk.Label(pf, text="", font=self.font_norm, fg=UI["green"], bg=UI["panel"])
        self.hud_xp.pack(anchor="w")
        self.hud_gold = tk.Label(pf, text="", font=self.font_bold, fg=UI["gold"], bg=UI["panel"])
        self.hud_gold.pack(anchor="w", pady=2)

        bar = tk.Frame(sp, bg=UI["bg"])
        bar.pack(fill=tk.X, padx=8, pady=3)
        for i, (txt, cmd) in enumerate((("Héroe", self.show_stats), ("Mochila [I]", self.toggle_inventory),
                                        ("Talentos [T]", self.toggle_talents), ("Tienda [B]", self.toggle_shop),
                                        ("Guía [G]", self.toggle_guide), ("Pausa [O]", self.toggle_pause))):
            self._stone_btn(bar, txt, cmd).grid(row=i // 2, column=i % 2, sticky="ew", padx=2, pady=2,
                                                columnspan=1)
        self._btn_bar, self._map_btn = bar, None
        bar.grid_columnconfigure(0, weight=1)
        bar.grid_columnconfigure(1, weight=1)

        outer = tk.Frame(sp, bg=UI["moss_d"], padx=3, pady=3)
        outer.pack(fill=tk.BOTH, expand=True, padx=8, pady=5)
        self.content_frame = outer
        self.scroll = self.side_scroll = None
        self._view_state = None
        self.update_content_view()

    MENU_TITLES = {"INVENTORY": "MOCHILA", "TALENTS": "TALENTOS", "GUIDE": "GUÍA", "SHOP": "TIENDA",
                   "HERO": "HÉROE"}

    def W(self, n):
        """Ancho de ajuste de texto: el menu a pantalla completa usa lineas ~3 veces mas largas."""
        return int(n * self._ws)

    def _has_map(self):
        p = getattr(self, "player", None)
        return p is not None and "map" in p.learned_passives

    def _sync_map_button(self):
        """El boton Mapa [N] solo existe una vez aprendida la pasiva del Mapa Abisal."""
        bar = getattr(self, "_btn_bar", None)
        if bar is None or not self._has_map():
            return
        try:
            if self._map_btn is not None and self._map_btn.winfo_exists():
                return
            self._map_btn = self._stone_btn(bar, "Mapa [N]", self._open_map_from_sidebar)
            self._map_btn.grid(row=3, column=0, columnspan=2, sticky="ew", padx=2, pady=2)
        except tk.TclError:
            self._map_btn = None

    def update_content_view(self):
        if not hasattr(self, "content_frame"):
            return
        self._sync_map_button()
        if self.state in MENU_STATES:
            self._show_menu()
        else:
            self._hide_menu()
            if not self._side_info_alive():          # el panel lateral es estatico: se construye una sola vez
                self._fill_side_panel()

    def _stats_rows(self):
        p = self.player
        v = p.vitamins
        rows = [("Daño físico", f"{p.phys_dmg:.0f}"), ("Daño mágico", f"{p.mag_dmg:.0f}"),
                ("Armadura", f"{p.armor:.0f}"), ("Defensa máx.", f"{p.max_def:.0f}"),
                ("Vida máx.", f"{p.max_hp:.0f}"), ("Velocidad", f"{p.speed:.0f}"),
                ("Crítico", f"{p.crit_chance * 100:.0f}%  x{p.crit_mult:.1f}"),
                ("Evasión", f"{p.dodge * 100:.0f}%"), ("Reducción CD", f"{p.cdr * 100:.0f}%"),
                ("Oro extra", f"{p.gold_bonus * 100:.0f}%"),
                ("Pociones [Q]", f"{p.hp_potions}"),
                ("Vitamínicos", f"{sum(v.values())}")]
        return rows

    def _side_info_alive(self):
        w = getattr(self, "_side_info", None)
        try:
            return (w is not None and bool(w.winfo_exists()) and getattr(self, "_side_sig", None) == self._stats_rows())
        except tk.TclError:
            return False

    def _fill_side_panel(self):
        """Durante la partida el panel muestra tus estadisticas (se reconstruye solo cuando cambian)."""
        for w in self.content_frame.winfo_children():
            w.destroy()
        box = tk.Frame(self.content_frame, bg="#0d0a10")
        box.pack(fill=tk.BOTH, expand=True)
        tk.Label(box, text="ESTADÍSTICAS", font=self.font_bold, fg=UI["gold"], bg="#0d0a10").pack(anchor="w", padx=8, pady=(6, 3))
        rows = self._stats_rows()
        for key, val in rows:
            r = tk.Frame(box, bg="#0d0a10")
            r.pack(fill=tk.X, padx=8, pady=1)
            tk.Label(r, text=key, font=self.font_small, fg=UI["dim"], bg="#0d0a10").pack(side=tk.LEFT)
            tk.Label(r, text=val, font=self.font_small, fg="#ffd166", bg="#0d0a10").pack(side=tk.RIGHT)
        self._side_info, self._side_sig = box, rows

    def _open_map_from_sidebar(self, _event=None):
        if getattr(self, "state", None) == "PLAYING":
            self.open_map()

    def _show_menu(self):
        """Menu a pantalla completa (el juego queda en pausa mientras esta abierto)."""
        pos = 0.0
        if self.menu_scroll is not None and self._menu_state == self.state:
            try:
                pos = self.menu_scroll.cv.yview()[0]
            except tk.TclError:
                pos = 0.0
        self._menu_state = self.state
        self.map_open = False
        if not getattr(self, "_canvas_hidden", False):   # el canvas se oculta: evita que se vea el juego (o el mapa) encima del menu
            self.canvas.pack_forget()
            self._canvas_hidden = True
        if self.menu is None:
            self.menu = tk.Frame(self.root, bg=UI["bg"])
        for w in self.menu.winfo_children():
            w.destroy()
        self.menu.place(x=0, y=0, relwidth=1, relheight=1)
        self.menu.lift()
        col = tk.Frame(self.menu, bg=UI["bg"], width=780)       # columna central de ancho fijo
        col.pack(fill=tk.Y, expand=True, pady=10)
        col.pack_propagate(False)
        head = tk.Frame(col, bg=UI["bg"])
        head.pack(fill=tk.X, pady=(0, 6))
        tk.Label(head, text=self.MENU_TITLES[self.state], font=self.font_title, fg=UI["gold"],
                 bg=UI["bg"]).pack(side=tk.LEFT)
        self._stone_btn(head, "Cerrar [Esc]", self.close_menu, font=self.font_bold).pack(side=tk.RIGHT)
        tk.Label(head, text=f"Oro: {self.player.gold}g", font=self.font_big, fg=UI["gold"],
                 bg=UI["bg"]).pack(side=tk.RIGHT, padx=14)
        tk.Label(col, text="Juego en pausa", font=self.font_small, fg=UI["dim"], bg=UI["bg"]).pack(anchor="w")
        frame = tk.Frame(col, bg=UI["moss_d"], padx=3, pady=3)
        frame.pack(fill=tk.BOTH, expand=True)
        self.menu_scroll = self.scroll = ScrollFrame(frame, UI["card"])
        self.scroll.pack(fill=tk.BOTH, expand=True)
        self.cf, self._ws = self.scroll.inner, 3.0
        {"INVENTORY": self._render_inventory_view, "TALENTS": self._render_talents_view,
         "GUIDE": self._render_guide_view, "SHOP": self._render_shop_view,
         "HERO": self._render_stats_view}[self.state]()
        if pos > 0:
            sc = self.scroll
            self.root.after(40, lambda: self._restore_scroll(sc, pos))

    def _hide_menu(self):
        if self.menu is not None:
            self.menu.place_forget()
        if getattr(self, "_canvas_hidden", False):
            self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, before=self.side_panel)
            self._canvas_hidden = False
        self.menu_scroll, self._menu_state = None, None
        self.scroll = self.side_scroll

    def toggle_pause(self):
        """Tecla O: pausa / reanuda. Congela la simulacion y dibuja un velo con el aviso de pausa."""
        if self.state == "PLAYING":
            self.keys.clear()
            self.mouse_down = False
            self.state = "PAUSED"
            self._draw_pause_overlay()
        elif self.state == "PAUSED":
            self.canvas.delete("pause")
            self.keys.clear()
            self.state = "PLAYING"

    def _draw_pause_overlay(self):
        c, W, H = self.canvas, self.view_w, self.view_h
        c.create_rectangle(0, 0, W, H, fill="#000000", stipple="gray50", outline="", tags="pause")
        c.create_rectangle(W / 2 - 190, H / 2 - 70, W / 2 + 190, H / 2 + 70, fill="#10060b", outline="#7a1030",
                           width=3, tags="pause")
        c.create_text(W / 2 + 2, H / 2 - 22, text="PAUSA", fill="#3a0612", font=self.font_huge, tags="pause")
        c.create_text(W / 2, H / 2 - 24, text="PAUSA", fill="#e8c2a0", font=self.font_huge, tags="pause")
        c.create_text(W / 2, H / 2 + 26, text="O o Esc para continuar", fill="#c2184b", font=self.font_bold, tags="pause")
        c.create_text(W / 2, H / 2 + 48, text="I mochila · T talentos · B tienda · G guía (se abren tras reanudar)",
                      fill="#8a7a80", font=self.font_small, tags="pause")

    def close_menu(self):
        self.set_state("PLAYING")

    def set_state(self, state):
        """Cambia entre juego y menus. Al abrir un menu se sueltan teclas y mouse (sin movimiento fantasma)."""
        if state in MENU_STATES:
            self.keys.clear()
            self.mouse_down = False
        self.state = state
        self.update_content_view()

    def _restore_scroll(self, sc, pos):
        try:
            sc.cv.yview_moveto(pos)
        except tk.TclError:
            pass

    def on_wheel(self, event):
        if self.scroll is not None:
            try:
                self.scroll.cv.yview_scroll(int(-event.delta / 120), "units")
            except tk.TclError:
                pass

    # ---- piezas de interfaz
    def _section(self, text, hint=None):
        f = tk.Frame(self.cf, bg=UI["card"])
        f.pack(fill=tk.X, padx=4, pady=(9, 2))
        tk.Label(f, text="» " + text, font=self.font_bold, fg=UI["gold"], bg=UI["card"]).pack(anchor="w")
        tk.Frame(f, bg=UI["moss"], height=2).pack(fill=tk.X)
        if hint:
            tk.Label(f, text=hint, font=self.font_small, fg=UI["dim"], bg=UI["card"], justify="left",
                     wraplength=self.W(215)).pack(anchor="w", pady=(2, 0))

    def _entry(self, head, help_text="", color=None):
        f = tk.Frame(self.cf, bg=UI["card"])
        f.pack(fill=tk.X, padx=6, pady=2)
        tk.Label(f, text=head, font=self.font_norm, fg=color or UI["text"], bg=UI["card"], justify="left",
                 wraplength=self.W(215)).pack(anchor="w")
        if help_text:
            tk.Label(f, text=help_text, font=self.font_small, fg=UI["dim"], bg=UI["card"], justify="left",
                     wraplength=self.W(215)).pack(anchor="w")

    def _render_stats_view(self):
        p = self.player
        cfg = CLASS_CONFIGS[p.char_class]
        self._section("HABILIDADES", "Se usan con X, C y Z. V activa un ataque alternativo. Mantené X apretado para repetir el ataque base.")
        for i, key in enumerate("XCZ"):
            nm, cd = cfg["kit"][i]
            self._entry(f"[{key}] {nm}", SKILL_HELP[p.char_class][i], UI["gold"])
        self._entry("Resistencia y reducción de daño", "La armadura y los efectos de reducción mitigan el daño recibido.", UI["gold"])
        self._section("ESTADÍSTICAS", "Cada número viene de tu clase + talentos + equipo.")
        rows = [
            ("Daño Físico", f"{p.phys_dmg}", "Potencia de tajos, dagas y torbellino."),
            ("Daño Mágico", f"{p.mag_dmg}", "Potencia de rayos, bolas de fuego y meteoros."),
            ("Armadura", f"{p.armor}", "Reduce el daño recibido (más armadura rinde menos a la larga)."),
            ("Prob. Crítico", f"{int(p.crit_chance * 100)}%", "Chance de que un golpe haga daño extra."),
            ("Mult. Crítico", f"{p.crit_mult:.2f}x", "Cuánto multiplica el daño un crítico."),
            ("Evasión", f"{int(p.dodge * 100)}%", "Chance de esquivar un golpe por completo."),
            ("Reducción CD", f"{int(p.cdr * 100)}%", "Acorta la espera de las habilidades C y Z."),
            ("Velocidad", f"{int(p.speed)}", "Velocidad de desplazamiento del personaje."),
            
            ("Regen. Vida", "Desactivada", "La vida solo se recupera con pociones; subir de nivel ya no cura."),
            ("Defensa máx", f"{int(p.max_def)}", "Reserva defensiva del personaje."),
            ("Reducción de daño", f"{int(getattr(p, "damage_reduction_bonus", 0)*100)}%", "Reducción permanente adquirida con suplementos."),
            ("Hielo", f"{int(p.freeze_chance * 100)}%", "Chance de congelar 1s al enemigo golpeado."),
            ("Fuego", f"{p.burn_dmg}", "Si es mayor a 0, tus golpes prenden en llamas al enemigo."),
            ("Oro extra", f"{int(p.gold_bonus * 100)}%", "Más oro por cada enemigo derrotado."),
        ]
        for nm, val, hlp in rows:
            self._entry(f"{nm}: {val}", hlp)
        self._section("POCIONES")
        self._entry(f"Vida [Q]: {p.hp_potions}", "Cura el 45% de tu vida máxima.", "#ff6b81")

    def _render_inventory_view(self):
        p = self.player
        self._section("PASIVAS ACTIVAS", "Las pasivas aprendidas permanecen activas durante toda la partida.")
        learned = sorted(getattr(p, "learned_passives", set()))
        if learned:
            for passive in learned:
                self._entry("✓ " + passive.replace("_", " ").capitalize(),
                            self.PASSIVE_DESCRIPTIONS.get(passive, "Pasiva permanente activa."), "#80ed99")
        else:
            self._entry("Todavía no aprendiste pasivas", "Comprá pergaminos en el Santuario de habilidades [B].")
        self._section(f"PERGAMINOS ({len(p.inventory)})", "Aprendé los pergaminos para activar sus efectos. No se puede comprar ni equipar equipo.")
        for idx, itm in enumerate(p.inventory):
            row = tk.Frame(self.cf, bg=UI["row"], bd=1, relief=tk.RAISED)
            row.pack(fill=tk.X, padx=4, pady=3)
            left = tk.Frame(row, bg=UI["row"])
            left.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=3)
            tk.Label(left, text=itm.name, font=self.font_small, fg=RARITY_COLORS[itm.rarity],
                     bg=UI["row"], justify="left", wraplength=self.W(180)).pack(anchor="w")
            tk.Label(left, text=itm.desc, font=self.font_small, fg=UI["dim"], bg=UI["row"],
                     justify="left", wraplength=self.W(180)).pack(anchor="w")
            self._stone_btn(row, "Aprender", lambda i=idx: self._equip(i), font=self.font_small).pack(side=tk.RIGHT, padx=4)
        if not p.inventory:
            self._entry("No tenés pergaminos", "Visitá el Santuario [B] para adquirir habilidades pasivas.")

    def _render_talents_view(self):
        p = self.player
        self._section(f"TALENTOS (puntos: {p.skill_points})",
                      "Ganás 1 punto por cada nivel. Cada punto mejora para siempre estas estadísticas:")
        for name, pts in p.talents.items():
            row = tk.Frame(self.cf, bg=UI["row"], bd=1, relief=tk.GROOVE)
            row.pack(fill=tk.X, padx=4, pady=3)
            left = tk.Frame(row, bg=UI["row"])
            left.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=3)
            tk.Label(left, text=f"{name.capitalize()}: {pts}", font=self.font_bold, fg=UI["text"], bg=UI["row"]).pack(anchor="w")
            tk.Label(left, text=TALENT_HELP[name], font=self.font_small, fg=UI["dim"], bg=UI["row"],
                     justify="left", wraplength=self.W(150)).pack(anchor="w")
            if p.skill_points > 0:
                tk.Button(row, text="+", font=self.font_bold, bg=UI["moss"], fg="#0b140a", width=3, takefocus=0,
                          activebackground=UI["green"], relief=tk.RIDGE, bd=3,
                          command=lambda tn=name: self._learn_talent(tn)).pack(side=tk.RIGHT, padx=4)

    def _render_guide_view(self):
        for title, items in GUIDE_SECTIONS:
            self._section(title)
            for head, txt in items:
                self._entry(head, txt, UI["gold"])

    def show_stats(self):
        self.set_state("PLAYING" if self.state == "HERO" else "HERO")

    def _equip(self, i): self.player.equip_item(i); self.update_content_view()
    def _unequip(self, s): self.player.unequip_item(s); self.update_content_view()

    def _sell(self, i):
        p = self.player
        if 0 <= i < len(p.inventory):
            p.gold += p.inventory.pop(i).value
            AUDIO.play_sfx("gold")
            self.update_content_view()

    def _learn_talent(self, name):
        p = self.player
        if p.skill_points > 0:
            p.skill_points -= 1
            p.talents[name] += 1
            p.recalculate_stats()
            AUDIO.play_sfx("level_up")
            self.update_content_view()

    def toggle_inventory(self):
        self.set_state("PLAYING" if self.state == "INVENTORY" else "INVENTORY")

    def toggle_talents(self):
        self.set_state("PLAYING" if self.state == "TALENTS" else "TALENTS")

    def toggle_guide(self):
        self.set_state("PLAYING" if self.state == "GUIDE" else "GUIDE")

    def toggle_shop(self):
        self.set_state("PLAYING" if self.state == "SHOP" else "SHOP")


    # ---- tienda
    @staticmethod
    def item_price(item):
        # Los pergaminos son mejoras permanentes; el coste evita comprar todo al inicio.
        return item.value * 6

    def _shop_row(self, title, subtitle, color, price, cmd, enabled=True, why=""):
        row = tk.Frame(self.cf, bg=UI["row"], bd=1, relief=tk.GROOVE)
        row.pack(fill=tk.X, padx=4, pady=2)
        left = tk.Frame(row, bg=UI["row"])
        left.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=4, pady=3)
        tk.Label(left, text=title, font=self.font_norm, fg=color, bg=UI["row"], justify="left",
                 wraplength=self.W(125)).pack(anchor="w")
        tk.Label(left, text=subtitle, font=self.font_small, fg=UI["dim"], bg=UI["row"], justify="left",
                 wraplength=self.W(125)).pack(anchor="w")
        b = self._stone_btn(row, why or f"Comprar {price}g", cmd, font=self.font_bold)
        if not enabled:
            b.config(state=tk.DISABLED)
        b.pack(side=tk.RIGHT, padx=6, pady=4)

    def _render_shop_view(self):
        p = self.player
        self._section("SANTUARIO", "Pociones, vitamínicos y pergaminos. Cada objeto indica para qué sirve.")
        self._section("POCIONES", f"Tenés {p.hp_potions}.")
        for key, name, price, desc in self.POTION_SHOP:
            ok = p.gold >= price
            self._shop_row(name, desc, "#ff6b81", price, lambda k=key: self._buy_potion(k), ok,
                           "" if ok else f"Faltan {price - p.gold}g")
        self._section("VITAMÍNICOS", f"Mejoras permanentes y caras: el precio sube con cada compra (máx. {VITAMIN_MAX} de cada una).")
        for key, vt in VITAMINS.items():
            n = p.vitamins[key]
            if n >= VITAMIN_MAX:
                self._shop_row(f"{vt['name']}  ({n}/{VITAMIN_MAX})", vt["desc"], vt["color"], 0,
                               lambda: None, False, "AL MÁXIMO")
                continue
            price = vitamin_price(key, n)
            ok = p.gold >= price
            self._shop_row(f"{vt['name']}  ({n}/{VITAMIN_MAX})", vt["desc"], vt["color"], price,
                           lambda k=key: self._buy_vitamin(k), ok, "" if ok else f"Faltan {price - p.gold}g")
        self._section("PERGAMINOS Y PASIVAS", "Se compran, se guardan en la mochila [I] y se aprenden para activar su efecto.")
        for idx, itm in enumerate(self.shop_stock):
            price = self.item_price(itm)
            full = len(p.inventory) >= p.max_inv
            ok = p.gold >= price and not full
            why = "Mochila llena" if full else ("" if ok else f"Faltan {price - p.gold}g")
            self._shop_row(f"{itm.name} ({itm.slot})", (itm.desc if itm.slot == "Pergamino" else f"[{itm.rarity}] " + itm.stat_text()), RARITY_COLORS[itm.rarity],
                           price, lambda i=idx: self._buy_item(i), ok, why)
        if not self.shop_stock:
            self._entry("(agotado)", "Volvé en el próximo piso: la tienda se reabastece.")

    def _buy_potion(self, kind):
        p = self.player
        price = next(x[2] for x in self.POTION_SHOP if x[0] == kind)
        if p.gold < price:
            return
        p.gold -= price
        p.hp_potions += 1
        AUDIO.play_sfx("gold")
        self.update_content_view()

    def _buy_vitamin(self, key):
        p = self.player
        n = p.vitamins.get(key, 0)
        if n >= VITAMIN_MAX:
            return
        price = vitamin_price(key, n)
        if p.gold < price:
            return
        p.gold -= price
        p.vitamins[key] = n + 1
        old_hp = p.max_hp
        p.recalculate_stats()
        if key == "vida":
            p.hp = min(p.max_hp, p.hp + (p.max_hp - old_hp))
        AUDIO.play_sfx("level_up")
        self.update_content_view()

    def _buy_item(self, i):
        p = self.player
        if not (0 <= i < len(self.shop_stock)) or len(p.inventory) >= p.max_inv:
            return
        itm = self.shop_stock[i]
        price = self.item_price(itm)
        if p.gold < price:
            return
        p.gold -= price
        p.inventory.append(self.shop_stock.pop(i))
        AUDIO.play_sfx("gold")
        self.update_content_view()
