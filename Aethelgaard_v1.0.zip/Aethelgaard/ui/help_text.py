# -*- coding: utf-8 -*-
"""Textos de ayuda de la interfaz."""


# ==============================================================================
SKILL_HELP = {
    "Guerrero": ("Tajo en arco frente a vos. Sin costo; mantenelo apretado para repetirlo.",
                 "Golpe sísmico: daño enorme, empuja y congela 1.2s a los golpeados.",
                 "Torbellino: 2.6s de cuchillas giratorias a tu alrededor. Sos invulnerable y más rápido."),
    "Mago": ("Rayo arcano: proyectil veloz, sin límite de uso.",
             "Bola de fuego: explota en área y deja a los enemigos ardiendo.",
             "Lluvia de meteoros: 10 meteoros caen alrededor del objetivo (cursor o autoapuntado)."),
    "Bandido": ("Daga veloz con +10% de crítico. Sin costo.",
               "Abanico: lanza 7 dagas en abanico; cada una atraviesa a 2 enemigos.",
               "Danza de cuchillas: te teletransportás entre hasta 7 enemigos cercanos con golpes críticos."),
}

SLOT_HELP = {
    "Pantalones": "Aumentan armadura y vida máxima.",
    "Botas": "Aumentan velocidad, armadura y evasión.",
    "Chaleco": "Aumenta armadura y vida máxima.",
    "Casco": "Aumenta armadura y vida máxima.",
    "Báculo": "Aumenta daño físico y mágico.",
}

TALENT_HELP = {
    "vitalidad": "+25 vida máxima y +0.5 regeneración de vida por punto.",
    "ferocidad": "+4 daño, +2% crítico y +0.1 de multiplicador crítico por punto.",
    "celeridad": "+10 velocidad, +5% reducción de cooldown y +10 stamina por punto.",
    "resistencia": "+2 armadura por punto: reduce el daño recibido.",
    "precision": "+1.5% de probabilidad de crítico por punto.",
}

GUIDE_SECTIONS = [
    ("CONTROLES", [
        ("WASD / Flechas", "Moverte por la mazmorra."),
        ("MOVIMIENTO", "Desplazate con WASD o las flechas. El personaje mira hacia la dirección en la que camina."),
        ("X o click izq.", "Ataque base. Tiene una pausa más larga entre golpes."),
        ("V", "Ataque alternativo: Guerrero hace un tajo amplio, Mago dispara tres rayos y Bandido lanza dos dagas."),
        ("C o click der.", "Ataque fuerte: más daño, con cooldown."),
        ("Z", "ULTIMATE: tu habilidad definitiva, con cooldown largo."),
        ("L (mantener)", "DEFENSA: te cubrís con un escudo y absorbés el 80% del daño. No podés atacar ni correr y caminás lento. "
                         "La defensa funciona sin mostrar una barra de escudo."),
        ("Q", "Poción de vida (cura 45%)."),
        ("P", "Activa o desactiva el AUTOAPUNTADO."),
        ("M", "Activa o desactiva la música."),
        ("O", "PAUSA: congela el juego. Volvé a apretar O o Esc para continuar."),
        ("I · T · B · G", "Mochila · Talentos · Tienda · Guía. Se abren a pantalla completa y pausan el juego; Esc los cierra."),
        ("F11", "Pantalla completa / ventana."),
    ]),
    ("AUTOAPUNTADO", [
        ("Cómo funciona", "Con P activado, cada ataque y meteoro va solo hacia el enemigo visible más cercano (hasta 480px). "
                          "Los ataques se orientan al enemigo visible más cercano. Sin enemigos cerca apuntás con el mouse. Con P desactivado apuntás siempre con el mouse."),
    ]),
    ("LA MAZMORRA", [
        ("Escaleras", "Bajan al siguiente piso. Cada 2 niveles hay un piso de jefe (sala única) y los pisos 5 y 10 tienen sala de jefe; todos bloquean el descenso. Mapa ampliado: [N] o clic en el minimapa. El piso 10 es la victoria."),
        ("Cofres", "Solo hay cofres en las habitaciones secretas; dan 100 monedas normalmente o 300 con menor probabilidad y una poción garantizada."),
        ("Paredes secretas", "Algunas paredes tienen una grieta. Atacalas (cuerpo a cuerpo, proyectiles o explosiones) y se rompen, "
                             "revelando una cámara oculta con un cofre que da 100 o 300 monedas y una poción garantizada."),
        ("Antorchas", "Iluminan la zona; lejos de ellas todo es más oscuro. Lo explorado queda en el minimapa."),
        ("Pociones y oro", "Las botellas rojas son pociones de vida y las monedas / montones brillantes son oro: caminá cerca y el oro viene solo hacia vos."),
    ]),
    ("OBJETOS Y ORO", [
        ("Rareza", "Común (gris), Mágico (azul), Raro (amarillo), Épico (violeta), Legendario (naranja). Más rareza, más bonos."),
        ("Mochila", "Usá los pergaminos para aprender pasivas permanentes."),
        ("Santuario", "El Santuario [B] vende habilidades y pasivas; no se compra equipamiento."),
        ("Oro", "Los enemigos dejan una cantidad moderada de oro; los jefes dan más que los enemigos comunes."),
    ]),
]

MENU_STATES = ("INVENTORY", "TALENTS", "GUIDE", "SHOP", "HERO")      # menus a pantalla completa (juego en pausa)
PLAY_STATES = ("PLAYING", "PAUSED") + MENU_STATES
