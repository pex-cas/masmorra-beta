# Aethelgaard V13 — portada y animaciones corregidas

- Se reconstruyeron los cuatro fotogramas de los personajes a partir de la pose base íntegra. La animación ya no usa los fotogramas anteriores que desplazaban extremidades dejando huecos grandes en el torso.
- Los fotogramas de caminar hacen un movimiento corto de la parte inferior; el reposo usa un desplazamiento vertical mínimo. Se mantiene el mismo lienzo por fotograma y se generan los espejados izquierda/derecha desde el mismo original para evitar saltos de tamaño o alineación.
- La portada ahora carga PNG detallados de los mismos sprites de gameplay, con escalado pixelado sin suavizado. El fondo incorpora muro de piedra, portal abisal con anillos rúnicos y una paleta más marcada.
- Se conservan el sistema de experiencia, la barra XP bajo la vida y la velocidad de movimiento de V12.

## Validación

- `python -m compileall -q .`: correcto.
- Suite: 59 pruebas; 47 aprobadas, 10 omitidas y 2 errores por limitaciones del entorno sin display Tk / root gráfico.
- Se inspeccionaron visualmente los PNG reconstruidos. No fue posible abrir una partida Tk en este entorno, así que la comprobación final de la portada en ejecución debe hacerse en Windows con `ejecutar.bat`.
