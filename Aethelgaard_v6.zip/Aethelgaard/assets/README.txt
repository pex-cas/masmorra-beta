RECURSOS EXTERNOS (todos opcionales)
====================================
El juego genera sus texturas, sprites y musica por codigo. Si colocas aqui un archivo valido,
reemplaza al integrado; si falta o esta danado (se anota en logs/game.log) se usa el integrado.

images/    (opcional) Sprites propios:  <nombre>.png  (PNG cuadrado, 64x64 para clases y enemigos comunes, 80x80
           Minotauro Brutal, 112x112 Senor del Abismo; se admiten multiplos exactos: 96x96, ...)
           Nombres: guerrero, mago, picaro, esqueleto, zombi_putrido, arquero_espectral,
           mago_de_fuego, minotauro_brutal, senor_del_abismo_jefe
textures/  Texturas 24x24 (o multiplo exacto): <tipo>_<variante>.png o <tipo>.png
           Tipos: floor (0-3), floor_sh (0-1), wall_face (0-7), wall_cap (0-7), void, chest, shrine,
           pillar, torch (0-1), stairs, bones, moss, crack, barrel, crate, web_l, web_r, chains
           Se tinen con los mismos niveles de luz que las integradas.
music/     Cualquier .mp3 / .wav / .wma que pongas aca suena en lugar de la musica generada (en bucle).
           - Una sola pista: suena en todos los pisos. Varias: se reparten por bioma (orden alfabetico).
           - bioma_1.mp3 ... bioma_4.mp3 fijan la pista de un bioma concreto (tienen prioridad).
           MP3/WMA usan MCI de Windows (sin instalar nada); si no se pueden abrir se anota en
           logs/game.log y suena la musica generada. Tecla M = silenciar.

No hay carpetas de fuentes ni de efectos de sonido: Tkinter no carga fuentes desde archivo de forma
portable, y los efectos usan winsound.Beep (un WAV externo cortaria la musica de fondo).
