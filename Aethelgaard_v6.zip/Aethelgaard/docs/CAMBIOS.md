# Resumen de cambios

## Estructura
`juego_v3.py` (un solo archivo) → paquetes `game/ player/ combat/ world/ graphics/ audio/ ui/ inventory/`.
El código se movió sin cambiar su comportamiento; `GameEngine` se reparte en mixins
(`PanelsMixin`, `CombatMixin`, `RenderMixin`, `HudMixin`). Sin dependencias circulares (probado).
Copia intacta del original: `docs/juego_v3_original.py`.

## Mapa
- **Bloques transparentes → sólidos**: causa real = `compute_fov` solo revela las paredes que toca un rayo,
  así que quedaban paredes junto a suelo explorado sin revelar (se veía el fondo) hasta acercarse.
  Nuevo `DungeonMap.complete_wall_shell()` revela el contorno de pared de lo explorado. No toca
  `compute_fov`, `visible`, mapa de luz ni niveles de luz.
- **Generación validada**: el mapa lógico se genera completo y se valida (bordes cerrados, sin zonas
  aisladas, escaleras accesibles, cámaras secretas selladas hasta romper la pared) antes de jugar.
  Hasta 40 intentos; si ninguno es perfecto se usa el mejor mapa válido.
- **3 habitaciones secretas por piso** (antes 1–3 según piso), sin superposición, accesibles al romper la pared.
- **Ciclo de color**: piso 1 azul, 2 verde, 3 rojo, 4 violeta, 5 azul… La música sigue usando su bioma original.
- **Puertas y arcos decorativos de pared eliminados** (generación, textura y render). Decoración de suelo intacta.
- Pilares: si aislarían una zona, se quitan (antes solo se comprobaba la escalera).

## Estética
Paletas más oscuras y apagadas; terreno en texturas de 12×12 texels ampliadas ×2 (pixelado áspero),
caras planas con luz arriba-izquierda/sombra abajo-derecha, mugre y desgaste en piedra. Los personajes ya eran
modelos poligonales con sombreado plano. `accent`/`rim` de cada paleta se conservan (alimentan los efectos de luz).

## Recursos externos (opcionales)
`assets/images`, `assets/textures`, `assets/music`: si hay un archivo válido reemplaza al integrado;
si falta o está dañado se registra en `logs/game.log` y se usa el integrado.

## Rendimiento
Un solo atlas de texturas por paleta (se reutiliza al repetirse el ciclo de colores); si hay sprite externo
no se rasteriza el modelo integrado. Generación de mapa ≈ 13 ms con validación (medido en el entorno de pruebas;
no se midió contra el original). No se refactorizó el bucle de render de Tk (borra y redibuja el canvas cada frame).

## Intacto (comprobado por AST contra el original en `tests/`)
Combate, robo de vida, stats, clases/habilidades, enemigos/IA, inventario, controles, música/SFX,
progresión, animaciones, HUD y minimapa; iluminación, FOV y efectos luminosos.

## Segunda entrega
- **Texturas**: se quitaron las manchas oscuras de desgaste/liquen que parecían agujeros en las paredes (y la mugre del suelo).
- **Sin equipo suelto**: enemigos, cofres, jefe y cámaras secretas ya no sueltan equipo (siguen las pociones). El jefe y las
  cámaras secretas dan oro extra. El equipo se compra en la **Tienda [B]** (pociones y 6 objetos que se renuevan cada piso;
  precio = valor × 4). Vender sigue en la Mochila.
- **Menús a pantalla completa con pausa**: Héroe, Mochila, Talentos, Tienda y Guía (botones o teclas H/I/T/B/G; ESC cierra).
- **Pantalla completa**: F11; la ventana es redimensionable y el juego se adapta al tamaño.
- **Sprites**: pixel art de frente (modelo poligonal rasterizado a 24/32/40 px y ampliado ×2 sin suavizar); la marcha se anima
  levantando los pies.
- **Música externa**: cualquier .mp3/.wav/.wma en `assets/music/` reemplaza la generada (MP3/WMA vía MCI de Windows).


## Versión 3: música/skins desde el juego y jefe del piso 5
- `game/mods.py` (nuevo): guarda en `config/mods.json` la canción/carpeta de música y las skins elegidas.
- `ui/panels.py`: menú "Música y skins" (tecla O) con selectores de archivo/carpeta de Windows; `game/engine.py`: `apply_skins()`.
- `game/assets.py` (`find_music`) y `audio/music.py` (`reload`): la música elegida va antes que `assets/music` y que la sintetizada.
- `graphics/sprites.py`: la skin del jugador va antes que `assets/images`.
- `combat/enemies.py`: jefe del piso 5 difícil (`HARD_BOSS_FLOOR`); `game/engine.py`: sala del jefe exclusiva e invocaciones.
- `tests/test_mods_boss.py` (nuevo); las pruebas de "sistemas protegidos" ahora permiten el cambio pedido en `Enemy`.


## Versión 4
- **Audio propio**: la música sintetizada seguía sonando debajo de la elegida porque `winsound.SND_PURGE` no corta el loop en
  Windows moderno. Ahora se frena con `PlaySound(None, SND_ASYNC)` (`audio/music.py`, `_stop_winsound`). Además el hilo que
  sintetiza ya no pisa una canción elegida mientras se generaba.
- **Skins**: aceptan PNG de cualquier tamaño (se muestrea proporcionalmente); antes se ignoraban si no medían 48 o múltiplo exacto.
- **Mapa**: solo rectángulos (salas siempre `rect`; sin erosión ni limpieza de paredes; pasillos rectos en L).
- **Sala del jefe** (pisos 5 y 10): cuadrado 13x13 lejos del spawn, con una sola entrada (validada al generar). Al entrar se sella
  (`GameEngine.update_boss_gate`) y se reabre al morir el jefe. Sin pilares ni cámaras secretas pegadas.
- **Jefe del piso 5 nerfeado**: vida x2.4 → x1.25 (~2480 → ~1290), daño x1.35 → x1.15, velocidad x1.15 → x1.05.
- `tests/test_v4.py` (nuevo); las pruebas de "sistemas protegidos" permiten estos cambios pedidos.


## Versión 5: fantasía oscura
- **Gráficos**: sprites pixel art tomados de `assets/source/roster.png` (mago, minotauro, zombi, esqueleto, caballero oscuro = Guerrero,
  pícaro). Mago de Fuego y Arquero Espectral son variantes de color del mago y del pícaro; el jefe es un diseño nuevo
  (alas, cuernos, runas). Sprites más grandes (64/80/112 px), con rebote al caminar. Generador: `tools/build_sprites.py`.
- **Portada**: escena con el elenco completo (jefe al fondo, enemigos detrás, héroes al frente), niebla y brasas.
- **Interfaz**: paleta carmesí sobre carbón; pisos más apagados (los acentos de luz no cambian).
- **Tecla O**: ahora **pausa** (estado `PAUSED`, velo y cartel). Se quitó el menú "Música y skins"; ya no hay botón ni estado MODS.
- **Música**: más tenebrosa (`audio/music.py`, `synth`): raíces sub-graves, acordes menores/disminuidos con segunda menor y tritono,
  viento, coro fantasmal, campanas inarmónicas, latido irregular y gemidos. Caché nueva (`bgm_v2`).
- **Jefe**: sprite detallado de 112 px, aura abisal pulsante con brasas orbitantes y runas (más intensa al enfurecerse),
  flota al moverse y barra de vida ornamentada con marcas de fase y aviso "¡ENFURECIDO!".
- Pruebas actualizadas (`SpriteBank`, música, tamaños de skin, pausa con O); combate, IA, stats y mapa no se tocaron.


## Versión 6
- **Personajes y enemigos**: vuelven los sprites pixel art 16x16 de la versión original (se quitaron los PNG de `assets/images` y las herramientas de `tools/`).
- **Jefe nuevo** (`build_boss` en `graphics/sprites.py`, 24x24): corona de cuernos, alas, armadura con núcleo rúnico y espadón.
- **Escenarios**: texturas nuevas en `graphics/textures.py` (contorno grueso, cel-shading) y paletas más vivas pero oscuras en `world/dungeon.py`.
- **Oro y botellas**: `graphics/icons.py`. El oro cae como monedas/montones y un imán lo atrae; el que quede sin recoger se cobra al bajar de piso. Las pociones son botellas rojas; el HUD muestra ambos con icono.
- **Defensa [L]** reemplaza al maná: barra celeste, escudo visible, se gasta y se recupera lento. Habilidades sin costo; sin pociones de maná.
- **Robo de vida eliminado** (talento Vampirismo y prefijo Vampírico). Los objetos de maná ahora dan defensa máxima / regeneración de defensa.
