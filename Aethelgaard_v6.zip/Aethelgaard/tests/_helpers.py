# -*- coding: utf-8 -*-
"""Utilidades de las pruebas: ruta del proyecto y un Tk simulado para importar sin pantalla."""
import os
import sys
import types

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def have_tk():
    try:
        import tkinter  # noqa: F401
        return True
    except ImportError:
        return False


def install_fake_tk():
    """Solo para comprobar importaciones cuando Tkinter no existe (entornos sin pantalla)."""
    if have_tk() or "tkinter" in sys.modules:
        return
    tk = types.ModuleType("tkinter")
    for n in ("Tk", "Canvas", "Frame", "Label", "Button", "Scrollbar", "TclError"):
        setattr(tk, n, type(n, (Exception,) if n == "TclError" else (), {}))
    tk.PhotoImage = type("PhotoImage", (), {"__init__": lambda self, *a, **k: None,
                                            "put": lambda self, *a, **k: None,
                                            "zoom": lambda self, *a, **k: self})
    for n in ("LEFT", "RIGHT", "BOTH", "X", "Y", "RIDGE", "GROOVE", "RAISED"):
        setattr(tk, n, n.lower())
    font = types.ModuleType("tkinter.font")
    font.Font = type("Font", (), {})
    tk.font = font
    fd = types.ModuleType("tkinter.filedialog")
    fd.askopenfilename = fd.askdirectory = lambda **k: ""
    tk.filedialog = fd
    sys.modules["tkinter"], sys.modules["tkinter.font"] = tk, font
    sys.modules["tkinter.filedialog"] = fd
