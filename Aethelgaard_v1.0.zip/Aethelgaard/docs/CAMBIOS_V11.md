# Cambios V11 — sprites de referencia y animación

- Se incorporaron sprites recortados de la hoja de referencia en `assets/sprites/`.
- Los personajes principales y enemigos usan esos PNG en el render del juego; no son una imagen de muestra aparte.
- Cada sprite tiene cuatro fotogramas para caminar/respirar y variantes espejadas para la orientación izquierda.
- El render conserva el sistema de movimiento, IA, colisiones, combate, barras de vida y efectos existentes.
- Si falta un PNG, el juego recurre al sprite procedural previo para evitar bloquear el inicio.
- Las animaciones reutilizan el reloj de animación y el estado de movimiento que ya tenía el juego.

## Validación realizada

- La suite de tests ejecutó 59 pruebas: 47 aprobadas, 10 omitidas por requerir Tk real y 2 fallaron porque el entorno de ejecución no tiene pantalla/display gráfico (`TclError: couldn't connect to display ":0"` y ausencia de ventana raíz Tk).
- La carga gráfica real y la partida interactiva no pudieron verificarse en este entorno sin display. Ejecutar `ejecutar.bat` en Windows para la comprobación visual final.
