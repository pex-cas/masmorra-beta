# V14 — optimización y limpieza de controles

- Quité las leyendas que promocionaban SHIFT para correr en el panel lateral y el HUD. La tecla sigue funcionando como sprint, pero ya no se anuncia en esas zonas.
- El render del mundo queda limitado a 40 FPS mientras la simulación continúa actualizándose en cada ciclo; esto reduce la carga de recrear cientos de elementos de Canvas cada 16 ms en equipos modestos.
- La portada se redibuja como máximo a 24 FPS y se redujo la cantidad de brasas animadas.
- Se sustituyó la distancia euclídea con raíz cuadrada por una aproximación visual para el cálculo de iluminación por baldosa.
- Las partículas fuera del área visible se omiten al dibujarlas.

La comprobación gráfica interactiva depende de ejecutar el juego en Windows; se validan sintaxis y pruebas automatizadas en este paquete.
